import React, { useState, useEffect, useRef } from 'react';
import { 
  db, 
  serverTimestamp, 
  getLocalData, 
  setLocalData, 
  DEFAULT_SEED_MATERI 
} from './services/firebase';
import { ref, onValue, set, update, remove, push } from 'firebase/database';
import { 
  User, 
  Materi, 
  FolderLock, 
  AbsenRecord, 
  LaporanNilai, 
  StudyTimeRecord, 
  ChatMessage, 
  CertificateConfig 
} from './types';
import { DATABASE_PEGAWAI } from './data/databasePegawai';
import { TopBar, Sidebar } from './components/Navigation';
import { LoginOverlay } from './components/LoginOverlay';
import { HomeView } from './components/HomeView';
import { FolderView } from './components/FolderView';
import { LearningView } from './components/LearningView';
import { TrainerPanel } from './components/TrainerPanel';
import { ModalMateri } from './components/ModalMateri';
import { ModalFolderLock } from './components/ModalFolderLock';
import { ModalUnlockFolder } from './components/ModalUnlockFolder';
import { ModalDetailPeserta } from './components/ModalDetailPeserta';
import { ModalInputNilai } from './components/ModalInputNilai';
import { CertificateModal } from './components/CertificateModal';

export default function App() {
  // Current logged in user
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    return getLocalData<User | null>('currentUser', null);
  });

  // Navigation State
  const [currentView, setCurrentView] = useState<'home' | 'folder' | 'learning' | 'admin'>('home');
  const [currentFolderName, setCurrentFolderName] = useState<string | null>(null);
  const [currentMateriId, setCurrentMateriId] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Application Data States
  const [materiList, setMateriList] = useState<Record<string, Materi>>(() => {
    return getLocalData<Record<string, Materi>>('materiList', DEFAULT_SEED_MATERI);
  });
  const [folderLocks, setFolderLocks] = useState<Record<string, FolderLock>>(() => {
    return getLocalData<Record<string, FolderLock>>('folderLocks', {});
  });
  const [folderOrder, setFolderOrder] = useState<string[]>(() => {
    return getLocalData<string[]>('folderOrder', []);
  });
  const [laporanRecords, setLaporanRecords] = useState<Record<string, Record<string, LaporanNilai>>>(() => {
    return getLocalData('laporanRecords', {});
  });
  const [absenRecords, setAbsenRecords] = useState<Record<string, Record<string, AbsenRecord>>>(() => {
    return getLocalData('absenRecords', {});
  });
  const [studyTimeRecords, setStudyTimeRecords] = useState<Record<string, Record<string, StudyTimeRecord>>>(() => {
    return getLocalData('studyTimeRecords', {});
  });
  const [chatData, setChatData] = useState<Record<string, Record<string, ChatMessage>>>({});

  // Local unlocked folders map (session-based)
  const [unlockedFolders, setUnlockedFolders] = useState<Record<string, boolean>>(() => {
    try {
      const raw = sessionStorage.getItem('bki_unlocked_folders');
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  });

  // Toast notifications
  const [toastMsg, setToastMsg] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);
  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMsg({ text, type });
    setTimeout(() => setToastMsg(null), 3500);
  };

  // Study timer ref
  const studyTimerRef = useRef<any>(null);
  const [studySeconds, setStudySeconds] = useState(0);

  // Modals state
  const [isModalMateriOpen, setIsModalMateriOpen] = useState(false);
  const [editingMateri, setEditingMateri] = useState<Materi | null>(null);

  const [isModalFolderLockOpen, setIsModalFolderLockOpen] = useState(false);
  const [folderLockTarget, setFolderLockTarget] = useState<string>('');

  const [isModalUnlockOpen, setIsModalUnlockOpen] = useState(false);
  const [folderToUnlock, setFolderToUnlock] = useState<string>('');
  const [afterUnlockAction, setAfterUnlockAction] = useState<(() => void) | null>(null);

  const [isModalDetailPesertaOpen, setIsModalDetailPesertaOpen] = useState(false);
  const [detailPesertaMateriId, setDetailPesertaMateriId] = useState<string | null>(null);

  const [isModalInputNilaiOpen, setIsModalInputNilaiOpen] = useState(false);

  // Certificate Modal State
  const [isCertificateModalOpen, setIsCertificateModalOpen] = useState(false);
  const [certificateData, setCertificateData] = useState<{
    materi: Materi | null;
    peserta: { nama: string; nup: string; unit: string; nilai: number } | null;
  }>({ materi: null, peserta: null });

  // 1. Firebase Listeners
  useEffect(() => {
    if (!db) return;

    // Listen to materi
    const materiRef = ref(db, 'materi');
    const unsubMateri = onValue(materiRef, (snapshot) => {
      const val = snapshot.val();
      if (val) {
        setMateriList(val);
        setLocalData('materiList', val);
      }
    });

    // Listen to folder locks
    const locksRef = ref(db, 'folderLocks');
    const unsubLocks = onValue(locksRef, (snapshot) => {
      const val = snapshot.val();
      if (val) {
        setFolderLocks(val);
        setLocalData('folderLocks', val);
      }
    });

    // Listen to folder order
    const orderRef = ref(db, 'folderOrder');
    const unsubOrder = onValue(orderRef, (snapshot) => {
      const val = snapshot.val();
      if (val && Array.isArray(val)) {
        setFolderOrder(val);
        setLocalData('folderOrder', val);
      }
    });

    // Listen to absen
    const absenDbRef = ref(db, 'absen');
    const unsubAbsen = onValue(absenDbRef, (snapshot) => {
      const val = snapshot.val();
      if (val) {
        setAbsenRecords(val);
        setLocalData('absenRecords', val);
      }
    });

    // Listen to laporan nilai
    const lapRef = ref(db, 'laporan');
    const unsubLaporan = onValue(lapRef, (snapshot) => {
      const val = snapshot.val();
      if (val) {
        setLaporanRecords(val);
        setLocalData('laporanRecords', val);
      }
    });

    // Listen to study time
    const studyRef = ref(db, 'studyTime');
    const unsubStudy = onValue(studyRef, (snapshot) => {
      const val = snapshot.val();
      if (val) {
        setStudyTimeRecords(val);
        setLocalData('studyTimeRecords', val);
      }
    });

    return () => {
      unsubMateri();
      unsubLocks();
      unsubOrder();
      unsubAbsen();
      unsubLaporan();
      unsubStudy();
    };
  }, []);

  // Listen to chat for active materi
  useEffect(() => {
    if (!db || !currentMateriId || currentView !== 'learning') return;
    const chatRef = ref(db, `chat/${currentMateriId}`);
    const unsubChat = onValue(chatRef, (snapshot) => {
      const val = snapshot.val();
      setChatData((prev) => ({
        ...prev,
        [currentMateriId]: val || {}
      }));
    });
    return () => unsubChat();
  }, [currentMateriId, currentView]);

  // Handle Study Timer
  useEffect(() => {
    if (currentView === 'learning' && currentMateriId && currentUser) {
      setStudySeconds(0);
      studyTimerRef.current = setInterval(() => {
        setStudySeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (studyTimerRef.current) {
        clearInterval(studyTimerRef.current);
        studyTimerRef.current = null;
        // Save duration if > 5 seconds
        if (currentMateriId && currentUser && studySeconds > 5) {
          saveStudyTime(currentMateriId, currentUser.nup, studySeconds);
        }
      }
    }
    return () => {
      if (studyTimerRef.current) {
        clearInterval(studyTimerRef.current);
      }
    };
  }, [currentView, currentMateriId]);

  const saveStudyTime = (mid: string, userNup: string, seconds: number) => {
    if (!currentUser) return;
    const existing = studyTimeRecords[mid]?.[userNup];
    const updated: StudyTimeRecord = {
      nama: currentUser.nama,
      unit: currentUser.unit,
      totalDetik: (existing?.totalDetik || 0) + seconds,
      sesiCount: (existing?.sesiCount || 0) + 1,
      lastSeen: Date.now()
    };

    setStudyTimeRecords((prev) => ({
      ...prev,
      [mid]: { ...(prev[mid] || {}), [userNup]: updated }
    }));
    setLocalData('studyTimeRecords', {
      ...studyTimeRecords,
      [mid]: { ...(studyTimeRecords[mid] || {}), [userNup]: updated }
    });

    if (db) {
      set(ref(db, `studyTime/${mid}/${userNup}`), updated).catch(console.error);
    }
  };

  // Helper: Get folder lock info
  const getFolderLock = (folderName: string): FolderLock | null => {
    if (!folderName) return null;
    const key = encodeURIComponent(folderName.trim()).replace(/\./g, '%2E');
    if (folderLocks[key]) return folderLocks[key];
    // Fallback from materi
    for (const mid of Object.keys(materiList)) {
      const m = materiList[mid];
      if (m.folder?.trim().toLowerCase() === folderName.trim().toLowerCase()) {
        if (m.ownerTrainerId) {
          return {
            folderName,
            ownerNup: m.ownerTrainerId,
            ownerName: m.ownerTrainerName || 'Trainer'
          };
        }
      }
    }
    return null;
  };

  // Helper: Check if folder is unlocked locally
  const isFolderUnlocked = (folderName: string): boolean => {
    if (!folderName) return true;
    const lock = getFolderLock(folderName);
    if (!lock?.password) return true;
    if (currentUser?.isSuperAdmin) return true;
    if (currentUser?.isTrainer && currentUser.nup === lock.ownerNup) return true;
    return !!unlockedFolders[folderName.trim()];
  };

  // Helper: Can user view this folder?
  const canUserSeeFolder = (folderName: string): boolean => {
    if (!currentUser) return false;
    if (currentUser.isSuperAdmin) return true;
    const lock = getFolderLock(folderName);

    if (currentUser.isTrainer) {
      if (lock?.ownerNup) {
        return lock.ownerNup === currentUser.nup;
      }
      // Check if this trainer has any materi in this folder
      for (const mid of Object.keys(materiList)) {
        const m = materiList[mid];
        if (m.folder?.trim().toLowerCase() === folderName.trim().toLowerCase()) {
          if (m.ownerTrainerId === currentUser.nup) return true;
          if (m.ownerTrainerId && m.ownerTrainerId !== currentUser.nup) return false;
        }
      }
      return true;
    }

    // Participant: must have at least one visible materi in this folder
    for (const mid of Object.keys(materiList)) {
      const m = materiList[mid];
      if (m.folder?.trim().toLowerCase() === folderName.trim().toLowerCase()) {
        if (canUserSeeMateri(m)) return true;
      }
    }
    return false;
  };

  // Helper: Can user view this materi?
  const canUserSeeMateri = (m: Materi): boolean => {
    if (!currentUser) return false;
    if (currentUser.isSuperAdmin) return true;

    if (currentUser.isTrainer) {
      if (m.ownerTrainerId) {
        return m.ownerTrainerId === currentUser.nup;
      }
      const lock = getFolderLock(m.folder || '');
      if (lock?.ownerNup) {
        return lock.ownerNup === currentUser.nup;
      }
      return true;
    }

    // Participant
    if (m.hidden) return false;
    const isRestricted = m.accessType === 'restricted' || (m.allowedPeserta && m.allowedPeserta.length > 0);
    if (isRestricted) {
      const userNupUpper = (currentUser.nup || '').trim().toUpperCase();
      return (m.allowedPeserta || []).some((n) => n.trim().toUpperCase() === userNupUpper);
    }

    if (m.targetRole && m.targetRole !== 'semua' && m.targetRole !== currentUser.role) {
      return false;
    }

    return true;
  };

  // Folder open click handler
  const handleOpenFolder = (folderName: string) => {
    if (!canUserSeeFolder(folderName)) {
      showToast('Akses Ditolak: Folder ini privat milik trainer lain!', 'error');
      return;
    }
    const lock = getFolderLock(folderName);
    const unlocked = isFolderUnlocked(folderName);

    if (lock?.password && !unlocked) {
      setFolderToUnlock(folderName);
      setAfterUnlockAction(() => () => {
        setCurrentFolderName(folderName);
        setCurrentView('folder');
      });
      setIsModalUnlockOpen(true);
      return;
    }

    setCurrentFolderName(folderName);
    setCurrentView('folder');
  };

  // Open materi click handler
  const handleOpenMateri = (mid: string) => {
    const m = materiList[mid];
    if (!m) return;
    if (!canUserSeeMateri(m)) {
      showToast('Akses Ditolak: Anda tidak memiliki izin untuk materi ini!', 'error');
      return;
    }

    // Check folder password
    if (m.folder && m.folder.trim()) {
      const fn = m.folder.trim();
      const lock = getFolderLock(fn);
      if (lock?.password && !isFolderUnlocked(fn)) {
        handleOpenFolder(fn);
        return;
      }
    }

    setCurrentMateriId(mid);
    setCurrentView('learning');

    // Auto-record attendance if participant
    if (currentUser && !currentUser.isTrainer) {
      if (!absenRecords[mid]?.[currentUser.nup]) {
        const record: AbsenRecord = {
          nama: currentUser.nama,
          nup: currentUser.nup,
          unit: currentUser.unit,
          role: currentUser.role,
          waktu: Date.now()
        };
        setAbsenRecords((prev) => ({
          ...prev,
          [mid]: { ...(prev[mid] || {}), [currentUser.nup]: record }
        }));
        if (db) {
          set(ref(db, `absen/${mid}/${currentUser.nup}`), record).catch(console.error);
        }
      }
    }
  };

  // Drag and drop reorder folders
  const handleReorderFolders = (newOrder: string[]) => {
    setFolderOrder(newOrder);
    setLocalData('folderOrder', newOrder);
    if (db) {
      set(ref(db, 'folderOrder'), newOrder).catch(console.error);
    }
    showToast('Urutan posisi folder tersimpan secara realtime!', 'success');
  };

  // Toggle session done
  const handleToggleSessionDone = (sesiIndex: number) => {
    if (!currentMateriId || !currentUser) return;
    const currentMateri = materiList[currentMateriId];
    if (!currentMateri) return;

    const currentMap = currentMateri.selesaiSesi || {};
    const userMap = currentMap[currentUser.nup] || {};
    const newStatus = !userMap[sesiIndex];

    const updatedUserMap = { ...userMap, [sesiIndex]: newStatus };
    const updatedMateri: Materi = {
      ...currentMateri,
      selesaiSesi: { ...currentMap, [currentUser.nup]: updatedUserMap }
    };

    setMateriList((prev) => ({ ...prev, [currentMateriId]: updatedMateri }));
    setLocalData('materiList', { ...materiList, [currentMateriId]: updatedMateri });

    if (db) {
      set(ref(db, `materi/${currentMateriId}/selesaiSesi/${currentUser.nup}/${sesiIndex}`), newStatus).catch(
        console.error
      );
    }
  };

  // Finish materi & report grade
  const handleFinishMateri = () => {
    if (!currentMateriId || !currentUser) return;
    const currentMateri = materiList[currentMateriId];
    if (!currentMateri) return;

    // Minimum Study Hours Enforcement: 8 Jam / 1 Hari Kerja (8 * 3600 = 28,800 detik)
    const minHours = currentMateri.minimalJam || 8;
    const minRequiredSecs = minHours * 3600;
    const existingSecs = studyTimeRecords[currentMateriId]?.[currentUser.nup]?.totalDetik || 0;
    const userTotalSecs = existingSecs + studySeconds;

    if (!currentUser.isTrainer && !currentUser.isSuperAdmin && userTotalSecs < minRequiredSecs) {
      const remainingSecs = minRequiredSecs - userTotalSecs;
      const remH = Math.floor(remainingSecs / 3600);
      const remM = Math.floor((remainingSecs % 3600) / 60);
      showToast(
        `Durasi belajar belum mencukupi standar ${minHours} Jam (1 Hari Kerja). Sisa waktu: ${remH} Jam ${remM} Menit.`,
        'error'
      );
      return;
    }

    const report: LaporanNilai = {
      nama: currentUser.nama,
      nup: currentUser.nup,
      unit: currentUser.unit,
      role: currentUser.role,
      nilai: 100,
      waktu: Date.now(),
      sertifikatDiterbitkan: true,
      sertifikatNomor: `CERT/${new Date().getFullYear()}/${currentUser.nup}`
    };

    setLaporanRecords((prev) => ({
      ...prev,
      [currentMateriId]: { ...(prev[currentMateriId] || {}), [currentUser.nup]: report }
    }));
    setLocalData('laporanRecords', {
      ...laporanRecords,
      [currentMateriId]: { ...(laporanRecords[currentMateriId] || {}), [currentUser.nup]: report }
    });

    if (db) {
      set(ref(db, `laporan/${currentMateriId}/${currentUser.nup}`), report).catch(console.error);
    }

    showToast(`🎉 Selamat! Anda telah menyelesaikan seluruh sesi dan memenuhi ${minHours} Jam Pembelajaran (1 Hari Kerja). Sertifikat PDF Anda siap diunduh!`, 'success');
  };

  // Add study seconds helper (for demo simulation or acceleration)
  const handleAddStudySeconds = (additionalSeconds: number) => {
    if (!currentMateriId || !currentUser) return;
    setStudySeconds((prev) => prev + additionalSeconds);
    saveStudyTime(currentMateriId, currentUser.nup, additionalSeconds);
    const jamAdded = Math.round(additionalSeconds / 3600);
    showToast(`Waktu pembelajaran berhasil disimulasikan (+${jamAdded > 0 ? `${jamAdded} Jam` : `${Math.round(additionalSeconds / 60)} Menit`})`, 'info');
  };

  // Send chat message
  const handleSendChat = (pesan: string) => {
    if (!currentMateriId || !currentUser) return;
    const msg: ChatMessage = {
      nama: currentUser.nama,
      nup: currentUser.nup,
      pesan,
      timestamp: Date.now()
    };

    if (db) {
      push(ref(db, `chat/${currentMateriId}`), msg).catch(console.error);
    } else {
      const chatList = chatData[currentMateriId] || {};
      const newKey = `local_${Date.now()}`;
      setChatData((prev) => ({
        ...prev,
        [currentMateriId]: { ...chatList, [newKey]: msg }
      }));
    }
  };

  // Save/Create Materi
  const handleSaveMateri = (data: Partial<Materi>, folderPassword?: string) => {
    if (!currentUser) return;
    const isEdit = !!editingMateri?.id;
    const mid = isEdit ? editingMateri!.id : `materi_${Date.now()}`;

    const completeMateri: Materi = {
      ...(isEdit ? editingMateri : {}),
      ...data,
      id: mid,
      judul: data.judul || 'Materi Baru',
      sesi: data.sesi || [],
      ownerTrainerId: editingMateri?.ownerTrainerId || currentUser.nup,
      ownerTrainerName: editingMateri?.ownerTrainerName || currentUser.nama,
      createdAt: editingMateri?.createdAt || Date.now()
    };

    setMateriList((prev) => ({ ...prev, [mid]: completeMateri }));
    setLocalData('materiList', { ...materiList, [mid]: completeMateri });

    if (db) {
      set(ref(db, `materi/${mid}`), completeMateri).catch(console.error);
    }

    // Save folder password if provided
    if (data.folder && folderPassword !== undefined) {
      handleSaveFolderLock(data.folder, folderPassword);
    }

    setIsModalMateriOpen(false);
    setEditingMateri(null);
    showToast(isEdit ? 'Materi berhasil diperbarui!' : 'Materi baru berhasil ditambahkan!', 'success');
  };

  // Delete Materi
  const handleDeleteMateri = (mid: string) => {
    const m = materiList[mid];
    if (!m) return;
    if (!window.confirm(`Hapus materi "${m.judul}"? Tindakan ini tidak dapat dibatalkan.`)) return;

    const nextList = { ...materiList };
    delete nextList[mid];
    setMateriList(nextList);
    setLocalData('materiList', nextList);

    if (db) {
      remove(ref(db, `materi/${mid}`)).catch(console.error);
    }
    showToast('Materi berhasil dihapus.', 'info');
  };

  // Save Folder Lock
  const handleSaveFolderLock = (folderName: string, password: string) => {
    if (!currentUser) return;
    const cleanFn = folderName.trim();
    const key = encodeURIComponent(cleanFn).replace(/\./g, '%2E');

    const lockData: FolderLock = {
      folderName: cleanFn,
      password: password || '',
      ownerNup: currentUser.nup,
      ownerName: currentUser.nama,
      updatedAt: Date.now()
    };

    setFolderLocks((prev) => ({ ...prev, [key]: lockData }));
    setLocalData('folderLocks', { ...folderLocks, [key]: lockData });

    if (db) {
      if (password) {
        set(ref(db, `folderLocks/${key}`), lockData).catch(console.error);
      } else {
        remove(ref(db, `folderLocks/${key}`)).catch(console.error);
      }
    }

    setIsModalFolderLockOpen(false);
    showToast(`Pengaturan kata sandi untuk folder "${cleanFn}" diperbarui!`, 'success');
  };

  // Relock Folder
  const handleRelockFolder = (folderName: string) => {
    const next = { ...unlockedFolders };
    delete next[folderName.trim()];
    setUnlockedFolders(next);
    sessionStorage.setItem('bki_unlocked_folders', JSON.stringify(next));
    showToast(`Folder "${folderName}" berhasil dikunci kembali.`, 'info');
    setCurrentView('home');
  };

  // Save Manual Grade
  const handleSaveManualNilai = (mid: string, nup: string, val: number) => {
    const p = DATABASE_PEGAWAI[nup] || { nama: `Peserta ${nup}`, unit: '-', role: 'umum' };
    const report: LaporanNilai = {
      nama: p.nama,
      nup,
      unit: p.unit,
      role: p.role,
      nilai: val,
      waktu: Date.now(),
      sertifikatDiterbitkan: true,
      sertifikatNomor: `BKI/PPSDM/${new Date().getFullYear()}/${nup}`
    };

    setLaporanRecords((prev) => ({
      ...prev,
      [mid]: { ...(prev[mid] || {}), [nup]: report }
    }));
    setLocalData('laporanRecords', {
      ...laporanRecords,
      [mid]: { ...(laporanRecords[mid] || {}), [nup]: report }
    });

    if (db) {
      set(ref(db, `laporan/${mid}/${nup}`), report).catch(console.error);
    }
    showToast(`Nilai peserta ${p.nama} (${val}) berhasil disimpan!`, 'success');
  };

  // Delete Nilai
  const handleDeleteNilai = (mid: string, nup: string) => {
    if (!window.confirm('Hapus nilai peserta ini?')) return;
    const midReports = { ...(laporanRecords[mid] || {}) };
    delete midReports[nup];
    const nextLaporan = { ...laporanRecords, [mid]: midReports };

    setLaporanRecords(nextLaporan);
    setLocalData('laporanRecords', nextLaporan);
    if (db) {
      remove(ref(db, `laporan/${mid}/${nup}`)).catch(console.error);
    }
    showToast('Data nilai peserta dihapus.', 'info');
  };

  // Delete Absen
  const handleDeleteAbsen = (mid: string, nup: string) => {
    if (!window.confirm('Hapus log absensi peserta ini?')) return;
    const midAbsen = { ...(absenRecords[mid] || {}) };
    delete midAbsen[nup];
    const nextAbsen = { ...absenRecords, [mid]: midAbsen };

    setAbsenRecords(nextAbsen);
    setLocalData('absenRecords', nextAbsen);
    if (db) {
      remove(ref(db, `absen/${mid}/${nup}`)).catch(console.error);
    }
    showToast('Log absensi dihapus.', 'info');
  };

  // Open Certificate Modal Handler
  const handleOpenCertificate = (
    mid: string,
    peserta: { nama: string; nup: string; unit: string; nilai: number }
  ) => {
    const m = materiList[mid];
    setCertificateData({
      materi: m || null,
      peserta
    });
    setIsCertificateModalOpen(true);
  };

  // Logout
  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('bki_currentUser');
    sessionStorage.clear();
    setCurrentView('home');
  };

  // Login
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setLocalData('currentUser', user);
    showToast(`Selamat datang, ${user.nama}!`, 'success');
  };

  // Compute Folders & Ungrouped Materials
  const rawFolderCounts: Record<string, number> = {};
  const ungroupedList: Materi[] = [];

  Object.keys(materiList).forEach((mid) => {
    const m = materiList[mid];
    if (!canUserSeeMateri(m)) return;
    if (m.folder && m.folder.trim()) {
      const fn = m.folder.trim();
      if (!canUserSeeFolder(fn)) return;
      rawFolderCounts[fn] = (rawFolderCounts[fn] || 0) + 1;
    } else {
      ungroupedList.push(m);
    }
  });

  // Sort folders according to folderOrder
  const allFolderNames = Object.keys(rawFolderCounts);
  const sortedFolderNames = [...allFolderNames].sort((a, b) => {
    const indexA = folderOrder.indexOf(a);
    const indexB = folderOrder.indexOf(b);
    if (indexA !== -1 && indexB !== -1) return indexA - indexB;
    if (indexA !== -1) return -1;
    if (indexB !== -1) return 1;
    return a.localeCompare(b);
  });

  const structuredFolders = sortedFolderNames.map((fn) => {
    const lock = getFolderLock(fn);
    const locked = !!lock?.password;
    return {
      name: fn,
      count: rawFolderCounts[fn],
      isLocked: locked,
      lock: {
        isLocked: locked,
        password: lock?.password,
        ownerNup: lock?.ownerNup,
        ownerName: lock?.ownerName
      },
      isUnlockedLocally: isFolderUnlocked(fn)
    };
  });

  // Calculate formatted timer
  const h = Math.floor(studySeconds / 3600);
  const m = Math.floor((studySeconds % 3600) / 60);
  const s = studySeconds % 60;
  const studyTimeFormatted = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;

  // Cumulative study time for active participant on this materi
  const activeUserTotalStudySeconds = ((currentMateriId && currentUser) 
    ? (studyTimeRecords[currentMateriId]?.[currentUser.nup]?.totalDetik || 0) 
    : 0) + studySeconds;

  // Current active learning materi
  const currentLearningMateri = currentMateriId ? materiList[currentMateriId] : null;
  const isCurrentMateriFinished = currentMateriId && currentUser
    ? !!laporanRecords[currentMateriId]?.[currentUser.nup]
    : false;
  const currentChatList = currentMateriId
    ? Object.values(chatData[currentMateriId] || {}).sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0))
    : [];

  // Folder materials for FolderView
  const currentFolderMateriList = currentFolderName
    ? Object.keys(materiList)
        .map((id) => materiList[id])
        .filter((m) => m.folder?.trim().toLowerCase() === currentFolderName.trim().toLowerCase() && canUserSeeMateri(m))
    : [];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 antialiased font-sans">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed top-16 right-4 z-[999] animate-fade-in pointer-events-none">
          <div
            className={`px-4 py-3 rounded-2xl shadow-xl text-white font-bold text-xs flex items-center gap-2 pointer-events-auto ${
              toastMsg.type === 'error'
                ? 'bg-rose-600'
                : toastMsg.type === 'info'
                ? 'bg-slate-800'
                : 'bg-emerald-600'
            }`}
          >
            {toastMsg.text}
          </div>
        </div>
      )}

      {/* Login Overlay if not authenticated */}
      {!currentUser ? (
        <LoginOverlay onLogin={handleLogin} />
      ) : (
        <>
          {/* Top Bar */}
          <TopBar
            currentUser={currentUser}
            onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
            onNavigateHome={() => {
              setCurrentView('home');
              setCurrentFolderName(null);
            }}
            onLogout={handleLogout}
          />

          {/* Sidebar */}
          <Sidebar
            currentUser={currentUser}
            currentView={currentView}
            currentFolderName={currentFolderName}
            onNavigate={(view, fn) => {
              if (view === 'folder' && fn) {
                handleOpenFolder(fn);
              } else {
                setCurrentView(view as any);
                setCurrentFolderName(null);
              }
            }}
            folderList={structuredFolders}
            onLogout={handleLogout}
            isSidebarOpen={isSidebarOpen}
            setIsSidebarOpen={setIsSidebarOpen}
          />

          {/* Main Content Area */}
          <main className="md:ml-64 pt-14 min-h-screen">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-6 md:py-8">
              {currentView === 'home' && (
                <HomeView
                  currentUser={currentUser}
                  folders={structuredFolders}
                  ungroupedMateri={ungroupedList}
                  onOpenFolder={handleOpenFolder}
                  onOpenMateri={handleOpenMateri}
                  onReorderFolders={handleReorderFolders}
                />
              )}

              {currentView === 'folder' && currentFolderName && (
                <FolderView
                  folderName={currentFolderName}
                  materiList={currentFolderMateriList}
                  folderLock={getFolderLock(currentFolderName)}
                  currentUser={currentUser}
                  onBack={() => {
                    setCurrentView('home');
                    setCurrentFolderName(null);
                  }}
                  onOpenMateri={handleOpenMateri}
                  onRelockFolder={handleRelockFolder}
                  onManageFolderLock={(fn) => {
                    setFolderLockTarget(fn);
                    setIsModalFolderLockOpen(true);
                  }}
                />
              )}

              {currentView === 'learning' && currentLearningMateri && (
                <LearningView
                  materi={currentLearningMateri}
                  currentUser={currentUser}
                  onBack={() => {
                    if (currentFolderName) {
                      setCurrentView('folder');
                    } else {
                      setCurrentView('home');
                    }
                  }}
                  onToggleSessionDone={handleToggleSessionDone}
                  onFinishMateri={handleFinishMateri}
                  onOpenCertificate={() => {
                    handleOpenCertificate(currentLearningMateri.id, {
                      nama: currentUser.nama,
                      nup: currentUser.nup,
                      unit: currentUser.unit,
                      nilai: laporanRecords[currentLearningMateri.id]?.[currentUser.nup]?.nilai || 100
                    });
                  }}
                  isFinished={isCurrentMateriFinished}
                  chatMessages={currentChatList}
                  onSendChat={handleSendChat}
                  studyTimeFormatted={studyTimeFormatted}
                  totalStudySeconds={activeUserTotalStudySeconds}
                  onAddStudySeconds={handleAddStudySeconds}
                />
              )}

              {currentView === 'admin' && currentUser.isTrainer && (
                <TrainerPanel
                  currentUser={currentUser}
                  materiList={materiList}
                  folderLocks={folderLocks}
                  laporanRecords={laporanRecords}
                  absenRecords={absenRecords}
                  studyTimeRecords={studyTimeRecords}
                  onOpenAddMateri={() => {
                    setEditingMateri(null);
                    setIsModalMateriOpen(true);
                  }}
                  onOpenEditMateri={(mid) => {
                    setEditingMateri(materiList[mid] || null);
                    setIsModalMateriOpen(true);
                  }}
                  onDeleteMateri={handleDeleteMateri}
                  onOpenFolderLockModal={(fn) => {
                    setFolderLockTarget(fn);
                    setIsModalFolderLockOpen(true);
                  }}
                  onOpenDetailPeserta={(mid) => {
                    setDetailPesertaMateriId(mid);
                    setIsModalDetailPesertaOpen(true);
                  }}
                  onOpenCertificateModal={(mid, peserta) => {
                    handleOpenCertificate(mid, peserta);
                  }}
                  onDeleteNilai={handleDeleteNilai}
                  onDeleteAbsen={handleDeleteAbsen}
                  onOpenInputNilaiModal={() => setIsModalInputNilaiOpen(true)}
                />
              )}
            </div>
          </main>

          {/* MODALS */}
          {/* Modal Tambah / Edit Materi with Session Reordering & Word Editor */}
          <ModalMateri
            isOpen={isModalMateriOpen}
            onClose={() => {
              setIsModalMateriOpen(false);
              setEditingMateri(null);
            }}
            onSave={handleSaveMateri}
            initialData={editingMateri}
            currentUser={currentUser}
            existingFolders={allFolderNames}
          />

          {/* Modal Kelola Kunci Folder */}
          <ModalFolderLock
            isOpen={isModalFolderLockOpen}
            onClose={() => setIsModalFolderLockOpen(false)}
            folderName={folderLockTarget}
            currentLock={getFolderLock(folderLockTarget)}
            onSave={handleSaveFolderLock}
            ownerName={getFolderLock(folderLockTarget)?.ownerName || currentUser.nama}
          />

          {/* Modal Buka Kunci Folder */}
          <ModalUnlockFolder
            isOpen={isModalUnlockOpen}
            onClose={() => {
              setIsModalUnlockOpen(false);
              setAfterUnlockAction(null);
            }}
            folderName={folderToUnlock}
            ownerName={getFolderLock(folderToUnlock)?.ownerName || 'Trainer'}
            expectedPassword={getFolderLock(folderToUnlock)?.password}
            onSuccess={() => {
              const updated = { ...unlockedFolders, [folderToUnlock.trim()]: true };
              setUnlockedFolders(updated);
              sessionStorage.setItem('bki_unlocked_folders', JSON.stringify(updated));
              setIsModalUnlockOpen(false);
              showToast(`Kunci folder "${folderToUnlock}" berhasil dibuka!`, 'success');
              if (afterUnlockAction) {
                afterUnlockAction();
                setAfterUnlockAction(null);
              }
            }}
          />

          {/* Modal Detail Peserta Materi */}
          <ModalDetailPeserta
            isOpen={isModalDetailPesertaOpen}
            onClose={() => {
              setIsModalDetailPesertaOpen(false);
              setDetailPesertaMateriId(null);
            }}
            materi={detailPesertaMateriId ? materiList[detailPesertaMateriId] : null}
            absenRecords={detailPesertaMateriId ? absenRecords[detailPesertaMateriId] || {} : {}}
            laporanRecords={detailPesertaMateriId ? laporanRecords[detailPesertaMateriId] || {} : {}}
            onEditPeserta={(mid) => {
              setIsModalDetailPesertaOpen(false);
              setEditingMateri(materiList[mid] || null);
              setIsModalMateriOpen(true);
            }}
            onOpenCertificate={(peserta) => {
              if (detailPesertaMateriId) {
                handleOpenCertificate(detailPesertaMateriId, peserta);
              }
            }}
            canManage={
              currentUser.isSuperAdmin ||
              (detailPesertaMateriId && materiList[detailPesertaMateriId]?.ownerTrainerId === currentUser.nup) ||
              false
            }
          />

          {/* Modal Input Nilai Manual */}
          <ModalInputNilai
            isOpen={isModalInputNilaiOpen}
            onClose={() => setIsModalInputNilaiOpen(false)}
            materiList={materiList}
            onSave={handleSaveManualNilai}
          />

          {/* Certificate Modal */}
          <CertificateModal
            isOpen={isCertificateModalOpen}
            onClose={() => setIsCertificateModalOpen(false)}
            materi={certificateData.materi}
            peserta={certificateData.peserta}
            onSaveCertificate={({ nomor }) => {
              showToast(`Sertifikat No. ${nomor} berhasil diekspor!`, 'success');
            }}
          />
        </>
      )}
    </div>
  );
}
