export interface TrainerAccount {
  nup: string;
  nama: string;
  pin: string;
  role: 'trainer' | 'superadmin';
  spesialis: string;
}

export const DAFTAR_TRAINER: TrainerAccount[] = [
  { nup: 'TRAINER-01', nama: 'Trainer 01', pin: 'ppsdm01', role: 'trainer', spesialis: 'Pengajar Senior Maritim & K3' },
  { nup: 'TRAINER-02', nama: 'Trainer 02', pin: 'ppsdm02', role: 'trainer', spesialis: 'Pengajar Konstruksi & Desain Kapal' },
  { nup: 'TRAINER-03', nama: 'Trainer 03', pin: '330303', role: 'trainer', spesialis: 'Pengajar Statutoria & Regulasi IMO' },
  { nup: 'TRAINER-04', nama: 'Trainer 04', pin: '440404', role: 'trainer', spesialis: 'Pengajar Material & Pengelasan Logam' },
  { nup: 'TRAINER-05', nama: 'Trainer 05', pin: '550505', role: 'trainer', spesialis: 'Pengajar Sistem Kelistrikan & Mesin Kapal' },
  { nup: 'DIKLAT-ADMIN', nama: 'Administrator Utama', pin: '000000', role: 'superadmin', spesialis: 'Super Admin Diklat PPSDM BKI' }
];
