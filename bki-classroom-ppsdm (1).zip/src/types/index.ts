export type UserRole = 'umum' | 'reguler' | 'trainer' | 'superadmin';

export interface User {
  nup: string;
  nama: string;
  unit: string;
  role: UserRole;
  isTrainer: boolean;
  isSuperAdmin: boolean;
}

export interface Pegawai {
  nama: string;
  unit: string;
  role: 'umum' | 'reguler';
}

export interface SesiMateri {
  judul: string;
  link?: string;
  konten?: string; // Rich text Word-like content
  durasi?: string;
}

export interface Materi {
  id: string;
  judul: string;
  folder?: string;
  targetRole?: 'semua' | 'umum' | 'reguler';
  accessType?: 'all' | 'restricted';
  allowedPeserta?: string[]; // NUP array
  gambar?: string;
  hidden?: boolean;
  sesi: SesiMateri[];
  minimalJam?: number; // Minimal waktu pembelajaran dalam jam (default: 8 jam / 1 hari kerja)
  ownerTrainerId?: string;
  ownerTrainerName?: string;
  createdAt?: number;
  selesaiSesi?: Record<string, Record<number, boolean>>; // [nup][sesiIndex]
}

export interface FolderLock {
  folderName: string;
  password?: string;
  ownerNup?: string;
  ownerName?: string;
  updatedAt?: number;
}

export interface AbsenRecord {
  nama: string;
  nup: string;
  unit: string;
  role: string;
  waktu: number;
}

export interface LaporanNilai {
  nama: string;
  nup: string;
  unit: string;
  role: string;
  nilai: number;
  waktu: number;
  sertifikatNomor?: string;
  sertifikatDiterbitkan?: boolean;
}

export interface StudyTimeRecord {
  nama: string;
  unit: string;
  totalDetik: number;
  sesiCount: number;
  lastSeen: number;
}

export interface ChatMessage {
  id?: string;
  nama: string;
  nup: string;
  pesan: string;
  timestamp: number;
}

export type CertificatePresetTheme = 'gold' | 'navy' | 'modern' | 'custom';

export interface ElementPosition {
  x: number;
  y: number;
}

export interface CertificateConfig {
  id?: string;
  materiId: string;
  materiJudul: string;
  presetTheme: CertificatePresetTheme;
  orientation: 'landscape' | 'portrait';
  customTemplateImage?: string; // Data URL or Image URL
  nomorFormat: string; // e.g. "CERT/{YYYY}/{NUP}"
  judulSertifikat: string; // "SERTIFIKAT KELULUSAN"
  subJudul: string; // "Diberikan dengan bangga kepada:"
  deskripsiPencapaian: string; // "Atas keberhasilan dan dedikasi dalam menyelesaikan seluruh rangkaian pelatihan..."
  materiRichText?: string; // Rich text Word-like syllabus / materi pelatihan yang diselesaikan
  showMateriDetails?: boolean; // Toggle to display rich text syllabus on certificate
  penandatanganNama: string; // "Dr. Ir. Hendra Gunawan, M.T."
  penandatanganJabatan: string; // "Direktur Pelatihan & Kompetensi"
  penandatanganNama2?: string;
  penandatanganJabatan2?: string;
  tandaTanganUrl?: string;
  stempelUrl?: string;
  showQrCode: boolean;
  showNilai: boolean;
  tanggalTerbit: string; // "26 Oktober 2026"
  // Posisi Elemen Kustom (Dapat digeser manual langsung di preview)
  elementPositions?: Record<string, ElementPosition>;
  // Posisi & Warna Kustom
  textColorPrimary?: string;
  textColorSecondary?: string;
  textColorAccent?: string;
  fontFamilyTitle?: string;
}

export interface IssuedCertificate {
  id: string;
  nomor: string;
  materiId: string;
  materiJudul: string;
  nup: string;
  namaPeserta: string;
  unit: string;
  nilai: number;
  predikat: string;
  tanggalTerbit: string;
  config: CertificateConfig;
  issuedAt: number;
}
