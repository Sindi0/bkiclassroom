import React, { useState } from 'react';
import { 
  Folder, 
  Lock, 
  Unlock, 
  ArrowRight, 
  GripHorizontal, 
  ChevronLeft, 
  ChevronRight, 
  User as UserIcon, 
  Check, 
  Sparkles 
} from 'lucide-react';
import { FolderLock } from '../types';

interface DragDropFolderGridProps {
  folders: {
    name: string;
    count: number;
    lock: {
      isLocked: boolean;
      password?: string;
      ownerNup?: string;
      ownerName?: string;
    };
    isUnlockedLocally: boolean;
  }[];
  onOpenFolder: (folderName: string) => void;
  onReorderFolders: (newOrder: string[]) => void;
  canManageOrder?: boolean;
}

export const DragDropFolderGrid: React.FC<DragDropFolderGridProps> = ({
  folders,
  onOpenFolder,
  onReorderFolders,
  canManageOrder = true
}) => {
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const [showOrderSaved, setShowOrderSaved] = useState(false);

  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverIndex !== index) {
      setDragOverIndex(index);
    }
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === targetIndex) {
      setDraggedIndex(null);
      setDragOverIndex(null);
      return;
    }

    const items = [...folders];
    const [moved] = items.splice(draggedIndex, 1);
    items.splice(targetIndex, 0, moved);

    const newOrder = items.map((f) => f.name);
    onReorderFolders(newOrder);

    setDraggedIndex(null);
    setDragOverIndex(null);
    setShowOrderSaved(true);
    setTimeout(() => setShowOrderSaved(false), 2000);
  };

  const moveFolder = (currentIndex: number, direction: 'left' | 'right') => {
    const targetIndex = direction === 'left' ? currentIndex - 1 : currentIndex + 1;
    if (targetIndex < 0 || targetIndex >= folders.length) return;

    const items = [...folders];
    const [moved] = items.splice(currentIndex, 1);
    items.splice(targetIndex, 0, moved);

    const newOrder = items.map((f) => f.name);
    onReorderFolders(newOrder);

    setShowOrderSaved(true);
    setTimeout(() => setShowOrderSaved(false), 2000);
  };

  if (!folders.length) return null;

  return (
    <div className="space-y-3">
      {/* Interactive Helper Toolbar */}
      <div className="flex items-center justify-between text-xs">
        <span className="text-slate-500 font-semibold flex items-center gap-1.5">
          <GripHorizontal className="w-3.5 h-3.5 text-indigo-600" />
          <span>Tarik / Geser kartu folder untuk menyesuaikan posisi di dashboard</span>
        </span>
        {showOrderSaved && (
          <span className="text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full font-bold text-[11px] flex items-center gap-1 animate-fade-in shadow-2xs">
            <Check className="w-3 h-3 text-emerald-600" /> Posisi folder tersimpan
          </span>
        )}
      </div>

      {/* Grid of Folders with Smooth Layout Transitions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {folders.map((item, index) => {
          const isBeingDragged = draggedIndex === index;
          const isDragTarget = dragOverIndex === index && draggedIndex !== index;

          return (
            <div
              key={item.name}
              draggable={canManageOrder}
              onDragStart={(e) => handleDragStart(e, index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDrop={(e) => handleDrop(e, index)}
              onDragEnd={() => {
                setDraggedIndex(null);
                setDragOverIndex(null);
              }}
              className={`relative bg-white rounded-2xl p-5 border transition-all duration-300 ease-out group select-none ${
                isBeingDragged
                  ? 'opacity-40 scale-95 border-indigo-400 shadow-2xl rotate-1 cursor-grabbing'
                  : isDragTarget
                  ? 'border-indigo-600 ring-2 ring-indigo-300 scale-[1.02] shadow-xl bg-indigo-50/30'
                  : 'border-slate-200 hover:border-indigo-400 hover:shadow-lg hover:-translate-y-0.5 cursor-pointer'
              }`}
            >
              {/* Drag Handle & Position Indicator */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl shadow-xs group-hover:scale-110 group-hover:bg-amber-100 transition-all">
                    <Folder className="w-6 h-6 fill-amber-500 text-amber-600" />
                  </div>
                  {canManageOrder && (
                    <span 
                      className="text-slate-300 group-hover:text-slate-500 hover:text-indigo-600 p-1 cursor-grab active:cursor-grabbing transition-colors"
                      title="Tahan & tarik untuk mengatur posisi folder"
                    >
                      <GripHorizontal className="w-4 h-4" />
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  {item.lock.isLocked ? (
                    item.isUnlockedLocally ? (
                      <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1">
                        <Unlock className="w-2.5 h-2.5" /> Terbuka
                      </span>
                    ) : (
                      <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-1 shadow-2xs">
                        <Lock className="w-2.5 h-2.5" /> Terkunci
                      </span>
                    )
                  ) : (
                    <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                      Umum
                    </span>
                  )}
                </div>
              </div>

              {/* Title & Owner */}
              <div onClick={() => onOpenFolder(item.name)}>
                <h4 className="font-bold text-sm text-slate-900 group-hover:text-indigo-600 transition-colors uppercase leading-snug line-clamp-1">
                  {item.name}
                </h4>

                {item.lock.ownerName && (
                  <p className="text-[11px] text-slate-400 mt-1 flex items-center gap-1 truncate font-medium">
                    <UserIcon className="w-3 h-3 text-slate-400 shrink-0" />
                    <span className="truncate">{item.lock.ownerName}</span>
                  </p>
                )}
              </div>

              {/* Bottom Info Bar & Manual Move Controls */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400 font-semibold">
                <span onClick={() => onOpenFolder(item.name)} className="hover:text-slate-700">
                  {item.count} Materi Modul
                </span>

                <div className="flex items-center gap-1">
                  {/* Manual move arrows for accessible and touch devices */}
                  {canManageOrder && (
                    <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg p-0.5 mr-1 shadow-2xs opacity-70 group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        disabled={index === 0}
                        onClick={(e) => {
                          e.stopPropagation();
                          moveFolder(index, 'left');
                        }}
                        className="p-1 hover:bg-white rounded hover:text-indigo-600 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                        title="Geser posisi ke kiri / atas"
                      >
                        <ChevronLeft className="w-3 h-3" />
                      </button>
                      <button
                        type="button"
                        disabled={index === folders.length - 1}
                        onClick={(e) => {
                          e.stopPropagation();
                          moveFolder(index, 'right');
                        }}
                        className="p-1 hover:bg-white rounded hover:text-indigo-600 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                        title="Geser posisi ke kanan / bawah"
                      >
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => onOpenFolder(item.name)}
                    className="p-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 transition-colors"
                    title="Buka Folder"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
