import React from 'react';
import { 
  GraduationCap, 
  Home, 
  Folder, 
  Lock, 
  Unlock, 
  Presentation, 
  LogOut, 
  Menu, 
  X, 
  User as UserIcon,
  Award
} from 'lucide-react';
import { User, FolderLock } from '../types';

interface NavigationProps {
  currentUser: User;
  currentView: string;
  currentFolderName: string | null;
  onNavigate: (view: string, folderName?: string) => void;
  folderList: {
    name: string;
    count: number;
    isLocked: boolean;
    isUnlockedLocally: boolean;
  }[];
  onLogout: () => void;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (isOpen: boolean) => void;
}

export const TopBar: React.FC<{
  currentUser: User;
  onToggleSidebar: () => void;
  onNavigateHome: () => void;
  onLogout: () => void;
}> = ({ currentUser, onToggleSidebar, onNavigateHome, onLogout }) => {
  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-white/95 backdrop-blur-md border-b border-slate-200 z-40 flex items-center px-4 gap-3">
      <button
        type="button"
        onClick={onToggleSidebar}
        className="md:hidden w-10 h-10 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-600 transition-colors"
      >
        <Menu className="w-5 h-5" />
      </button>

      <div
        onClick={onNavigateHome}
        className="flex items-center gap-2.5 cursor-pointer hover:opacity-90 transition-opacity"
      >
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-xs">
          <GraduationCap className="w-5 h-5" />
        </div>
        <div>
          <span className="font-black text-base tracking-tight text-slate-900">bki Classroom</span>
          <span className="hidden sm:inline-block ml-2 text-[10px] font-black uppercase tracking-widest text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full border border-indigo-100">
            PPSDM
          </span>
        </div>
      </div>

      <div className="flex-1" />

      {/* User Info & Logout */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center text-xs font-bold shadow-xs">
          {currentUser.nama ? currentUser.nama.charAt(0).toUpperCase() : '?'}
        </div>
        <div className="hidden sm:block text-right">
          <p className="text-xs font-bold text-slate-800 leading-tight truncate max-w-[150px]">
            {currentUser.nama}
          </p>
          <p className="text-[10px] font-semibold text-slate-400 leading-tight uppercase font-mono">
            {currentUser.isTrainer ? 'TRAINER DIKLAT' : `NUP: ${currentUser.nup}`}
          </p>
        </div>
        <button
          type="button"
          onClick={onLogout}
          className="text-slate-400 hover:text-rose-600 p-2 rounded-xl hover:bg-rose-50 transition-colors"
          title="Keluar dari akun"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};

export const Sidebar: React.FC<NavigationProps> = ({
  currentUser,
  currentView,
  currentFolderName,
  onNavigate,
  folderList,
  isSidebarOpen,
  setIsSidebarOpen
}) => {
  return (
    <>
      {/* Mobile Backdrop */}
      {isSidebarOpen && (
        <div
          onClick={() => setIsSidebarOpen(false)}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs z-40 md:hidden"
        />
      )}

      {/* Sidebar Content */}
      <aside
        className={`fixed left-0 top-14 bottom-0 w-64 bg-white border-r border-slate-200 z-40 flex flex-col transition-transform duration-300 ease-out md:translate-x-0 ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex-1 overflow-y-auto py-3 custom-scroll">
          {/* Main Navigation */}
          <div
            onClick={() => {
              onNavigate('home');
              setIsSidebarOpen(false);
            }}
            className={`flex items-center gap-3 px-5 py-2.5 cursor-pointer text-xs font-bold border-l-4 transition-all ${
              currentView === 'home'
                ? 'bg-indigo-50 text-indigo-700 border-indigo-600'
                : 'border-transparent text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>Beranda Materi</span>
          </div>

          {/* Folder Categories */}
          {folderList.length > 0 && (
            <div className="mt-4">
              <div className="px-5 pb-1 text-[10px] font-black uppercase tracking-wider text-slate-400">
                Kategori & Folder
              </div>
              {folderList.map((f) => {
                const isActive = currentView === 'folder' && currentFolderName === f.name;
                return (
                  <div
                    key={f.name}
                    onClick={() => {
                      onNavigate('folder', f.name);
                      setIsSidebarOpen(false);
                    }}
                    className={`flex items-center gap-2.5 px-5 py-2 cursor-pointer text-xs font-semibold border-l-4 transition-all ${
                      isActive
                        ? 'bg-indigo-50 text-indigo-700 border-indigo-600'
                        : 'border-transparent text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <Folder className="w-3.5 h-3.5 text-amber-500 fill-amber-500/20 shrink-0" />
                    <span className="truncate flex-1 font-medium">{f.name}</span>
                    {f.isLocked && (
                      f.isUnlockedLocally ? (
                        <Unlock className="w-3 h-3 text-amber-500 shrink-0" />
                      ) : (
                        <Lock className="w-3 h-3 text-rose-500 shrink-0" />
                      )
                    )}
                    <span className="text-[10px] text-slate-400 font-bold ml-1 font-mono">{f.count}</span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Trainer Panel Link */}
          {currentUser.isTrainer && (
            <div className="mt-4 pt-3 border-t border-slate-100">
              <div
                onClick={() => {
                  onNavigate('admin');
                  setIsSidebarOpen(false);
                }}
                className={`flex items-center gap-3 px-5 py-2.5 cursor-pointer text-xs font-bold border-l-4 transition-all ${
                  currentView === 'admin'
                    ? 'bg-indigo-50 text-indigo-700 border-indigo-600'
                    : 'border-transparent text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Presentation className="w-4 h-4 text-indigo-600" />
                <span>Panel Trainer</span>
              </div>
            </div>
          )}
        </div>

        {/* User Card Footer */}
        <div className="p-3 border-t border-slate-200 bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs">
              {currentUser.nama ? currentUser.nama.charAt(0).toUpperCase() : '?'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-800 truncate">{currentUser.nama}</p>
              <p className="text-[10px] text-slate-400 font-mono truncate uppercase">{currentUser.unit}</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
