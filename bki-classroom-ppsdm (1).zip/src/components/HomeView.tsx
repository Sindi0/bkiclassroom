import React from 'react';
import { ShieldCheck, BookOpen, FolderOpen, Award, CheckCircle2 } from 'lucide-react';
import { Materi, User } from '../types';
import { DragDropFolderGrid } from './DragDropFolderGrid';

interface HomeViewProps {
  currentUser: User;
  folders: {
    name: string;
    count: number;
    lock: {
      isLocked: boolean;
      password?: string;
      ownerNup?: string;
      ownerName?: string;
    };
    isUnlockedLocally: boolean;
  }[];
  ungroupedMateri: Materi[];
  onOpenFolder: (folderName: string) => void;
  onOpenMateri: (materiId: string) => void;
  onReorderFolders: (newOrder: string[]) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  currentUser,
  folders,
  ungroupedMateri,
  onOpenFolder,
  onOpenMateri,
  onReorderFolders
}) => {
  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* Role Banner */}
      <div className="rounded-3xl p-5 bg-white border border-slate-200 shadow-xs flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-black text-slate-900 uppercase tracking-wide">
              Selamat Datang, {currentUser.nama}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {currentUser.isTrainer
                ? currentUser.isSuperAdmin
                  ? 'Otorisasi: Administrator Utama Diklat PPSDM BKI'
                  : `Otorisasi: ${currentUser.nama} (Akses Privat Pengajar)`
                : `Akses Peserta: Kategori ${(currentUser.role || 'umum').toUpperCase()} • Unit: ${currentUser.unit}`}
            </p>
          </div>
        </div>

        <span
          className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
            currentUser.isSuperAdmin
              ? 'bg-purple-100 text-purple-800 border border-purple-200'
              : currentUser.isTrainer
              ? 'bg-rose-100 text-rose-800 border border-rose-200'
              : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
          }`}
        >
          {currentUser.isSuperAdmin
            ? 'SUPER ADMIN'
            : currentUser.isTrainer
            ? 'TRAINER PPSDM'
            : `PESERTA ${(currentUser.role || 'UMUM').toUpperCase()}`}
        </span>
      </div>

      {/* Folders Section with Drag and Drop Reordering */}
      {folders.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Kategori & Folder Materi
            </h3>
            <span className="text-xs text-slate-400 font-semibold">
              {folders.length} Folder Terorganisir
            </span>
          </div>

          <DragDropFolderGrid
            folders={folders}
            onOpenFolder={onOpenFolder}
            onReorderFolders={onReorderFolders}
            canManageOrder={true}
          />
        </section>
      )}

      {/* Ungrouped Materi Section */}
      {ungroupedMateri.length > 0 && (
        <section className="space-y-4">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-indigo-600" /> Materi Pembelajaran Mandiri
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {ungroupedMateri.map((m) => {
              const totalSessions = m.sesi?.length || 0;
              const userDone = m.selesaiSesi?.[currentUser.nup] || {};
              const doneCount = Object.keys(userDone).filter((k) => userDone[Number(k)]).length;
              const pct = totalSessions > 0 ? Math.round((doneCount / totalSessions) * 100) : 0;
              const isRestricted = m.accessType === 'restricted' || (m.allowedPeserta && m.allowedPeserta.length > 0);

              return (
                <div
                  key={m.id}
                  onClick={() => onOpenMateri(m.id)}
                  className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-xl hover:border-indigo-400 transition-all cursor-pointer group"
                >
                  <div className="relative h-40 bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-900 overflow-hidden">
                    {m.gambar && (
                      <img
                        src={m.gambar}
                        alt={m.judul}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent" />
                    
                    <div className="absolute top-3 left-3 flex items-center gap-1.5">
                      <span className="bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full text-[10px] font-black text-white uppercase">
                        {m.folder || 'Umum'}
                      </span>
                      {isRestricted && (
                        <span className="bg-violet-600/90 backdrop-blur-md px-2 py-0.5 rounded-full text-[9px] font-black text-white uppercase">
                          Khusus
                        </span>
                      )}
                    </div>

                    <div className="absolute bottom-3 left-3 right-3">
                      <h4 className="text-white font-black text-sm uppercase leading-tight line-clamp-2 drop-shadow-md">
                        {m.judul}
                      </h4>
                    </div>
                  </div>

                  <div className="p-4 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400 font-bold">
                        {doneCount}/{totalSessions} Sesi Selesai
                      </span>
                      <span className={`font-black ${pct === 100 ? 'text-emerald-600' : 'text-indigo-600'}`}>
                        {pct}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          pct === 100 ? 'bg-emerald-500' : 'bg-indigo-600'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Empty State */}
      {folders.length === 0 && ungroupedMateri.length === 0 && (
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
          <div className="w-16 h-16 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <FolderOpen className="w-8 h-8" />
          </div>
          <h4 className="text-sm font-bold text-slate-700">Belum Ada Materi Pelatihan</h4>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Belum ada modul pelatihan yang dapat diakses dengan akun Anda saat ini. Hubungi trainer atau administrator untuk hak akses.
          </p>
        </div>
      )}
    </div>
  );
};
