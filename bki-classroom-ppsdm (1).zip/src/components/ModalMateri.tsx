import React, { useState, useEffect } from 'react';
import { 
  X, 
  Save, 
  Users, 
  UserCheck, 
  Search, 
  Plus, 
  Lock, 
  Image as ImageIcon,
  CheckCircle2,
  FileText,
  Clock
} from 'lucide-react';
import { Materi, SesiMateri, User } from '../types';
import { DATABASE_PEGAWAI } from '../data/databasePegawai';
import { SessionReorderList } from './SessionReorderList';

interface ModalMateriProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (materiData: Partial<Materi>, folderPassword?: string) => void;
  initialData?: Materi | null;
  currentUser: User;
  existingFolders: string[];
}

export const ModalMateri: React.FC<ModalMateriProps> = ({
  isOpen,
  onClose,
  onSave,
  initialData,
  currentUser,
  existingFolders
}) => {
  const [judul, setJudul] = useState('');
  const [folder, setFolder] = useState('');
  const [folderPassword, setFolderPassword] = useState('');
  const [targetRole, setTargetRole] = useState<'semua' | 'umum' | 'reguler'>('semua');
  const [accessType, setAccessType] = useState<'all' | 'restricted'>('all');
  const [allowedPeserta, setAllowedPeserta] = useState<string[]>([]);
  const [gambar, setGambar] = useState('');
  const [hidden, setHidden] = useState(false);
  const [minimalJam, setMinimalJam] = useState<number>(8);
  const [sessions, setSessions] = useState<SesiMateri[]>([
    { judul: 'Sesi 1: Pengenalan & Dasar Teori', link: '', konten: '' }
  ]);

  // Peserta picker search & tab
  const [pickerSearch, setPickerSearch] = useState('');
  const [pickerTab, setPickerTab] = useState<'all' | 'selected'>('all');
  const [customNupInput, setCustomNupInput] = useState('');

  useEffect(() => {
    if (initialData) {
      setJudul(initialData.judul || '');
      setFolder(initialData.folder || '');
      setFolderPassword('');
      setTargetRole(initialData.targetRole || 'semua');
      setAccessType(initialData.accessType || (initialData.allowedPeserta?.length ? 'restricted' : 'all'));
      setAllowedPeserta(initialData.allowedPeserta || []);
      setGambar(initialData.gambar || '');
      setHidden(!!initialData.hidden);
      setMinimalJam(initialData.minimalJam ?? 8);
      setSessions(
        initialData.sesi?.length
          ? initialData.sesi
          : [{ judul: 'Sesi 1: Pengenalan & Dasar Teori', link: '', konten: '' }]
      );
    } else {
      setJudul('');
      setFolder('');
      setFolderPassword('');
      setTargetRole('semua');
      setAccessType('all');
      setAllowedPeserta([]);
      setGambar('');
      setHidden(false);
      setMinimalJam(8);
      setSessions([{ judul: 'Sesi 1: Pengenalan & Dasar Teori', link: '', konten: '' }]);
    }
    setPickerSearch('');
    setPickerTab('all');
  }, [initialData, isOpen]);

  if (!isOpen) return null;

  // Toggle selection of a participant
  const togglePeserta = (nup: string) => {
    const cleanNup = nup.trim().toUpperCase();
    if (allowedPeserta.includes(cleanNup)) {
      setAllowedPeserta(allowedPeserta.filter((n) => n !== cleanNup));
    } else {
      setAllowedPeserta([...allowedPeserta, cleanNup]);
    }
  };

  const addCustomNup = () => {
    const clean = customNupInput.trim().toUpperCase();
    if (!clean) return;
    if (!allowedPeserta.includes(clean)) {
      setAllowedPeserta([...allowedPeserta, clean]);
    }
    setCustomNupInput('');
  };

  const handleSelectAllVisible = (filteredNups: string[]) => {
    const combined = Array.from(new Set([...allowedPeserta, ...filteredNups]));
    setAllowedPeserta(combined);
  };

  const handleClearAll = () => {
    setAllowedPeserta([]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!judul.trim()) {
      alert('Judul materi wajib diisi!');
      return;
    }
    if (!sessions.length || !sessions[0].judul.trim()) {
      alert('Tambahkan minimal 1 sesi materi pembelajaran!');
      return;
    }
    if (accessType === 'restricted' && !allowedPeserta.length) {
      alert('Pilih minimal 1 peserta untuk materi dengan hak akses terbatas!');
      return;
    }

    const materiPayload: Partial<Materi> = {
      judul: judul.trim(),
      folder: folder.trim(),
      targetRole,
      accessType,
      allowedPeserta: accessType === 'restricted' ? allowedPeserta : [],
      gambar: gambar.trim(),
      hidden,
      minimalJam: Number(minimalJam) || 8,
      sesi: sessions,
      ownerTrainerId: initialData?.ownerTrainerId || currentUser.nup,
      ownerTrainerName: initialData?.ownerTrainerName || currentUser.nama
    };

    onSave(materiPayload, folderPassword.trim());
  };

  // Compile full employee list
  const allPegawaiKeys = Object.keys(DATABASE_PEGAWAI);
  const q = pickerSearch.toLowerCase().trim();
  const filteredPegawai = allPegawaiKeys.filter((nup) => {
    if (pickerTab === 'selected' && !allowedPeserta.includes(nup)) return false;
    if (!q) return true;
    const p = DATABASE_PEGAWAI[nup];
    return nup.toLowerCase().includes(q) || p.nama.toLowerCase().includes(q) || p.unit.toLowerCase().includes(q);
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="font-black text-base text-slate-900 uppercase tracking-tight">
              {initialData ? 'Edit Materi Pembelajaran' : 'Tambah Materi Baru'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Trainer Pemilik: <span className="font-bold text-indigo-600">{currentUser.nama}</span> ({currentUser.nup})
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl hover:bg-slate-200 text-slate-400 hover:text-slate-700 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5 custom-scroll">
          {/* Judul & Folder */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Judul Materi *</label>
              <input
                type="text"
                required
                value={judul}
                onChange={(e) => setJudul(e.target.value)}
                placeholder="Contoh: K3 Dasar Kelautan & Galangan"
                className="w-full border-2 border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold bg-slate-50 focus:bg-white outline-none focus:border-indigo-600 transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Folder / Kategori</label>
              <input
                type="text"
                list="existing-folders"
                value={folder}
                onChange={(e) => setFolder(e.target.value)}
                placeholder="Contoh: Modul K3"
                className="w-full border-2 border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold bg-slate-50 focus:bg-white outline-none focus:border-indigo-600 transition-all"
              />
              <datalist id="existing-folders">
                {existingFolders.map((f) => (
                  <option key={f} value={f} />
                ))}
              </datalist>
            </div>
          </div>

          {/* Durasi Waktu Pembelajaran Minimal (8 Jam / 1 Hari Kerja) */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between gap-4 flex-wrap sm:flex-nowrap">
            <div>
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-indigo-600" /> Waktu Pembelajaran Minimal (Syarat Kelulusan)
              </label>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Standar durasi: <strong>8 Jam Pembelajaran (1 Hari Kerja)</strong>. Peserta wajib mencapai durasi ini untuk mengklaim sertifikat kelulusan.
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <input
                type="number"
                min={1}
                max={168}
                value={minimalJam}
                onChange={(e) => setMinimalJam(Math.max(1, parseInt(e.target.value) || 8))}
                className="w-20 border-2 border-slate-200 rounded-xl px-3 py-2 text-center text-xs font-black font-mono bg-white outline-none focus:border-indigo-600"
              />
              <span className="text-xs font-bold text-slate-700">Jam (JP)</span>
            </div>
          </div>

          {/* Folder Password Lock on Create */}
          {!initialData && (
            <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black uppercase text-amber-900 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-amber-600" /> Kata Sandi Kunci Folder (Opsional)
                </span>
                <span className="text-[10px] font-bold text-amber-700">Otomatis dilindungi RBAC</span>
              </div>
              <input
                type="text"
                value={folderPassword}
                onChange={(e) => setFolderPassword(e.target.value)}
                placeholder="Tentukan kata sandi / PIN folder (kosongkan bila tanpa sandi)"
                className="w-full border border-amber-300 rounded-xl px-3 py-2 text-xs font-mono font-bold bg-white outline-none focus:border-amber-600"
              />
            </div>
          )}

          {/* Hak Akses Peserta (Manual Whitelist / Kategori) */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <Users className="w-4 h-4 text-indigo-600" /> Hak Akses Peserta Pelatihan
              </label>
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                accessType === 'restricted' ? 'bg-violet-100 text-violet-700' : 'bg-slate-200 text-slate-700'
              }`}>
                {accessType === 'restricted' ? `Akses Terbatas (${allowedPeserta.length} Peserta)` : 'Semua Peserta'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setAccessType('all')}
                className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all text-left flex items-center gap-2 ${
                  accessType === 'all'
                    ? 'bg-white border-indigo-600 text-indigo-700 shadow-xs ring-1 ring-indigo-200'
                    : 'bg-slate-100 border-slate-200 text-slate-600 hover:border-slate-300'
                }`}
              >
                <Users className="w-4 h-4" />
                <div>
                  <p className="leading-tight">Semua Peserta</p>
                  <p className="text-[9px] text-slate-400 font-normal">Sesuai Kategori Role</p>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setAccessType('restricted')}
                className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all text-left flex items-center gap-2 ${
                  accessType === 'restricted'
                    ? 'bg-white border-violet-600 text-violet-700 shadow-xs ring-1 ring-violet-200'
                    : 'bg-slate-100 border-slate-200 text-slate-600 hover:border-slate-300'
                }`}
              >
                <UserCheck className="w-4 h-4" />
                <div>
                  <p className="leading-tight">Pilih Manual (Whitelist)</p>
                  <p className="text-[9px] text-slate-400 font-normal">Peserta Tertentu Saja</p>
                </div>
              </button>
            </div>

            {accessType === 'all' ? (
              <div>
                <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                  Target Kategori Peserta
                </label>
                <select
                  value={targetRole}
                  onChange={(e) => setTargetRole(e.target.value as any)}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold bg-white outline-none focus:border-indigo-600"
                >
                  <option value="semua">Semua Kategori (UMUM & REGULER)</option>
                  <option value="umum">UMUM Saja</option>
                  <option value="reguler">REGULER Saja</option>
                </select>
              </div>
            ) : (
              <div className="space-y-3 pt-2 border-t border-slate-200">
                {/* Selected Chips */}
                <div className="p-3 bg-violet-50/70 rounded-2xl border border-violet-100 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-violet-950 flex items-center gap-1.5">
                      <UserCheck className="w-3.5 h-3.5 text-violet-600" /> Peserta Terpilih ke Materi:
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full bg-violet-600 text-white font-black text-[10px] shadow-xs">
                      {allowedPeserta.length} Peserta
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto custom-scroll p-2 bg-white rounded-xl border border-violet-100 min-h-[44px] items-center">
                    {allowedPeserta.length === 0 ? (
                      <span className="text-slate-400 text-[11px] italic">
                        Belum ada peserta dipilih. Centang pegawai dari daftar di bawah.
                      </span>
                    ) : (
                      allowedPeserta.map((nup) => {
                        const p = DATABASE_PEGAWAI[nup] || { nama: `Peserta ${nup}` };
                        return (
                          <span
                            key={nup}
                            className="inline-flex items-center gap-1.5 pl-2.5 pr-1 py-1 rounded-xl bg-violet-50 text-violet-900 border border-violet-200 text-xs font-bold"
                          >
                            <span className="truncate max-w-[120px]">{p.nama}</span>
                            <span className="font-mono text-[10px] text-violet-600">({nup})</span>
                            <button
                              type="button"
                              onClick={() => togglePeserta(nup)}
                              className="text-violet-400 hover:text-rose-600 p-0.5"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </span>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* Filter & Search */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex bg-slate-200/70 p-1 rounded-xl text-xs font-bold">
                    <button
                      type="button"
                      onClick={() => setPickerTab('all')}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        pickerTab === 'all' ? 'bg-white text-violet-700 shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      Semua Pegawai
                    </button>
                    <button
                      type="button"
                      onClick={() => setPickerTab('selected')}
                      className={`px-3 py-1 rounded-lg transition-all ${
                        pickerTab === 'selected' ? 'bg-white text-violet-700 shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      Terpilih Saja ({allowedPeserta.length})
                    </button>
                  </div>

                  <div className="flex gap-2 text-[11px]">
                    <button
                      type="button"
                      onClick={() => handleSelectAllVisible(filteredPegawai)}
                      className="text-violet-700 hover:underline font-bold"
                    >
                      Pilih Semua
                    </button>
                    <span className="text-slate-300">|</span>
                    <button
                      type="button"
                      onClick={handleClearAll}
                      className="text-rose-600 hover:underline font-bold"
                    >
                      Kosongkan
                    </button>
                  </div>
                </div>

                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={pickerSearch}
                    onChange={(e) => setPickerSearch(e.target.value)}
                    placeholder="Cari nama, NUP, atau divisi pegawai..."
                    className="w-full border border-slate-200 rounded-xl pl-8 pr-3 py-2 text-xs bg-white outline-none focus:border-violet-600"
                  />
                </div>

                {/* Checklist Box */}
                <div className="max-h-48 overflow-y-auto custom-scroll border border-slate-200 rounded-xl bg-white p-2 space-y-1">
                  {filteredPegawai.length === 0 ? (
                    <div className="text-center py-6 text-slate-400 text-xs">
                      Tidak ditemukan pegawai yang cocok.
                    </div>
                  ) : (
                    filteredPegawai.slice(0, 100).map((nup) => {
                      const p = DATABASE_PEGAWAI[nup];
                      const isChecked = allowedPeserta.includes(nup);
                      return (
                        <label
                          key={nup}
                          className={`flex items-center gap-2.5 p-2 rounded-xl cursor-pointer transition-all border ${
                            isChecked
                              ? 'bg-violet-50/70 border-violet-200'
                              : 'border-transparent hover:bg-slate-50'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => togglePeserta(nup)}
                            className="w-4 h-4 rounded text-violet-600"
                          />
                          <div className="flex-1 min-w-0">
                            <p className="font-bold text-xs text-slate-900 truncate">{p.nama}</p>
                            <p className="text-[10px] text-slate-400 truncate">
                              NUP: <span className="font-mono text-slate-600 font-semibold">{nup}</span> • {p.unit}
                            </p>
                          </div>
                        </label>
                      );
                    })
                  )}
                </div>

                {/* Add Custom NUP */}
                <div className="pt-2 border-t border-dashed border-slate-200 flex gap-2">
                  <input
                    type="text"
                    value={customNupInput}
                    onChange={(e) => setCustomNupInput(e.target.value)}
                    placeholder="Tambah NUP lain secara manual..."
                    className="flex-1 border border-slate-200 rounded-xl px-3 py-1.5 text-xs bg-white outline-none focus:border-violet-600 font-mono uppercase"
                  />
                  <button
                    type="button"
                    onClick={addCustomNup}
                    className="px-3 py-1.5 bg-violet-50 hover:bg-violet-100 text-violet-700 font-bold text-xs rounded-xl transition-colors flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Tambah NUP
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Curriculum Sessions Reorder with Word Editor */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
            <SessionReorderList
              sessions={sessions}
              onChange={(newSessions) => setSessions(newSessions)}
            />
          </div>

          {/* Cover Image & Hidden Toggle */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1 flex items-center gap-1">
                <ImageIcon className="w-3.5 h-3.5 text-indigo-600" /> Link Cover Gambar Materi (Opsional)
              </label>
              <input
                type="url"
                value={gambar}
                onChange={(e) => setGambar(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                className="w-full border-2 border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold bg-slate-50 focus:bg-white outline-none focus:border-indigo-600 transition-all font-mono"
              />
            </div>

            <div className="flex items-center justify-between p-3.5 bg-rose-50/70 rounded-2xl border border-rose-200">
              <span className="text-xs font-bold text-rose-800">Sembunyikan Materi dari Peserta (Draft Mode)</span>
              <input
                type="checkbox"
                checked={hidden}
                onChange={(e) => setHidden(e.target.checked)}
                className="w-4 h-4 text-rose-600 rounded"
              />
            </div>
          </div>

          {/* Footer Submit Actions */}
          <div className="flex gap-2 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 font-bold text-slate-400 uppercase text-xs hover:bg-slate-50 rounded-xl border border-slate-200 transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-bold uppercase text-xs shadow-md transition-colors flex items-center justify-center gap-1.5"
            >
              <Save className="w-4 h-4" /> {initialData ? 'Perbarui Materi' : 'Simpan Materi'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
