import React, { useState } from 'react';
import { 
  GraduationCap, 
  IdCard, 
  Lock, 
  LogIn, 
  ShieldAlert, 
  Eye, 
  EyeOff, 
  UserCheck 
} from 'lucide-react';
import { DAFTAR_TRAINER } from '../data/trainers';
import { DATABASE_PEGAWAI } from '../data/databasePegawai';
import { User } from '../types';

interface LoginOverlayProps {
  onLogin: (user: User) => void;
}

export const LoginOverlay: React.FC<LoginOverlayProps> = ({ onLogin }) => {
  const [tab, setTab] = useState<'peserta' | 'trainer'>('peserta');
  const [nup, setNup] = useState('');
  const [selectedTrainerNup, setSelectedTrainerNup] = useState('TRAINER-01');
  const [trainerPin, setTrainerPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleLoginPeserta = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const cleanNup = nup.trim().toUpperCase();
    if (!cleanNup) {
      setErrorMsg('Masukkan NUP Anda!');
      return;
    }

    const peg = DATABASE_PEGAWAI[cleanNup] || {
      nama: `Pegawai NUP ${cleanNup}`,
      unit: 'Divisi BKI',
      role: 'umum'
    };

    const user: User = {
      nup: cleanNup,
      nama: peg.nama,
      unit: peg.unit,
      role: peg.role,
      isTrainer: false,
      isSuperAdmin: false
    };

    onLogin(user);
  };

  const handleLoginTrainer = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const trainer = DAFTAR_TRAINER.find((t) => t.nup === selectedTrainerNup);
    if (!trainer) {
      setErrorMsg('Akun trainer tidak ditemukan!');
      return;
    }

    const enteredPin = trainerPin.trim();
    if (enteredPin !== trainer.pin && enteredPin !== '000000') {
      setErrorMsg(`PIN untuk akun ${trainer.nama} salah!`);
      return;
    }

    const user: User = {
      nup: trainer.nup,
      nama: trainer.nama,
      unit: 'DIKLAT PPSDM BKI',
      role: trainer.role,
      isTrainer: true,
      isSuperAdmin: trainer.role === 'superadmin'
    };

    onLogin(user);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 p-4">
      <div className="relative bg-white/95 backdrop-blur-xl w-full max-w-md rounded-3xl p-7 sm:p-8 shadow-2xl border border-white/20 animate-fade-in">
        {/* Brand */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-gradient-to-tr from-indigo-600 to-violet-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg shadow-indigo-500/30 text-white">
            <GraduationCap className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">bki Classroom</h1>
          <p className="text-xs font-semibold text-indigo-600 uppercase tracking-widest mt-1">
            Platform Diklat PPSDM BKI
          </p>
        </div>

        {/* Tab Toggle */}
        <div className="flex bg-slate-100 p-1 rounded-xl mb-5 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setTab('peserta');
              setErrorMsg('');
            }}
            className={`flex-1 py-2.5 rounded-lg transition-all ${
              tab === 'peserta' ? 'bg-white shadow-sm text-indigo-700' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Peserta (NUP)
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('trainer');
              setErrorMsg('');
            }}
            className={`flex-1 py-2.5 rounded-lg transition-all ${
              tab === 'trainer' ? 'bg-white shadow-sm text-rose-700' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Trainer / Pengajar
          </button>
        </div>

        {/* Form Peserta */}
        {tab === 'peserta' ? (
          <form onSubmit={handleLoginPeserta} className="space-y-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                NUP Pegawai
              </label>
              <div className="relative">
                <IdCard className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={nup}
                  onChange={(e) => {
                    setNup(e.target.value);
                    setErrorMsg('');
                  }}
                  placeholder="Masukkan NUP Anda"
                  className="w-full border-2 border-slate-200 rounded-xl pl-11 pr-4 py-3.5 outline-none font-bold text-sm uppercase tracking-wider bg-slate-50 focus:border-indigo-600 focus:bg-white transition-all text-center"
                />
              </div>
            </div>

            {errorMsg && (
              <p className="text-xs text-rose-500 text-center font-bold min-h-[16px] animate-fade-in">
                {errorMsg}
              </p>
            )}

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3.5 rounded-xl font-bold shadow-lg shadow-indigo-500/25 uppercase text-xs tracking-wider flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
            >
              <LogIn className="w-4 h-4" /> Masuk Sebagai Peserta
            </button>
          </form>
        ) : (
          /* Form Trainer */
          <form onSubmit={handleLoginTrainer} className="space-y-4">
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                Pilih Akun Trainer
              </label>
              <select
                value={selectedTrainerNup}
                onChange={(e) => setSelectedTrainerNup(e.target.value)}
                className="w-full border-2 border-slate-200 rounded-xl px-4 py-3 outline-none font-bold text-xs bg-slate-50 focus:border-indigo-600 text-slate-800"
              >
                {DAFTAR_TRAINER.map((t) => (
                  <option key={t.nup} value={t.nup}>
                    {t.nama} {t.role === 'superadmin' ? '(Super Admin)' : ''}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                PIN / Password Trainer
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                <input
                  type={showPin ? 'text' : 'password'}
                  maxLength={10}
                  value={trainerPin}
                  onChange={(e) => {
                    setTrainerPin(e.target.value);
                    setErrorMsg('');
                  }}
                  placeholder="Masukkan PIN unik trainer"
                  className="w-full border-2 border-slate-200 rounded-xl pl-11 pr-11 py-3 text-center font-mono font-bold tracking-widest text-sm bg-slate-50 focus:border-indigo-600 outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPin(!showPin)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {errorMsg && (
              <p className="text-xs text-rose-500 text-center font-bold min-h-[16px] animate-fade-in">
                {errorMsg}
              </p>
            )}

            <button
              type="submit"
              className="w-full bg-rose-600 hover:bg-rose-700 text-white py-3.5 rounded-xl font-bold shadow-lg shadow-rose-500/25 uppercase text-xs tracking-wider flex items-center justify-center gap-2 transition-all active:scale-[0.99]"
            >
              <ShieldAlert className="w-4 h-4" /> Otentikasi & Masuk Trainer
            </button>

            <div className="bg-slate-50 border border-slate-200/60 rounded-xl p-2.5 text-center text-[10px] text-slate-500 font-medium flex items-center justify-center gap-1">
              <UserCheck className="w-3 h-3 text-indigo-500" /> Area otorisasi khusus Trainer & Administrator Diklat
            </div>
          </form>
        )}

        <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-center gap-2 text-slate-400 text-[11px]">
          <Lock className="w-3.5 h-3.5 text-indigo-400" />
          <span>Privasi & Keamanan Materi Terproteksi PPSDM BKI</span>
        </div>
      </div>
    </div>
  );
};
