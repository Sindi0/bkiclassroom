import React from 'react';
import { 
  ArrowLeft, 
  FolderOpen, 
  Lock, 
  Unlock, 
  Key, 
  Inbox, 
  User as UserIcon,
  CheckCircle2
} from 'lucide-react';
import { Materi, User, FolderLock } from '../types';

interface FolderViewProps {
  folderName: string;
  materiList: Materi[];
  folderLock: FolderLock | null;
  currentUser: User;
  onBack: () => void;
  onOpenMateri: (materiId: string) => void;
  onRelockFolder: (folderName: string) => void;
  onManageFolderLock: (folderName: string) => void;
}

export const FolderView: React.FC<FolderViewProps> = ({
  folderName,
  materiList,
  folderLock,
  currentUser,
  onBack,
  onOpenMateri,
  onRelockFolder,
  onManageFolderLock
}) => {
  const isLocked = !!folderLock?.password;
  const canManage = currentUser.isSuperAdmin || folderLock?.ownerNup === currentUser.nup;

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Folder Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 pb-4 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBack}
            className="px-3.5 py-2 rounded-xl bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold flex items-center gap-2 shadow-2xs transition-colors"
          >
            <ArrowLeft className="w-4 h-4" /> Kembali
          </button>
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center text-lg">
            <FolderOpen className="w-5 h-5 fill-amber-600 text-amber-700" />
          </div>
          <div>
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-tight">
              {folderName}
            </h2>
            <p className="text-xs text-slate-400 font-medium flex items-center gap-1">
              <UserIcon className="w-3.5 h-3.5" />
              <span>Trainer Pemilik: {folderLock?.ownerName || 'Trainer PPSDM'}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {isLocked ? (
            <span className="px-3 py-1 rounded-full text-xs font-black uppercase bg-amber-50 text-amber-700 border border-amber-200 flex items-center gap-1">
              <Unlock className="w-3.5 h-3.5" /> Terbuka (PIN Valid)
            </span>
          ) : (
            <span className="px-3 py-1 rounded-full text-xs font-black uppercase bg-emerald-50 text-emerald-700 border border-emerald-200">
              Tidak Dikunci
            </span>
          )}

          {isLocked && (
            <button
              type="button"
              onClick={() => onRelockFolder(folderName)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <Lock className="w-3.5 h-3.5 text-rose-500" /> Kunci Kembali
            </button>
          )}

          {canManage && (
            <button
              type="button"
              onClick={() => onManageFolderLock(folderName)}
              className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
            >
              <Key className="w-3.5 h-3.5" /> Atur Sandi Folder
            </button>
          )}
        </div>
      </div>

      {/* Grid Materi in Folder */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {materiList.length === 0 ? (
          <div className="col-span-full text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 space-y-2">
            <Inbox className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="text-sm font-bold text-slate-500">Folder ini belum memiliki materi.</p>
          </div>
        ) : (
          materiList.map((m) => {
            const totalSessions = m.sesi?.length || 0;
            const userDone = m.selesaiSesi?.[currentUser.nup] || {};
            const doneCount = Object.keys(userDone).filter((k) => userDone[Number(k)]).length;
            const pct = totalSessions > 0 ? Math.round((doneCount / totalSessions) * 100) : 0;
            const isRestricted = m.accessType === 'restricted' || (m.allowedPeserta && m.allowedPeserta.length > 0);

            return (
              <div
                key={m.id}
                onClick={() => onOpenMateri(m.id)}
                className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-xl hover:border-indigo-400 transition-all cursor-pointer group"
              >
                <div className="relative h-40 bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-900 overflow-hidden">
                  {m.gambar && (
                    <img
                      src={m.gambar}
                      alt={m.judul}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/30 to-transparent" />

                  <div className="absolute top-3 left-3 flex items-center gap-1.5">
                    <span className="bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full text-[10px] font-black text-white uppercase">
                      {folderName}
                    </span>
                    {isRestricted && (
                      <span className="bg-violet-600/90 backdrop-blur-md px-2 py-0.5 rounded-full text-[9px] font-black text-white uppercase">
                        Khusus
                      </span>
                    )}
                  </div>

                  <div className="absolute bottom-3 left-3 right-3">
                    <h4 className="text-white font-black text-sm uppercase leading-tight line-clamp-2 drop-shadow-md">
                      {m.judul}
                    </h4>
                  </div>
                </div>

                <div className="p-4 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-bold">
                      {doneCount}/{totalSessions} Sesi Selesai
                    </span>
                    <span className={`font-black ${pct === 100 ? 'text-emerald-600' : 'text-indigo-600'}`}>
                      {pct}%
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        pct === 100 ? 'bg-emerald-500' : 'bg-indigo-600'
                      }`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
