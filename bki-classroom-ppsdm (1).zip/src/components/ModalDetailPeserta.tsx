import React, { useState } from 'react';
import { 
  X, 
  Search, 
  Copy, 
  FileSpreadsheet, 
  Users, 
  CheckCircle2, 
  BookOpen, 
  Award, 
  Edit,
  Check
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Materi, LaporanNilai, AbsenRecord } from '../types';
import { DATABASE_PEGAWAI } from '../data/databasePegawai';

interface ModalDetailPesertaProps {
  isOpen: boolean;
  onClose: () => void;
  materi: Materi | null;
  absenRecords: Record<string, AbsenRecord>;
  laporanRecords: Record<string, LaporanNilai>;
  onEditPeserta: (materiId: string) => void;
  onOpenCertificate: (peserta: { nama: string; nup: string; unit: string; nilai: number }) => void;
  canManage: boolean;
}

export const ModalDetailPeserta: React.FC<ModalDetailPesertaProps> = ({
  isOpen,
  onClose,
  materi,
  absenRecords,
  laporanRecords,
  onEditPeserta,
  onOpenCertificate,
  canManage
}) => {
  const [search, setSearch] = useState('');
  const [copied, setCopied] = useState(false);

  if (!isOpen || !materi) return null;

  // Compute eligible participants
  const isRestricted = materi.accessType === 'restricted' || (materi.allowedPeserta && materi.allowedPeserta.length > 0);
  let participantList: { nup: string; nama: string; unit: string; role: string }[] = [];

  if (isRestricted) {
    (materi.allowedPeserta || []).forEach((nup) => {
      const clean = nup.trim().toUpperCase();
      const p = DATABASE_PEGAWAI[clean] || { nama: `Peserta ${clean}`, unit: '-', role: 'umum' };
      participantList.push({
        nup: clean,
        nama: p.nama,
        unit: p.unit,
        role: p.role
      });
    });
  } else {
    const targetRole = materi.targetRole || 'semua';
    Object.keys(DATABASE_PEGAWAI).forEach((nup) => {
      const p = DATABASE_PEGAWAI[nup];
      if (targetRole === 'semua' || p.role === targetRole) {
        participantList.push({
          nup,
          nama: p.nama,
          unit: p.unit,
          role: p.role
        });
      }
    });
  }

  // Filter with query
  const q = search.toLowerCase().trim();
  const filtered = participantList.filter(
    (p) => p.nama.toLowerCase().includes(q) || p.nup.toLowerCase().includes(q) || p.unit.toLowerCase().includes(q)
  );

  // Statistics
  const totalCount = participantList.length;
  let absenCount = 0;
  let selesaiCount = 0;

  participantList.forEach((p) => {
    if (absenRecords[p.nup]) absenCount++;
    if (laporanRecords[p.nup]) selesaiCount++;
  });

  const handleCopyNUP = () => {
    const nups = participantList.map((p) => p.nup).join(', ');
    navigator.clipboard.writeText(nups);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadExcel = () => {
    const rows = participantList.map((p, i) => {
      const isSelesai = !!laporanRecords[p.nup];
      const isAbsen = !!absenRecords[p.nup];
      const nilai = laporanRecords[p.nup]?.nilai ?? (isSelesai ? 100 : '-');
      const statusStr = isSelesai ? 'Selesai Belajar (100)' : isAbsen ? 'Sedang Akses/Absen' : 'Belum Akses';

      return {
        No: i + 1,
        NUP: p.nup,
        'Nama Pegawai': p.nama,
        'Unit Kerja': p.unit,
        Kategori: p.role.toUpperCase(),
        'Judul Materi': materi.judul,
        Folder: materi.folder || '-',
        'Nilai Akhir': nilai,
        'Status Belajar': statusStr
      };
    });

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Peserta');
    const cleanTitle = (materi.judul || 'Materi').replace(/[^a-zA-Z0-9]/g, '_').substring(0, 30);
    XLSX.writeFile(wb, `Peserta_${cleanTitle}.xlsx`);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div className="bg-white w-full max-w-3xl rounded-3xl p-6 sm:p-7 shadow-2xl border border-slate-100 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex justify-between items-start mb-4 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-slate-100 text-slate-600">
                {materi.folder ? `Folder: ${materi.folder}` : 'Umum'}
              </span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                isRestricted ? 'bg-violet-100 text-violet-700' : 'bg-slate-100 text-slate-700'
              }`}>
                {isRestricted ? `Khusus ${totalCount} Peserta Terpilih` : `Terbuka: Kategori ${(materi.targetRole || 'Semua').toUpperCase()}`}
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-amber-100 text-amber-800 border border-amber-300">
                Standar: {materi.minimalJam || 8} Jam (1 Hari Kerja)
              </span>
            </div>
            <h3 className="font-black text-base sm:text-lg text-slate-900 uppercase leading-snug">
              {materi.judul}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Dibuat oleh: <span className="font-bold text-slate-600">{materi.ownerTrainerName || 'Trainer'}</span>
            </p>
          </div>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-rose-600 p-1">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Statistic Cards */}
        <div className="grid grid-cols-3 gap-2 mb-4 text-center">
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-2.5">
            <p className="text-[10px] uppercase font-bold text-slate-400">Total Berhak Akses</p>
            <p className="text-lg font-black text-slate-800">{totalCount}</p>
          </div>
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-2.5">
            <p className="text-[10px] uppercase font-bold text-emerald-700">Sudah Absen/Buka</p>
            <p className="text-lg font-black text-emerald-700">{absenCount}</p>
          </div>
          <div className="bg-indigo-50 border border-indigo-200 rounded-2xl p-2.5">
            <p className="text-[10px] uppercase font-bold text-indigo-700">Selesai Belajar</p>
            <p className="text-lg font-black text-indigo-700">{selesaiCount}</p>
          </div>
        </div>

        {/* Search & Actions */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari nama, NUP, atau unit peserta..."
              className="w-full border border-slate-200 rounded-xl pl-8 pr-3 py-1.5 text-xs bg-slate-50 outline-none focus:border-indigo-600 transition-colors"
            />
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={handleCopyNUP}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Tersalin' : 'Salin NUP'}</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadExcel}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 shadow-2xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Ekspor Excel</span>
            </button>
          </div>
        </div>

        {/* Participants Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-200 flex-1 max-h-[44vh] overflow-y-auto custom-scroll">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200 sticky top-0 bg-slate-50 z-10">
              <tr>
                <th className="p-2.5">#</th>
                <th className="p-2.5">Nama Pegawai</th>
                <th className="p-2.5">NUP</th>
                <th className="p-2.5">Unit / Divisi</th>
                <th className="p-2.5">Kategori</th>
                <th className="p-2.5 text-center">Status Belajar</th>
                <th className="p-2.5 text-right">Sertifikat</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-slate-400 font-semibold text-xs">
                    Tidak ada peserta yang cocok dengan pencarian.
                  </td>
                </tr>
              ) : (
                filtered.map((p, idx) => {
                  const isSelesai = !!laporanRecords[p.nup];
                  const isAbsen = !!absenRecords[p.nup];
                  const grade = laporanRecords[p.nup]?.nilai ?? (isSelesai ? 100 : 0);

                  return (
                    <tr key={p.nup} className="hover:bg-slate-50 transition-colors">
                      <td className="p-2.5 text-slate-400 font-mono text-[10px]">{idx + 1}</td>
                      <td className="p-2.5 font-bold text-slate-900">{p.nama}</td>
                      <td className="p-2.5 font-mono font-bold text-indigo-700">{p.nup}</td>
                      <td className="p-2.5 text-slate-500">{p.unit}</td>
                      <td className="p-2.5">
                        <span className={`px-1.5 py-0.5 rounded text-[9px] font-black uppercase ${
                          p.role === 'reguler'
                            ? 'bg-sky-50 text-sky-700 border border-sky-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}>
                          {p.role.toUpperCase()}
                        </span>
                      </td>
                      <td className="p-2.5 text-center">
                        {isSelesai ? (
                          <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-black inline-flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Selesai ({grade})
                          </span>
                        ) : isAbsen ? (
                          <span className="px-2.5 py-0.5 rounded-full bg-sky-50 text-sky-700 border border-sky-200 text-[10px] font-bold inline-flex items-center gap-1">
                            <BookOpen className="w-3 h-3 text-sky-600" /> Membaca
                          </span>
                        ) : (
                          <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-400 text-[10px] font-medium">
                            Belum Akses
                          </span>
                        )}
                      </td>
                      <td className="p-2.5 text-right">
                        <button
                          type="button"
                          onClick={() => onOpenCertificate({
                            nama: p.nama,
                            nup: p.nup,
                            unit: p.unit,
                            nilai: grade || 90
                          })}
                          className={`p-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 ml-auto ${
                            isSelesai
                              ? 'bg-amber-100 hover:bg-amber-200 text-amber-900'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                          }`}
                          title="Generate Sertifikat Peserta Ini"
                        >
                          <Award className="w-3.5 h-3.5 text-amber-600" />
                          <span className="text-[10px]">Cetak PDF</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100 mt-4">
          <span className="text-xs text-slate-400 font-medium">
            {filtered.length} dari {totalCount} peserta ditampilkan
          </span>
          <div className="flex gap-2">
            {canManage && (
              <button
                type="button"
                onClick={() => onEditPeserta(materi.id)}
                className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <Edit className="w-3.5 h-3.5" /> Ubah Pilihan Peserta
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors"
            >
              Tutup
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
