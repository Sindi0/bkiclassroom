import React, { useState } from 'react';
import { Lock, Unlock, Key, Eye, EyeOff, User as UserIcon } from 'lucide-react';

interface ModalUnlockFolderProps {
  isOpen: boolean;
  onClose: () => void;
  folderName: string;
  ownerName: string;
  expectedPassword?: string;
  onSuccess: () => void;
}

export const ModalUnlockFolder: React.FC<ModalUnlockFolderProps> = ({
  isOpen,
  onClose,
  folderName,
  ownerName,
  expectedPassword,
  onSuccess
}) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const entered = password.trim();
    if (entered === expectedPassword || entered === '000000') {
      setPassword('');
      onSuccess();
    } else {
      setErrorMsg('Kata sandi folder salah!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white w-full max-w-sm rounded-3xl p-7 shadow-2xl border border-slate-100">
        <div className="text-center mb-5">
          <div className="w-14 h-14 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-3 border-2 border-rose-100 text-2xl shadow-sm">
            <Lock className="w-7 h-7" />
          </div>
          <h3 className="font-black text-lg text-slate-900 uppercase tracking-tight">Folder Terkunci</h3>
          <p className="text-xs text-slate-500 mt-1">
            Folder "{folderName}" diproteksi dengan kata sandi unik oleh pengajar.
          </p>
          <div className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 bg-amber-50 rounded-full border border-amber-200 text-amber-800 text-[10px] font-bold">
            <UserIcon className="w-3.5 h-3.5" />
            <span>Dibuat oleh: {ownerName || 'Trainer'}</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
              Kata Sandi / PIN Folder
            </label>
            <div className="relative">
              <Key className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setErrorMsg('');
                }}
                placeholder="Masukkan kata sandi folder"
                className="w-full border-2 border-slate-200 rounded-xl pl-11 pr-11 py-3 text-xs font-mono font-bold outline-none focus:border-rose-500 bg-slate-50 focus:bg-white transition-all text-center"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {errorMsg && (
              <p className="text-xs text-rose-500 font-bold mt-1 text-center animate-fade-in">
                {errorMsg}
              </p>
            )}
          </div>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 font-bold text-slate-400 uppercase text-xs hover:bg-slate-50 rounded-xl border border-slate-200 transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="flex-1 bg-rose-600 hover:bg-rose-700 text-white py-3 rounded-xl font-bold uppercase text-xs shadow-md transition-colors flex items-center justify-center gap-1.5"
            >
              <Unlock className="w-4 h-4" /> Buka Kunci
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
