import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Download, 
  Printer, 
  Upload, 
  Settings2, 
  Eye, 
  CheckCircle, 
  Award, 
  Sparkles, 
  FileText, 
  Palette, 
  QrCode,
  Image as ImageIcon,
  BookOpen,
  LayoutTemplate,
  Check,
  Move,
  RotateCcw,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { CertificateConfig, ElementPosition, Materi } from '../types';
import { WordEditor } from './WordEditor';

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
  materi: Materi | null;
  peserta: {
    nama: string;
    nup: string;
    unit?: string;
    nilai?: number;
  } | null;
  onSaveCertificate?: (certData: { nomor: string; config: CertificateConfig }) => void;
}

interface DraggableElementProps {
  id: string;
  label: string;
  position: ElementPosition;
  isDragEnabled: boolean;
  isSelected: boolean;
  isExporting: boolean;
  onSelect: (id: string) => void;
  onDragStart: (id: string, e: React.MouseEvent | React.TouchEvent) => void;
  className?: string;
  children: React.ReactNode;
}

const DraggableElement: React.FC<DraggableElementProps> = ({
  id,
  label,
  position,
  isDragEnabled,
  isSelected,
  isExporting,
  onSelect,
  onDragStart,
  className = '',
  children
}) => {
  const isShifted = position.x !== 0 || position.y !== 0;

  return (
    <div
      onClick={(e) => {
        if (!isExporting && isDragEnabled) {
          e.stopPropagation();
          onSelect(id);
        }
      }}
      onMouseDown={(e) => {
        if (!isExporting && isDragEnabled) {
          onDragStart(id, e);
        }
      }}
      onTouchStart={(e) => {
        if (!isExporting && isDragEnabled) {
          onDragStart(id, e);
        }
      }}
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
        position: 'relative',
        zIndex: isSelected ? 30 : 10
      }}
      className={`group/draggable relative select-none transition-all duration-75 ${className} ${
        !isExporting && isDragEnabled
          ? 'cursor-grab active:cursor-grabbing hover:outline hover:outline-2 hover:outline-dashed hover:outline-indigo-400 rounded-xl'
          : ''
      } ${
        !isExporting && isSelected
          ? 'outline outline-2 outline-indigo-600 ring-4 ring-indigo-500/20 rounded-xl bg-indigo-50/10'
          : ''
      }`}
    >
      {/* Badge label & offset info shown on hover or when selected */}
      {!isExporting && isDragEnabled && (
        <div
          className={`absolute -top-7 left-1/2 -translate-x-1/2 pointer-events-none transition-opacity flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold shadow-md whitespace-nowrap z-50 ${
            isSelected
              ? 'opacity-100 bg-indigo-600 text-white ring-2 ring-white'
              : 'opacity-0 group-hover/draggable:opacity-100 bg-slate-900 text-white'
          }`}
        >
          <Move className="w-2.5 h-2.5 text-indigo-200" />
          <span>{label}</span>
          {isShifted && (
            <span className="text-[8px] opacity-80 font-mono ml-0.5">
              ({position.x > 0 ? `+${position.x}` : position.x}, {position.y > 0 ? `+${position.y}` : position.y})
            </span>
          )}
        </div>
      )}

      {children}
    </div>
  );
};

export const CertificateModal: React.FC<CertificateModalProps> = ({
  isOpen,
  onClose,
  materi,
  peserta,
  onSaveCertificate
}) => {
  const certificateRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [activeTab, setActiveTab] = useState<'preview' | 'customize'>('preview');

  // Interactive direct drag-and-drop state
  const [isDragModeActive, setIsDragModeActive] = useState<boolean>(true);
  const [selectedElementId, setSelectedElementId] = useState<string | null>(null);

  const defaultYear = new Date().getFullYear();
  const defaultNumber = `CERT/${defaultYear}/${peserta ? peserta.nup : '001'}`;
  
  // Format tanggal Indonesia
  const todayStr = new Intl.DateTimeFormat('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(new Date());

  // Default syllabus formatted text from sessions if available
  const defaultSyllabus = materi?.sesi && materi.sesi.length > 0
    ? `<p><strong>Materi &amp; Silabus Pelatihan yang Diselesaikan:</strong></p><ol>` +
      materi.sesi.map((s) => `<li><strong>${s.judul}</strong>: Penguasaan materi kurikulum &amp; uji kompetensi.</li>`).join('') +
      `</ol>`
    : `<p><strong>Materi &amp; Silabus Pelatihan yang Diselesaikan:</strong></p><ul><li><strong>Penguasaan Teori &amp; Dasar Kompetensi</strong>: Pemahaman komprehensif kurikulum standar.</li><li><strong>Studi Kasus &amp; Implementasi Teknis</strong>: Penyelesaian tugas analisis dan evaluasi lapangan.</li><li><strong>Ujian Kompetensi Akhir</strong>: Memenuhi seluruh tolok ukur kelulusan dengan memuaskan.</li></ul>`;

  const [config, setConfig] = useState<CertificateConfig>({
    materiId: materi?.id || '',
    materiJudul: materi?.judul || 'Pelatihan Kompetensi & Keahlian Khusus',
    presetTheme: 'gold',
    orientation: 'landscape',
    customTemplateImage: '',
    nomorFormat: defaultNumber,
    judulSertifikat: 'SERTIFIKAT KELULUSAN',
    subJudul: 'Diberikan dengan bangga kepada:',
    deskripsiPencapaian: 'Atas keberhasilan, dedikasi, dan kelulusan penuh dalam menyelesaikan seluruh kurikulum program pelatihan:',
    materiRichText: defaultSyllabus,
    showMateriDetails: false,
    penandatanganNama: 'Dr. Ir. Hendra Gunawan, M.T.',
    penandatanganJabatan: 'Direktur Pelatihan & Kompetensi',
    penandatanganNama2: materi?.ownerTrainerName || 'Instruktur Pelatihan',
    penandatanganJabatan2: 'Lead Instructor & Assessor',
    showQrCode: true,
    showNilai: true,
    tanggalTerbit: `Jakarta, ${todayStr}`,
    textColorPrimary: '#0f172a',
    textColorSecondary: '#475569',
    textColorAccent: '#b45309',
    elementPositions: {}
  });

  const [positions, setPositions] = useState<Record<string, ElementPosition>>(config.elementPositions || {});

  // Sync positions if config changes
  useEffect(() => {
    if (config.elementPositions) {
      setPositions(config.elementPositions);
    }
  }, [config.elementPositions]);

  // Calculate predicate based on grade
  const grade = peserta?.nilai ?? 95;
  const predicate = grade >= 90 ? 'DENGAN PREDIKAT SANGAT MEMUASKAN (DISTINCTION)' : 
                    grade >= 75 ? 'DENGAN PREDIKAT MEMUASKAN (CREDIT)' : 'LULUS (PASSED)';

  // Keyboard navigation for precision element nudging
  useEffect(() => {
    if (!isOpen || !selectedElementId || !isDragModeActive) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        // Avoid scrolling window
        e.preventDefault();
        const step = e.shiftKey ? 10 : 2;
        let dx = 0;
        let dy = 0;
        if (e.key === 'ArrowUp') dy = -step;
        if (e.key === 'ArrowDown') dy = step;
        if (e.key === 'ArrowLeft') dx = -step;
        if (e.key === 'ArrowRight') dx = step;

        nudgeSelectedElement(dx, dy);
      } else if (e.key === 'Escape') {
        setSelectedElementId(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedElementId, isDragModeActive, positions]);

  if (!isOpen) return null;

  const dragSessionRef = { current: null as {
    id: string;
    startX: number;
    startY: number;
    originX: number;
    originY: number;
  } | null };

  const handleElementDragStart = (id: string, e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    setSelectedElementId(id);

    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    const currentPos = positions[id] || { x: 0, y: 0 };

    dragSessionRef.current = {
      id,
      startX: clientX,
      startY: clientY,
      originX: currentPos.x,
      originY: currentPos.y
    };

    const handlePointerMove = (moveEvent: MouseEvent | TouchEvent) => {
      if (!dragSessionRef.current) return;
      if (moveEvent.cancelable) {
        moveEvent.preventDefault();
      }

      const curX = 'touches' in moveEvent ? moveEvent.touches[0].clientX : moveEvent.clientX;
      const curY = 'touches' in moveEvent ? moveEvent.touches[0].clientY : moveEvent.clientY;

      const deltaX = Math.round(curX - dragSessionRef.current.startX);
      const deltaY = Math.round(curY - dragSessionRef.current.startY);

      const newX = dragSessionRef.current.originX + deltaX;
      const newY = dragSessionRef.current.originY + deltaY;

      setPositions((prev) => ({
        ...prev,
        [dragSessionRef.current!.id]: { x: newX, y: newY }
      }));
    };

    const handlePointerUp = () => {
      if (dragSessionRef.current) {
        dragSessionRef.current = null;
        setPositions((latest) => {
          setConfig((prev) => ({
            ...prev,
            elementPositions: latest
          }));
          return latest;
        });
      }
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      window.removeEventListener('touchmove', handlePointerMove);
      window.removeEventListener('touchend', handlePointerUp);
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: false });
    window.addEventListener('mouseup', handlePointerUp);
    window.addEventListener('touchmove', handlePointerMove, { passive: false });
    window.addEventListener('touchend', handlePointerUp);
  };

  const nudgeSelectedElement = (dx: number, dy: number) => {
    if (!selectedElementId) return;
    const current = positions[selectedElementId] || { x: 0, y: 0 };
    const updated = {
      ...positions,
      [selectedElementId]: { x: current.x + dx, y: current.y + dy }
    };
    setPositions(updated);
    setConfig((prev) => ({ ...prev, elementPositions: updated }));
  };

  const resetSelectedElement = () => {
    if (!selectedElementId) return;
    const updated = {
      ...positions,
      [selectedElementId]: { x: 0, y: 0 }
    };
    setPositions(updated);
    setConfig((prev) => ({ ...prev, elementPositions: updated }));
  };

  const resetAllElements = () => {
    setPositions({});
    setSelectedElementId(null);
    setConfig((prev) => ({ ...prev, elementPositions: {} }));
  };

  const getElementLabel = (id: string): string => {
    switch (id) {
      case 'nomor': return 'Nomor Sertifikat';
      case 'judul': return 'Judul Sertifikat';
      case 'nama': return 'Nama Peserta';
      case 'nup': return 'NUP & Unit';
      case 'deskripsi': return 'Teks Apresiasi';
      case 'materi': return 'Judul Materi Pelatihan';
      case 'materiDetail': return 'Rincian Materi (Word)';
      case 'nilai': return 'Nilai & Predikat';
      case 'ttd1': return 'Tanda Tangan 1';
      case 'seal': return 'Segel / QR Code';
      case 'ttd2': return 'Tanda Tangan 2';
      default: return id;
    }
  };

  const handleCustomTemplateUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('Ukuran file gambar template maksimal 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setConfig((prev) => ({
            ...prev,
            presetTheme: 'custom',
            customTemplateImage: event.target?.result as string
          }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const isPortrait = config.orientation === 'portrait';

  const downloadPDF = async () => {
    if (!certificateRef.current) return;
    setSelectedElementId(null);
    setIsExporting(true);
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });

      const element = certificateRef.current;
      const canvas = await html2canvas(element, {
        scale: 3, // High-DPI export
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff'
      });

      const imgData = canvas.toDataURL('image/jpeg', 0.98);
      
      const pdf = new jsPDF({
        orientation: isPortrait ? 'portrait' : 'landscape',
        unit: 'mm',
        format: 'a4'
      });

      if (isPortrait) {
        pdf.addImage(imgData, 'JPEG', 0, 0, 210, 297);
      } else {
        pdf.addImage(imgData, 'JPEG', 0, 0, 297, 210);
      }

      const cleanName = (peserta?.nama || 'Peserta').replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `Sertifikat_${cleanName}_${peserta?.nup || '001'}.pdf`;
      pdf.save(filename);

      if (onSaveCertificate) {
        onSaveCertificate({
          nomor: config.nomorFormat,
          config: {
            ...config,
            elementPositions: positions
          }
        });
      }
    } catch (err) {
      console.error('PDF export failed:', err);
      alert('Gagal mengekspor PDF. Pastikan gambar background dapat dimuat.');
    } finally {
      setIsExporting(false);
    }
  };

  const downloadPNG = async () => {
    if (!certificateRef.current) return;
    setSelectedElementId(null);
    setIsExporting(true);
    try {
      const element = certificateRef.current;
      const canvas = await html2canvas(element, {
        scale: 2.5,
        useCORS: true,
        allowTaint: true
      });

      const link = document.createElement('a');
      const cleanName = (peserta?.nama || 'Peserta').replace(/[^a-zA-Z0-9]/g, '_');
      link.download = `Sertifikat_${cleanName}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (err) {
      console.error('PNG export failed:', err);
      alert('Gagal mendownload gambar PNG.');
    } finally {
      setIsExporting(false);
    }
  };

  const handlePrint = () => {
    setSelectedElementId(null);
    window.print();
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fade-in"
      onClick={() => setSelectedElementId(null)}
    >
      <div 
        className="relative w-full max-w-6xl bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[96vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 to-violet-500 flex items-center justify-center text-white shadow-md">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-sm uppercase tracking-wide text-white flex items-center gap-2">
                Sertifikat Kelulusan Pelatihan
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-400 text-slate-950 font-black">
                  {isPortrait ? 'Format Potret (A4)' : 'Format Lanskap (A4)'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Peserta: <span className="text-indigo-300 font-bold">{peserta?.nama || 'Peserta Pelatihan'}</span> ({peserta?.nup || '-'})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-slate-800 p-1 rounded-xl text-xs font-bold mr-2">
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
                  activeTab === 'preview' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Eye className="w-3.5 h-3.5" /> Preview Sertifikat
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('customize')}
                className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
                  activeTab === 'customize' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Settings2 className="w-3.5 h-3.5" /> Edit Sertifikat &amp; Materi
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100 flex flex-col items-center">
          {activeTab === 'customize' && (
            <div className="w-full bg-white rounded-2xl border border-slate-200 p-6 mb-6 shadow-xs max-w-4xl space-y-6 animate-fade-in">
              {/* Orientasi Sertifikat (Lanskap vs Potret) */}
              <div>
                <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide flex items-center gap-2">
                  <LayoutTemplate className="w-4 h-4 text-indigo-600" /> Ukuran &amp; Orientasi Sertifikat
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">Pilih orientasi dokumen cetak (Standar Internasional ISO 216 A4).</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, orientation: 'landscape' })}
                    className={`p-3.5 rounded-2xl border-2 text-left flex items-center gap-3.5 transition-all ${
                      config.orientation === 'landscape'
                        ? 'border-indigo-600 bg-indigo-50/70 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="w-12 h-9 rounded-lg bg-slate-800 border-2 border-indigo-400 flex items-center justify-center shrink-0">
                      <span className="text-[10px] text-white font-mono font-bold">297×210</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-bold text-xs text-slate-900">Lanskap (Landscape A4)</p>
                        {config.orientation === 'landscape' && <Check className="w-4 h-4 text-indigo-600" />}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">Lebar mendatar, format piagam kelulusan klasik</p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, orientation: 'portrait' })}
                    className={`p-3.5 rounded-2xl border-2 text-left flex items-center gap-3.5 transition-all ${
                      config.orientation === 'portrait'
                        ? 'border-indigo-600 bg-indigo-50/70 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="w-9 h-12 rounded-lg bg-slate-800 border-2 border-indigo-400 flex items-center justify-center shrink-0">
                      <span className="text-[9px] text-white font-mono font-bold">210×297</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="font-bold text-xs text-slate-900">Potret (Portrait A4)</p>
                        {config.orientation === 'portrait' && <Check className="w-4 h-4 text-indigo-600" />}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">Tegak memanjang, ruang optimal untuk rincian materi</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Pilihan Desain Template Background */}
              <div className="pt-4 border-t border-slate-100">
                <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide flex items-center gap-2">
                  <Palette className="w-4 h-4 text-indigo-600" /> Desain Template Sertifikat
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">Template bawaan polos tanpa logo atau upload file kustom.</p>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 mt-3">
                  {/* Preset 1: Gold Classic */}
                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, presetTheme: 'gold' })}
                    className={`p-3 rounded-2xl border-2 text-left transition-all ${
                      config.presetTheme === 'gold'
                        ? 'border-amber-500 bg-amber-50/70 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="h-12 rounded-lg bg-gradient-to-r from-amber-700 via-amber-500 to-amber-600 flex items-center justify-center text-white font-bold text-xs shadow-xs mb-2">
                      <Award className="w-5 h-5 text-amber-100" />
                    </div>
                    <p className="font-bold text-xs text-slate-800">Gold Classic</p>
                    <p className="text-[10px] text-slate-400">Formal dengan ornamen emas murni tanpa logo</p>
                  </button>

                  {/* Preset 2: Maritime Navy */}
                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, presetTheme: 'navy' })}
                    className={`p-3 rounded-2xl border-2 text-left transition-all ${
                      config.presetTheme === 'navy'
                        ? 'border-indigo-600 bg-indigo-50/70 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="h-12 rounded-lg bg-gradient-to-r from-slate-900 via-indigo-900 to-blue-900 flex items-center justify-center text-white font-bold text-xs shadow-xs mb-2">
                      <Sparkles className="w-5 h-5 text-cyan-300" />
                    </div>
                    <p className="font-bold text-xs text-slate-800">Corporate Navy</p>
                    <p className="text-[10px] text-slate-400">Elegan nuansa biru gelap profesional</p>
                  </button>

                  {/* Preset 3: Modern Minimalist */}
                  <button
                    type="button"
                    onClick={() => setConfig({ ...config, presetTheme: 'modern' })}
                    className={`p-3 rounded-2xl border-2 text-left transition-all ${
                      config.presetTheme === 'modern'
                        ? 'border-emerald-600 bg-emerald-50/70 shadow-sm'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="h-12 rounded-lg bg-gradient-to-r from-emerald-800 via-teal-700 to-slate-900 flex items-center justify-center text-white font-bold text-xs shadow-xs mb-2">
                      <FileText className="w-5 h-5 text-emerald-200" />
                    </div>
                    <p className="font-bold text-xs text-slate-800">Emerald Clean</p>
                    <p className="text-[10px] text-slate-400">Minimalis kontemporer dengan lis hijau zamrud</p>
                  </button>

                  {/* Upload Custom Template */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className={`p-3 rounded-2xl border-2 border-dashed cursor-pointer text-left transition-all flex flex-col justify-between ${
                      config.presetTheme === 'custom'
                        ? 'border-indigo-600 bg-indigo-50/70 shadow-sm'
                        : 'border-slate-300 hover:border-indigo-400 bg-white'
                    }`}
                  >
                    <div className="h-12 rounded-lg bg-slate-100 border border-slate-200 flex flex-col items-center justify-center text-slate-600 text-xs shadow-2xs mb-2">
                      <Upload className="w-4 h-4 text-indigo-600 mb-0.5" />
                      <span className="text-[9px] font-bold">Upload Background</span>
                    </div>
                    <div>
                      <p className="font-bold text-xs text-slate-800">Upload Kustom</p>
                      <p className="text-[10px] text-slate-400">Gunakan file template sendiri (PNG/JPG)</p>
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleCustomTemplateUpload}
                      className="hidden"
                    />
                  </div>
                </div>
              </div>

              {/* Form Input Detail Teks Sertifikat */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-100">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Judul Sertifikat</label>
                  <input
                    type="text"
                    value={config.judulSertifikat}
                    onChange={(e) => setConfig({ ...config, judulSertifikat: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-bold bg-slate-50 outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Nomor Sertifikat</label>
                  <input
                    type="text"
                    value={config.nomorFormat}
                    onChange={(e) => setConfig({ ...config, nomorFormat: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-mono font-bold bg-slate-50 outline-none focus:border-indigo-600"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Sub-Judul / Teks Penerima</label>
                  <input
                    type="text"
                    value={config.subJudul}
                    onChange={(e) => setConfig({ ...config, subJudul: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-medium bg-slate-50 outline-none focus:border-indigo-600"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Deskripsi / Teks Apresiasi</label>
                  <textarea
                    rows={2}
                    value={config.deskripsiPencapaian}
                    onChange={(e) => setConfig({ ...config, deskripsiPencapaian: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-medium bg-slate-50 outline-none focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Nama Penandatangan 1</label>
                  <input
                    type="text"
                    value={config.penandatanganNama}
                    onChange={(e) => setConfig({ ...config, penandatanganNama: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-bold bg-slate-50 outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Jabatan Penandatangan 1</label>
                  <input
                    type="text"
                    value={config.penandatanganJabatan}
                    onChange={(e) => setConfig({ ...config, penandatanganJabatan: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs bg-slate-50 outline-none focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Nama Penandatangan 2 (Instruktur)</label>
                  <input
                    type="text"
                    value={config.penandatanganNama2}
                    onChange={(e) => setConfig({ ...config, penandatanganNama2: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-bold bg-slate-50 outline-none focus:border-indigo-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Jabatan Penandatangan 2</label>
                  <input
                    type="text"
                    value={config.penandatanganJabatan2}
                    onChange={(e) => setConfig({ ...config, penandatanganJabatan2: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs bg-slate-50 outline-none focus:border-indigo-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Tanggal Terbit &amp; Lokasi</label>
                  <input
                    type="text"
                    value={config.tanggalTerbit}
                    onChange={(e) => setConfig({ ...config, tanggalTerbit: e.target.value })}
                    className="w-full border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-bold bg-slate-50 outline-none focus:border-indigo-600"
                  />
                </div>

                <div className="flex items-center gap-6 pt-5">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
                    <input
                      type="checkbox"
                      checked={config.showQrCode}
                      onChange={(e) => setConfig({ ...config, showQrCode: e.target.checked })}
                      className="w-4 h-4 rounded text-indigo-600"
                    />
                    Tampilkan QR Code Verifikasi
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
                    <input
                      type="checkbox"
                      checked={config.showNilai}
                      onChange={(e) => setConfig({ ...config, showNilai: e.target.checked })}
                      className="w-4 h-4 rounded text-indigo-600"
                    />
                    Tampilkan Nilai &amp; Predikat
                  </label>
                </div>
              </div>

              {/* Rich Text Word-Like Editor untuk Input Materi Pelatihan */}
              <div className="pt-4 border-t border-slate-100 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-wide flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-indigo-600" /> Input Materi Pelatihan (Editor Format Word)
                    </h4>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Tulis atau sesuaikan rincian silabus materi, kompetensi, atau modul kurikulum dengan format Word.
                    </p>
                  </div>

                  <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-xl border border-indigo-200">
                    <input
                      type="checkbox"
                      checked={!!config.showMateriDetails}
                      onChange={(e) => setConfig({ ...config, showMateriDetails: e.target.checked })}
                      className="w-4 h-4 rounded text-indigo-600"
                    />
                    Tampilkan Rincian Materi pada Lembar Sertifikat
                  </label>
                </div>

                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200">
                  <WordEditor
                    value={config.materiRichText || ''}
                    onChange={(newHtml) => setConfig({ ...config, materiRichText: newHtml })}
                    placeholder="Ketik silabus materi pelatihan, poin-poin kompetensi, atau rincian jam pelajaran..."
                    minHeight="180px"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('preview')}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-md transition-transform active:scale-95"
                >
                  <CheckCircle className="w-4 h-4" /> Terapkan &amp; Lihat Preview
                </button>
              </div>
            </div>
          )}

          {/* Interactive Direct Element Manipulation Toolbar (Preview Mode) */}
          {activeTab === 'preview' && (
            <div className="w-full max-w-5xl bg-white border border-slate-200 rounded-2xl p-3 mb-3 shadow-xs flex flex-wrap items-center justify-between gap-3 animate-fade-in">
              <div className="flex items-center gap-2.5 flex-wrap">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-900 text-xs font-bold">
                  <Move className="w-4 h-4 text-indigo-600" />
                  <span>Mode Geser Elemen:</span>
                  <button
                    type="button"
                    onClick={() => setIsDragModeActive(!isDragModeActive)}
                    className={`ml-1 px-2 py-0.5 rounded-md text-[10px] font-black uppercase transition-all shadow-2xs ${
                      isDragModeActive 
                        ? 'bg-indigo-600 text-white ring-2 ring-indigo-300' 
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {isDragModeActive ? 'Aktif (ON)' : 'Terkunci (OFF)'}
                  </button>
                </div>

                <p className="text-[11px] text-slate-500 hidden md:block">
                  💡 <strong>Geser Langsung di Preview:</strong> Klik &amp; tarik teks, nomor, judul, materi, atau tanda tangan untuk memindahkannya.
                </p>
              </div>

              {/* Selected Element Controls & Reset */}
              <div className="flex items-center gap-2 ml-auto flex-wrap">
                {selectedElementId ? (
                  <div className="flex items-center gap-1.5 bg-indigo-50/70 border border-indigo-200 px-2.5 py-1 rounded-xl text-xs animate-fade-in">
                    <span className="font-bold text-indigo-950 text-[11px] flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping" />
                      {getElementLabel(selectedElementId)}
                    </span>

                    {/* Precise Nudge Arrows */}
                    <div className="flex items-center border border-slate-300 rounded-lg bg-white overflow-hidden ml-1 shadow-2xs">
                      <button
                        type="button"
                        onClick={() => nudgeSelectedElement(0, -3)}
                        className="p-1 hover:bg-slate-100 text-slate-700"
                        title="Geser Atas (Panah Atas)"
                      >
                        <ArrowUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => nudgeSelectedElement(0, 3)}
                        className="p-1 hover:bg-slate-100 text-slate-700"
                        title="Geser Bawah (Panah Bawah)"
                      >
                        <ArrowDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => nudgeSelectedElement(-3, 0)}
                        className="p-1 hover:bg-slate-100 text-slate-700"
                        title="Geser Kiri (Panah Kiri)"
                      >
                        <ArrowLeft className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => nudgeSelectedElement(3, 0)}
                        className="p-1 hover:bg-slate-100 text-slate-700"
                        title="Geser Kanan (Panah Kanan)"
                      >
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <button
                      type="button"
                      onClick={resetSelectedElement}
                      className="text-[10px] text-indigo-700 hover:text-indigo-900 font-bold px-2 py-0.5 rounded bg-white border border-indigo-200 shadow-2xs hover:bg-indigo-50"
                      title="Kembalikan posisi elemen ini ke default"
                    >
                      Reset Elemen
                    </button>
                  </div>
                ) : null}

                <button
                  type="button"
                  onClick={resetAllElements}
                  className="px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-2xs"
                  title="Kembalikan seluruh elemen ke posisi awal"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                  <span>Reset Semua Posisi</span>
                </button>
              </div>
            </div>
          )}

          {/* Certificate Canvas / Sheet Container (Standard A4 Dimensions: Landscape 297x210mm vs Portrait 210x297mm) */}
          <div className="w-full overflow-x-auto flex justify-center py-2">
            <div
              ref={certificateRef}
              id="printable-certificate"
              style={{
                width: isPortrait ? '742px' : '1050px',
                minWidth: isPortrait ? '742px' : '1050px',
                height: isPortrait ? '1050px' : '742px',
                minHeight: isPortrait ? '1050px' : '742px',
                backgroundImage: config.presetTheme === 'custom' && config.customTemplateImage ? `url(${config.customTemplateImage})` : undefined,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
              className={`relative bg-white shadow-2xl rounded-sm p-10 flex flex-col justify-between overflow-hidden select-none border border-slate-300 ${
                config.presetTheme === 'gold' ? 'border-[16px] border-[#cbb06d]' :
                config.presetTheme === 'navy' ? 'border-[16px] border-[#0f172a]' :
                config.presetTheme === 'modern' ? 'border-[14px] border-[#047857]' : ''
              }`}
            >
              {/* Inner Decorative Framing for Presets */}
              {config.presetTheme === 'gold' && (
                <>
                  <div className="absolute inset-3 border-2 border-dashed border-[#b89547] pointer-events-none opacity-80" />
                  <div className="absolute inset-5 border border-[#e4cb8d] pointer-events-none" />
                  {/* Decorative Corner Ornaments */}
                  <div className="absolute top-6 left-6 w-12 h-12 border-t-4 border-l-4 border-[#b89547]" />
                  <div className="absolute top-6 right-6 w-12 h-12 border-t-4 border-r-4 border-[#b89547]" />
                  <div className="absolute bottom-6 left-6 w-12 h-12 border-b-4 border-l-4 border-[#b89547]" />
                  <div className="absolute bottom-6 right-6 w-12 h-12 border-b-4 border-r-4 border-[#b89547]" />
                </>
              )}

              {config.presetTheme === 'navy' && (
                <>
                  <div className="absolute inset-3 border border-indigo-200 pointer-events-none" />
                  <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-indigo-900/10 via-blue-800/5 to-transparent pointer-events-none" />
                  <div className="absolute bottom-0 left-0 w-64 h-64 bg-gradient-to-tr from-indigo-900/10 via-blue-800/5 to-transparent pointer-events-none" />
                </>
              )}

              {config.presetTheme === 'modern' && (
                <>
                  <div className="absolute inset-4 border border-teal-200 pointer-events-none" />
                  <div className="absolute top-0 left-0 right-0 h-3 bg-gradient-to-r from-teal-600 via-emerald-500 to-indigo-600" />
                </>
              )}

              {/* Certificate Top Header: Clean & Plain without any Corporate Logo, Icon, or Company Name */}
              <div className="relative z-10 text-center space-y-2 pt-2">
                {/* Draggable Certificate Number Badge */}
                <DraggableElement
                  id="nomor"
                  label="Nomor Sertifikat"
                  position={positions['nomor'] || { x: 0, y: 0 }}
                  isDragEnabled={isDragModeActive}
                  isSelected={selectedElementId === 'nomor'}
                  isExporting={isExporting}
                  onSelect={setSelectedElementId}
                  onDragStart={handleElementDragStart}
                  className="inline-block"
                >
                  <div className="inline-block px-5 py-1.5 bg-slate-50 border border-slate-200 rounded-full font-mono font-bold text-xs text-slate-600 tracking-widest shadow-2xs">
                    NO: {config.nomorFormat}
                  </div>
                </DraggableElement>

                {/* Draggable Judul Sertifikat & Sub-Judul */}
                <DraggableElement
                  id="judul"
                  label="Judul Sertifikat"
                  position={positions['judul'] || { x: 0, y: 0 }}
                  isDragEnabled={isDragModeActive}
                  isSelected={selectedElementId === 'judul'}
                  isExporting={isExporting}
                  onSelect={setSelectedElementId}
                  onDragStart={handleElementDragStart}
                  className="space-y-1"
                >
                  <h1 
                    className={`${isPortrait ? 'text-3xl' : 'text-3xl sm:text-4xl'} font-black uppercase tracking-widest ${
                      config.presetTheme === 'gold' ? 'text-[#855e16]' :
                      config.presetTheme === 'navy' ? 'text-[#0f172a]' : 'text-slate-900'
                    }`}
                    style={{ fontFamily: 'Cinzel, serif' }}
                  >
                    {config.judulSertifikat}
                  </h1>
                  
                  <p className="text-xs uppercase tracking-widest text-slate-500 font-bold">
                    {config.subJudul}
                  </p>
                </DraggableElement>
              </div>

              {/* Recipient Details & Achievement */}
              <div className="relative z-10 text-center my-auto py-2 space-y-3">
                {/* Draggable Participant Name */}
                <DraggableElement
                  id="nama"
                  label="Nama Lengkap Peserta"
                  position={positions['nama'] || { x: 0, y: 0 }}
                  isDragEnabled={isDragModeActive}
                  isSelected={selectedElementId === 'nama'}
                  isExporting={isExporting}
                  onSelect={setSelectedElementId}
                  onDragStart={handleElementDragStart}
                  className="inline-block px-8 py-1 max-w-full"
                >
                  <h2 
                    className={`${isPortrait ? 'text-2xl sm:text-3xl' : 'text-3xl sm:text-4xl'} font-extrabold text-slate-900 tracking-wide uppercase break-words`}
                    style={{ fontFamily: 'Playfair Display, serif' }}
                  >
                    {peserta?.nama || 'NAMA LENGKAP PESERTA'}
                  </h2>
                  <div className="w-full h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent mt-2 mx-auto" />
                </DraggableElement>

                {/* Draggable NUP & Unit Info */}
                <DraggableElement
                  id="nup"
                  label="NUP & Unit Kerja"
                  position={positions['nup'] || { x: 0, y: 0 }}
                  isDragEnabled={isDragModeActive}
                  isSelected={selectedElementId === 'nup'}
                  isExporting={isExporting}
                  onSelect={setSelectedElementId}
                  onDragStart={handleElementDragStart}
                >
                  <div className="flex items-center justify-center gap-3 text-xs font-bold text-slate-600">
                    <span>NUP: <span className="font-mono text-indigo-700 font-extrabold">{peserta?.nup || '-'}</span></span>
                    {peserta?.unit && (
                      <>
                        <span>•</span>
                        <span>DIVISI / UNIT: <span className="text-slate-800 font-extrabold">{peserta.unit}</span></span>
                      </>
                    )}
                  </div>
                </DraggableElement>

                {/* Draggable Description / Appreciation Text */}
                <DraggableElement
                  id="deskripsi"
                  label="Teks Apresiasi"
                  position={positions['deskripsi'] || { x: 0, y: 0 }}
                  isDragEnabled={isDragModeActive}
                  isSelected={selectedElementId === 'deskripsi'}
                  isExporting={isExporting}
                  onSelect={setSelectedElementId}
                  onDragStart={handleElementDragStart}
                >
                  <p className="text-xs max-w-2xl mx-auto text-slate-600 leading-relaxed font-medium">
                    {config.deskripsiPencapaian}
                  </p>
                </DraggableElement>

                {/* Draggable Training Title */}
                <DraggableElement
                  id="materi"
                  label="Judul Materi Pelatihan"
                  position={positions['materi'] || { x: 0, y: 0 }}
                  isDragEnabled={isDragModeActive}
                  isSelected={selectedElementId === 'materi'}
                  isExporting={isExporting}
                  onSelect={setSelectedElementId}
                  onDragStart={handleElementDragStart}
                  className="inline-block max-w-2xl"
                >
                  <div className="px-6 py-2 rounded-xl bg-slate-50 border border-slate-200/90 shadow-2xs">
                    <h3 
                      className={`${isPortrait ? 'text-base' : 'text-base sm:text-lg'} font-black text-indigo-950 uppercase tracking-tight`}
                      style={{ fontFamily: 'Cinzel, serif' }}
                    >
                      "{materi?.judul || config.materiJudul}"
                    </h3>
                    {materi?.folder && (
                      <p className="text-[11px] font-bold text-indigo-600 uppercase mt-0.5">
                        Kategori Program: {materi.folder}
                      </p>
                    )}
                  </div>
                </DraggableElement>

                {/* Draggable Optional Rich Text Material Syllabus Box (Word Format) */}
                {config.showMateriDetails && config.materiRichText && (
                  <DraggableElement
                    id="materiDetail"
                    label="Silabus Rincian Materi (Word)"
                    position={positions['materiDetail'] || { x: 0, y: 0 }}
                    isDragEnabled={isDragModeActive}
                    isSelected={selectedElementId === 'materiDetail'}
                    isExporting={isExporting}
                    onSelect={setSelectedElementId}
                    onDragStart={handleElementDragStart}
                    className="max-w-2xl mx-auto"
                  >
                    <div className="text-left bg-slate-50/90 border border-slate-200 rounded-xl p-3 shadow-2xs text-[11px] text-slate-700 leading-normal max-h-44 overflow-y-auto">
                      <div 
                        className="prose prose-xs max-w-none text-slate-700"
                        dangerouslySetInnerHTML={{ __html: config.materiRichText }}
                      />
                    </div>
                  </DraggableElement>
                )}

                {/* Draggable Grade & Predicate */}
                {config.showNilai && (
                  <DraggableElement
                    id="nilai"
                    label="Nilai & Predikat"
                    position={positions['nilai'] || { x: 0, y: 0 }}
                    isDragEnabled={isDragModeActive}
                    isSelected={selectedElementId === 'nilai'}
                    isExporting={isExporting}
                    onSelect={setSelectedElementId}
                    onDragStart={handleElementDragStart}
                  >
                    <div className="flex items-center justify-center gap-2 text-xs font-black">
                      <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300 shadow-2xs">
                        Nilai Akhir: {grade}/100
                      </span>
                      <span className="px-3 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-300 shadow-2xs">
                        {predicate}
                      </span>
                    </div>
                  </DraggableElement>
                )}
              </div>

              {/* Certificate Bottom Signatures & Seal */}
              <div className="relative z-10 pt-4 flex items-end justify-between px-6 sm:px-10">
                {/* Draggable Signer 1 */}
                <DraggableElement
                  id="ttd1"
                  label="Penandatangan 1"
                  position={positions['ttd1'] || { x: 0, y: 0 }}
                  isDragEnabled={isDragModeActive}
                  isSelected={selectedElementId === 'ttd1'}
                  isExporting={isExporting}
                  onSelect={setSelectedElementId}
                  onDragStart={handleElementDragStart}
                >
                  <div className="text-center w-52 sm:w-60">
                    <p className="text-[11px] font-bold text-slate-500 mb-8">{config.tanggalTerbit}</p>
                    <p className="text-sm font-black text-slate-900 border-b border-slate-400 pb-1 leading-snug">
                      {config.penandatanganNama}
                    </p>
                    <p className="text-[10px] text-slate-600 font-semibold mt-1">
                      {config.penandatanganJabatan}
                    </p>
                  </div>
                </DraggableElement>

                {/* Draggable Center Seal / QR Code */}
                <DraggableElement
                  id="seal"
                  label="Segel / QR Code"
                  position={positions['seal'] || { x: 0, y: 0 }}
                  isDragEnabled={isDragModeActive}
                  isSelected={selectedElementId === 'seal'}
                  isExporting={isExporting}
                  onSelect={setSelectedElementId}
                  onDragStart={handleElementDragStart}
                >
                  <div className="text-center flex flex-col items-center">
                    {config.showQrCode ? (
                      <div className="p-2 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col items-center">
                        <div className="w-14 h-14 bg-slate-900 rounded-lg flex items-center justify-center text-white">
                          <QrCode className="w-10 h-10 text-slate-100" />
                        </div>
                        <span className="text-[8px] font-mono font-bold text-slate-400 mt-1 uppercase tracking-wider">OFFICIAL SEAL</span>
                      </div>
                    ) : (
                      <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-amber-500 to-amber-300 border-4 border-amber-600 flex items-center justify-center text-white shadow-md">
                        <Award className="w-7 h-7 text-amber-900" />
                      </div>
                    )}
                  </div>
                </DraggableElement>

                {/* Draggable Signer 2: Instructor */}
                <DraggableElement
                  id="ttd2"
                  label="Penandatangan 2 (Instruktur)"
                  position={positions['ttd2'] || { x: 0, y: 0 }}
                  isDragEnabled={isDragModeActive}
                  isSelected={selectedElementId === 'ttd2'}
                  isExporting={isExporting}
                  onSelect={setSelectedElementId}
                  onDragStart={handleElementDragStart}
                >
                  <div className="text-center w-52 sm:w-60">
                    <p className="text-[11px] font-bold text-slate-500 mb-8">Instruktur Pembimbing</p>
                    <p className="text-sm font-black text-slate-900 border-b border-slate-400 pb-1 leading-snug">
                      {config.penandatanganNama2}
                    </p>
                    <p className="text-[10px] text-slate-600 font-semibold mt-1">
                      {config.penandatanganJabatan2}
                    </p>
                  </div>
                </DraggableElement>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Actions Footer */}
        <div className="px-6 py-4 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span>
              Standar Dimensi: A4 {isPortrait ? 'Potret (210 × 297 mm)' : 'Lanskap (297 × 210 mm)'} • Resolusi Cetak 300 DPI
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-4 h-4 text-slate-500" /> Print
            </button>
            <button
              type="button"
              onClick={downloadPNG}
              disabled={isExporting}
              className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <ImageIcon className="w-4 h-4 text-slate-500" /> Download PNG
            </button>
            <button
              type="button"
              onClick={downloadPDF}
              disabled={isExporting}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all active:scale-[0.98] disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              {isExporting ? 'Memproses PDF...' : `Unduh Format PDF (${isPortrait ? 'Potret' : 'Lanskap'})`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
