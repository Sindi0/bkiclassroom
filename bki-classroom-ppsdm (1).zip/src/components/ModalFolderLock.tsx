import React, { useState, useEffect } from 'react';
import { X, Lock, Key, Save, ShieldCheck } from 'lucide-react';
import { FolderLock } from '../types';

interface ModalFolderLockProps {
  isOpen: boolean;
  onClose: () => void;
  folderName: string;
  currentLock: FolderLock | null;
  onSave: (folderName: string, password: string) => void;
  ownerName: string;
}

export const ModalFolderLock: React.FC<ModalFolderLockProps> = ({
  isOpen,
  onClose,
  folderName,
  currentLock,
  onSave,
  ownerName
}) => {
  const [password, setPassword] = useState('');

  useEffect(() => {
    setPassword(currentLock?.password || '');
  }, [currentLock, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(folderName, password.trim());
  };

  const isLocked = !!(password && password.trim());

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl border border-slate-100">
        <div className="flex justify-between items-center mb-5 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900 uppercase">Atur Sandi Folder</h3>
              <p className="text-xs text-slate-400 font-medium truncate max-w-[220px]">{folderName}</p>
            </div>
          </div>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-rose-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-semibold">Pemilik Folder:</span>
              <span className="font-bold text-slate-800">{ownerName}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-semibold">Status Proteksi:</span>
              <span className={`font-black ${isLocked ? 'text-rose-600' : 'text-emerald-600'}`}>
                {isLocked ? 'TERKUNCI DENGAN PASSWORD' : 'TERBUKA / UMUM'}
              </span>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
              Kata Sandi / PIN Folder
            </label>
            <div className="relative">
              <Key className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Ketik kata sandi untuk mengunci folder"
                className="w-full border-2 border-slate-200 rounded-xl pl-11 pr-4 py-2.5 text-xs font-mono font-bold outline-none focus:border-amber-500 bg-slate-50 focus:bg-white transition-all"
              />
            </div>
            <p className="text-[10px] text-slate-400 mt-1">
              *Kosongkan isian kata sandi bila ingin membuka folder menjadi umum tanpa kunci.
            </p>
          </div>

          <div className="flex gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 font-bold text-slate-400 uppercase text-xs hover:bg-slate-50 rounded-xl border border-slate-200 transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="flex-1 bg-amber-500 hover:bg-amber-600 text-white py-3 rounded-xl font-bold uppercase text-xs shadow-md transition-colors flex items-center justify-center gap-1.5"
            >
              <Save className="w-4 h-4" /> Simpan Pengaturan
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
