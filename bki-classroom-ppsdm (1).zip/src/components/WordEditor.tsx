import React, { useRef, useState, useEffect } from 'react';
import { 
  Bold, 
  Italic, 
  Underline, 
  Strikethrough, 
  AlignLeft, 
  AlignCenter, 
  AlignRight, 
  AlignJustify, 
  List, 
  ListOrdered, 
  Heading1, 
  Heading2, 
  Heading3, 
  Quote, 
  Table as TableIcon, 
  Link as LinkIcon, 
  Minus, 
  RotateCcw, 
  RotateCw, 
  RemoveFormatting, 
  Highlighter, 
  Palette,
  FileText
} from 'lucide-react';

interface WordEditorProps {
  value: string;
  onChange: (content: string) => void;
  placeholder?: string;
  minHeight?: string;
}

export const WordEditor: React.FC<WordEditorProps> = ({
  value,
  onChange,
  placeholder = "Ketik atau paste materi pelatihan di sini seperti di Microsoft Word...",
  minHeight = "240px"
}) => {
  const editorRef = useRef<HTMLDivElement>(null);
  const [selectedTextColor, setSelectedTextColor] = useState('#0f172a');
  const [selectedBgColor, setSelectedBgColor] = useState('#fef08a');
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showHighlightPicker, setShowHighlightPicker] = useState(false);
  const [isFocused, setIsFocused] = useState(false);

  // Sync internal innerHTML only when value changes externally (not during active typing)
  useEffect(() => {
    if (editorRef.current && editorRef.current.innerHTML !== value) {
      // If editor is not focused, update it
      if (!isFocused || !editorRef.current.innerHTML.trim()) {
        editorRef.current.innerHTML = value || '';
      }
    }
  }, [value, isFocused]);

  const exec = (command: string, val: string | undefined = undefined) => {
    document.execCommand(command, false, val);
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const insertTable = () => {
    const rows = prompt("Jumlah baris tabel:", "3");
    const cols = prompt("Jumlah kolom tabel:", "3");
    if (!rows || !cols) return;
    const r = parseInt(rows, 10);
    const c = parseInt(cols, 10);
    if (isNaN(r) || isNaN(c) || r <= 0 || c <= 0) return;

    let tableHtml = '<table border="1" style="width:100%; border-collapse: collapse; margin: 12px 0; border: 1px solid #cbd5e1;">';
    tableHtml += '<thead><tr style="background-color: #f1f5f9;">';
    for (let j = 0; j < c; j++) {
      tableHtml += `<th style="padding: 8px; border: 1px solid #cbd5e1; font-weight: bold; text-align: left;">Header ${j + 1}</th>`;
    }
    tableHtml += '</tr></thead><tbody>';
    for (let i = 0; i < r; i++) {
      tableHtml += '<tr>';
      for (let j = 0; j < c; j++) {
        tableHtml += `<td style="padding: 8px; border: 1px solid #cbd5e1;">Data ${i + 1}-${j + 1}</td>`;
      }
      tableHtml += '</tr>';
    }
    tableHtml += '</tbody></table><p><br></p>';
    exec('insertHTML', tableHtml);
  };

  const insertLink = () => {
    const url = prompt("Masukkan URL Tautan Web:", "https://");
    if (url && url !== "https://") {
      exec('createLink', url);
    }
  };

  const handleInput = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  return (
    <div className="border border-slate-300 rounded-2xl overflow-hidden bg-white shadow-xs focus-within:border-indigo-600 focus-within:ring-2 focus-within:ring-indigo-100 transition-all">
      {/* Word-like Ribbon Toolbar */}
      <div className="bg-slate-50 border-b border-slate-200 p-2 flex flex-wrap items-center gap-1 text-slate-700 select-none">
        {/* Undo / Redo */}
        <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
          <button
            type="button"
            onClick={() => exec('undo')}
            className="p-1.5 hover:bg-slate-100 rounded text-slate-600 transition-colors"
            title="Undo (Ctrl+Z)"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('redo')}
            className="p-1.5 hover:bg-slate-100 rounded text-slate-600 transition-colors"
            title="Redo (Ctrl+Y)"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="h-5 w-[1px] bg-slate-200 mx-0.5" />

        {/* Headings */}
        <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
          <button
            type="button"
            onClick={() => exec('formatBlock', '<h1>')}
            className="px-2 py-1 hover:bg-indigo-50 hover:text-indigo-600 rounded text-xs font-bold transition-colors flex items-center gap-1"
            title="Judul Utama (H1)"
          >
            <Heading1 className="w-3.5 h-3.5" /> H1
          </button>
          <button
            type="button"
            onClick={() => exec('formatBlock', '<h2>')}
            className="px-2 py-1 hover:bg-indigo-50 hover:text-indigo-600 rounded text-xs font-bold transition-colors flex items-center gap-1"
            title="Sub Judul (H2)"
          >
            <Heading2 className="w-3.5 h-3.5" /> H2
          </button>
          <button
            type="button"
            onClick={() => exec('formatBlock', '<h3>')}
            className="px-2 py-1 hover:bg-indigo-50 hover:text-indigo-600 rounded text-xs font-bold transition-colors flex items-center gap-1"
            title="Sub-Bab (H3)"
          >
            <Heading3 className="w-3.5 h-3.5" /> H3
          </button>
          <button
            type="button"
            onClick={() => exec('formatBlock', '<p>')}
            className="px-2 py-1 hover:bg-indigo-50 hover:text-indigo-600 rounded text-xs font-semibold transition-colors flex items-center gap-1"
            title="Paragraf Biasa"
          >
            <FileText className="w-3.5 h-3.5" /> Normal
          </button>
        </div>

        <div className="h-5 w-[1px] bg-slate-200 mx-0.5" />

        {/* Text Formats */}
        <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
          <button
            type="button"
            onClick={() => exec('bold')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Tebal (Bold)"
          >
            <Bold className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('italic')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Miring (Italic)"
          >
            <Italic className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('underline')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Garis Bawah (Underline)"
          >
            <Underline className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('strikeThrough')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Coret (Strikethrough)"
          >
            <Strikethrough className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="h-5 w-[1px] bg-slate-200 mx-0.5" />

        {/* Colors & Highlight */}
        <div className="relative flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
          {/* Text Color */}
          <div className="relative">
            <button
              type="button"
              onClick={() => { setShowColorPicker(!showColorPicker); setShowHighlightPicker(false); }}
              className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors flex items-center gap-1"
              title="Warna Font"
            >
              <Palette className="w-3.5 h-3.5" />
              <span className="w-2.5 h-1 rounded-sm block" style={{ backgroundColor: selectedTextColor }} />
            </button>
            {showColorPicker && (
              <div className="absolute top-full left-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl p-2 z-50 flex gap-1.5">
                {['#0f172a', '#2563eb', '#dc2626', '#16a34a', '#d97706', '#9333ea'].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      setSelectedTextColor(c);
                      exec('foreColor', c);
                      setShowColorPicker(false);
                    }}
                    className="w-5 h-5 rounded-full border border-slate-300 hover:scale-110 transition-transform"
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Highlight Color */}
          <div className="relative">
            <button
              type="button"
              onClick={() => { setShowHighlightPicker(!showHighlightPicker); setShowColorPicker(false); }}
              className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors flex items-center gap-1"
              title="Warna Stabilo (Highlight)"
            >
              <Highlighter className="w-3.5 h-3.5" />
              <span className="w-2.5 h-1 rounded-sm block" style={{ backgroundColor: selectedBgColor }} />
            </button>
            {showHighlightPicker && (
              <div className="absolute top-full left-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-xl p-2 z-50 flex gap-1.5">
                {['#fef08a', '#bbf7d0', '#fed7aa', '#fbcfe8', '#bae6fd'].map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      setSelectedBgColor(c);
                      exec('hiliteColor', c);
                      setShowHighlightPicker(false);
                    }}
                    className="w-5 h-5 rounded-full border border-slate-300 hover:scale-110 transition-transform"
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="h-5 w-[1px] bg-slate-200 mx-0.5" />

        {/* Alignments */}
        <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
          <button
            type="button"
            onClick={() => exec('justifyLeft')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Rata Kiri"
          >
            <AlignLeft className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('justifyCenter')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Rata Tengah"
          >
            <AlignCenter className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('justifyRight')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Rata Kanan"
          >
            <AlignRight className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('justifyFull')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Rata Kanan-Kiri (Justify)"
          >
            <AlignJustify className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="h-5 w-[1px] bg-slate-200 mx-0.5" />

        {/* Lists & Extras */}
        <div className="flex items-center bg-white border border-slate-200 rounded-lg p-0.5 shadow-2xs">
          <button
            type="button"
            onClick={() => exec('insertUnorderedList')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Daftar Poin (Bullets)"
          >
            <List className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('insertOrderedList')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Daftar Angka (Numbering)"
          >
            <ListOrdered className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('formatBlock', '<blockquote>')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Kutipan / Catatan Penting"
          >
            <Quote className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={insertTable}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors text-indigo-600"
            title="Sisipkan Tabel Word"
          >
            <TableIcon className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={insertLink}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Sisipkan Tautan (Link)"
          >
            <LinkIcon className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('insertHorizontalRule')}
            className="p-1.5 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors"
            title="Garis Pembatas Horizontal"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => exec('removeFormat')}
            className="p-1.5 hover:bg-rose-50 hover:text-rose-600 rounded transition-colors text-slate-400"
            title="Hapus Pemformatan"
          >
            <RemoveFormatting className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Word Page Editing Surface */}
      <div className="bg-slate-100/60 p-3 sm:p-5 flex justify-center">
        <div className="w-full bg-white rounded-xl shadow-xs border border-slate-200/80 p-5 sm:p-7 min-h-[160px]">
          <div
            ref={editorRef}
            contentEditable
            onInput={handleInput}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            style={{ minHeight }}
            data-placeholder={placeholder}
            className="outline-none text-slate-800 text-sm leading-relaxed prose prose-slate max-w-none empty:before:content-[attr(data-placeholder)] empty:before:text-slate-400 empty:before:italic"
          />
        </div>
      </div>
      
      {/* Footer Info */}
      <div className="px-4 py-1.5 bg-slate-50 border-t border-slate-200 text-[10px] text-slate-400 flex items-center justify-between">
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> Word Rich-Text Editor Aktif
        </span>
        <span>Format tabel, heading, teks warna tersimpan otomatis</span>
      </div>
    </div>
  );
};
