import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Clock, 
  CheckCircle, 
  CheckCircle2, 
  ExternalLink, 
  MessageSquare, 
  Send, 
  Award, 
  FileText, 
  Download, 
  Sparkles,
  BookOpen,
  FastForward,
  AlertCircle,
  Timer
} from 'lucide-react';
import { Materi, User, ChatMessage } from '../types';

interface LearningViewProps {
  materi: Materi;
  currentUser: User;
  onBack: () => void;
  onToggleSessionDone: (sesiIndex: number) => void;
  onFinishMateri: () => void;
  onOpenCertificate: () => void;
  isFinished: boolean;
  chatMessages: ChatMessage[];
  onSendChat: (pesan: string) => void;
  studyTimeFormatted: string;
  totalStudySeconds: number;
  onAddStudySeconds?: (seconds: number) => void;
}

export const LearningView: React.FC<LearningViewProps> = ({
  materi,
  currentUser,
  onBack,
  onToggleSessionDone,
  onFinishMateri,
  onOpenCertificate,
  isFinished,
  chatMessages,
  onSendChat,
  studyTimeFormatted,
  totalStudySeconds,
  onAddStudySeconds
}) => {
  const [activeSessionIndex, setActiveSessionIndex] = useState(0);
  const [chatInput, setChatInput] = useState('');

  const sessions = materi.sesi || [];
  const userDoneMap = materi.selesaiSesi?.[currentUser.nup] || {};
  const completedCount = sessions.filter((_, idx) => !!userDoneMap[idx]).length;
  const progressPct = sessions.length > 0 ? Math.round((completedCount / sessions.length) * 100) : 0;
  const isAllSessionsDone = progressPct === 100;

  // Waktu Pembelajaran Minimal: 8 Jam (1 Hari Kerja)
  const minRequiredHours = materi.minimalJam || 8;
  const minRequiredSeconds = minRequiredHours * 3600; // 8 * 3600 = 28,800 detik
  const isTimeRequirementMet = totalStudySeconds >= minRequiredSeconds;
  const timeProgressPct = Math.min(100, Math.round((totalStudySeconds / minRequiredSeconds) * 100));

  const totalH = Math.floor(totalStudySeconds / 3600);
  const totalM = Math.floor((totalStudySeconds % 3600) / 60);
  const totalS = totalStudySeconds % 60;

  const remainingSeconds = Math.max(0, minRequiredSeconds - totalStudySeconds);
  const remainingH = Math.floor(remainingSeconds / 3600);
  const remainingM = Math.floor((remainingSeconds % 3600) / 60);

  // Participant must finish all sessions AND satisfy the 8-hour / 1-working-day requirement (or is trainer/admin)
  const canFinish = isAllSessionsDone && (isTimeRequirementMet || currentUser.isTrainer || currentUser.isSuperAdmin);

  const currentActiveSession = sessions[activeSessionIndex] || sessions[0];

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    onSendChat(chatInput.trim());
    setChatInput('');
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in pb-12">
      {/* Top Banner Header with Cover Image & Live Timer */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="relative h-48 md:h-64 w-full bg-gradient-to-r from-indigo-700 via-indigo-900 to-slate-900 flex items-end p-6 md:p-8 text-white">
          {materi.gambar && (
            <img
              src={materi.gambar}
              alt={materi.judul}
              className="absolute inset-0 w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/40 to-transparent" />
          
          <div className="relative z-10 w-full flex items-end justify-between flex-wrap gap-4">
            <div>
              <div className="flex items-center gap-2 mb-2 flex-wrap">
                <span className="px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-[10px] font-black uppercase tracking-wider inline-block border border-white/20 text-white">
                  {materi.folder || 'Materi Pembelajaran'}
                </span>
                <span className="px-3 py-1 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider inline-flex items-center gap-1 shadow-sm">
                  <Clock className="w-3 h-3" /> Standar {minRequiredHours} Jam (1 Hari Kerja)
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-black uppercase tracking-tight text-white drop-shadow-md">
                {materi.judul}
              </h2>
              <p className="text-xs text-indigo-200 mt-1">
                Instruktur: <span className="font-bold text-white">{materi.ownerTrainerName || 'Trainer PPSDM'}</span>
              </p>
            </div>

            {/* Live Timer Badges */}
            <div className="flex flex-col sm:flex-row items-end sm:items-center gap-2">
              <div className="bg-white/10 backdrop-blur-md border border-white/20 px-3.5 py-2 rounded-2xl flex items-center gap-2.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <Clock className="w-4 h-4 text-emerald-300" />
                <div className="text-right sm:text-left">
                  <p className="text-[9px] uppercase tracking-wider text-slate-300 font-bold">Sesi Aktif</p>
                  <p className="font-mono font-black text-xs text-emerald-200">{studyTimeFormatted}</p>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-md border border-white/20 px-3.5 py-2 rounded-2xl flex items-center gap-2.5">
                <Timer className="w-4 h-4 text-amber-300" />
                <div className="text-right sm:text-left">
                  <p className="text-[9px] uppercase tracking-wider text-slate-300 font-bold">Total Waktu Belajar</p>
                  <p className="font-mono font-black text-xs text-amber-200">
                    {totalH}j {totalM}m / {minRequiredHours} Jam
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 md:p-8 space-y-6">
          {/* Dual Progress: Kurikulum Sesi & Durasi Pembelajaran 8 Jam */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Progress 1: Kurikulum Sesi */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-slate-600 uppercase flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-indigo-600" />
                  Kurikulum Sesi
                </span>
                <span className={`font-black ${progressPct === 100 ? 'text-emerald-600' : 'text-indigo-600'}`}>
                  {completedCount}/{sessions.length} Sesi ({progressPct}%)
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    progressPct === 100
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                      : 'bg-gradient-to-r from-indigo-500 to-emerald-500'
                  }`}
                  style={{ width: `${progressPct}%` }}
                />
              </div>
              <p className="text-[11px] text-slate-400">
                {progressPct === 100 ? '✓ Seluruh sesi kurikulum telah ditandai selesai' : 'Pelajari dan tandai selesai setiap sesi di bawah.'}
              </p>
            </div>

            {/* Progress 2: Waktu Pembelajaran 8 Jam (1 Hari Kerja) */}
            <div className={`p-4 rounded-2xl border space-y-2 transition-all ${
              isTimeRequirementMet 
                ? 'bg-emerald-50/70 border-emerald-300' 
                : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-slate-700 uppercase flex items-center gap-1.5">
                  <Clock className={`w-4 h-4 ${isTimeRequirementMet ? 'text-emerald-600' : 'text-amber-600'}`} />
                  Waktu Pembelajaran (Min. 8 Jam)
                </span>
                <span className={`font-black ${isTimeRequirementMet ? 'text-emerald-700 font-mono' : 'text-amber-700 font-mono'}`}>
                  {totalH} Jam {totalM} Menit ({timeProgressPct}%)
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    isTimeRequirementMet
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                      : 'bg-gradient-to-r from-amber-500 to-amber-400'
                  }`}
                  style={{ width: `${timeProgressPct}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px]">
                {isTimeRequirementMet ? (
                  <span className="font-bold text-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> Target 8 jam (1 hari kerja) terpenuhi
                  </span>
                ) : (
                  <span className="font-bold text-amber-700 flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" /> Sisa {remainingH} jam {remainingM} menit lagi
                  </span>
                )}
                <span className="text-slate-400 font-mono text-[10px]">
                  {Math.round(totalStudySeconds)} / {minRequiredSeconds} detik
                </span>
              </div>
            </div>
          </div>

          {/* Quick Simulation / Fast-Forward Helper for Testing & Demo */}
          {onAddStudySeconds && !isTimeRequirementMet && (
            <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-2xl flex items-center justify-between flex-wrap gap-2 text-xs">
              <div className="flex items-center gap-2 text-indigo-900 font-bold">
                <FastForward className="w-4 h-4 text-indigo-600 animate-pulse" />
                <span>Simulasi / Tambah Waktu Belajar (Demo &amp; Uji Coba):</span>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={() => onAddStudySeconds(3600)}
                  className="px-2.5 py-1 rounded-lg bg-white border border-indigo-200 text-indigo-700 font-bold text-xs hover:bg-indigo-600 hover:text-white transition-all shadow-2xs"
                  title="Tambah 1 Jam Waktu Belajar"
                >
                  +1 Jam
                </button>
                <button
                  type="button"
                  onClick={() => onAddStudySeconds(4 * 3600)}
                  className="px-2.5 py-1 rounded-lg bg-white border border-indigo-200 text-indigo-700 font-bold text-xs hover:bg-indigo-600 hover:text-white transition-all shadow-2xs"
                  title="Tambah 4 Jam Waktu Belajar"
                >
                  +4 Jam
                </button>
                <button
                  type="button"
                  onClick={() => onAddStudySeconds(minRequiredSeconds)}
                  className="px-3 py-1 rounded-lg bg-indigo-600 text-white font-bold text-xs hover:bg-indigo-700 transition-all shadow-2xs"
                  title="Penuhi 8 Jam Pembelajaran (1 Hari Kerja) Langsung"
                >
                  Penuhi 8 Jam Langsung
                </button>
              </div>
            </div>
          )}

          {/* Certificate Claim Banner if Completed */}
          {isFinished ? (
            <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-500/10 via-amber-500/20 to-amber-500/10 border-2 border-amber-300 flex flex-col sm:flex-row items-center justify-between gap-4 animate-fade-in shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 text-slate-900 flex items-center justify-center text-xl shadow-md font-black shrink-0">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-black text-sm text-slate-900 uppercase flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-600" /> Selamat! Anda Telah Lulus Materi Ini
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Sertifikat resmi kelulusan telah diterbitkan ({minRequiredHours} Jam Pembelajaran / 1 Hari Kerja). Silakan cetak atau unduh dokumen PDF sertifikat Anda.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onOpenCertificate}
                className="w-full sm:w-auto px-5 py-3 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-700 hover:to-amber-600 text-white font-black text-xs uppercase tracking-wider shadow-md flex items-center justify-center gap-2 shrink-0 transition-transform active:scale-95"
              >
                <Download className="w-4 h-4" /> Unduh Sertifikat PDF
              </button>
            </div>
          ) : (
            <div className="text-xs font-bold text-amber-900 bg-amber-50 border border-amber-200 p-4 rounded-2xl flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  <strong>Syarat Kelulusan:</strong> Tuntaskan seluruh <strong>{sessions.length} sesi kurikulum</strong> dan capai waktu pembelajaran minimal <strong>{minRequiredHours} Jam (1 Hari Kerja)</strong> untuk membuka Sertifikat Kelulusan PDF.
                </span>
              </div>
            </div>
          )}

          {/* Sessions List */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-400 mb-3">
              Daftar Sesi Materi Kurikulum
            </h3>

            <div className="space-y-3">
              {sessions.map((sesi, idx) => {
                const isDone = !!userDoneMap[idx];
                const isSelected = activeSessionIndex === idx;

                return (
                  <div
                    key={idx}
                    className={`rounded-2xl border transition-all ${
                      isSelected
                        ? 'border-indigo-600 ring-2 ring-indigo-100 bg-white shadow-xs'
                        : isDone
                        ? 'border-emerald-200 bg-emerald-50/40'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="p-4 flex items-center justify-between gap-3 flex-wrap sm:flex-nowrap">
                      <div
                        onClick={() => setActiveSessionIndex(idx)}
                        className="flex items-center gap-3 cursor-pointer flex-1"
                      >
                        <span
                          className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black shrink-0 ${
                            isDone ? 'bg-emerald-500 text-white shadow-xs' : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {isDone ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                        </span>
                        <div>
                          <p className="font-bold text-sm text-slate-800 leading-snug">
                            {sesi.judul}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            {sesi.link && (
                              <a
                                href={sesi.link}
                                target="_blank"
                                rel="noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="text-[10px] font-bold text-slate-500 hover:text-indigo-600 flex items-center gap-1"
                              >
                                <ExternalLink className="w-2.5 h-2.5" /> Link Referensi / Modul
                              </a>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 ml-auto sm:ml-0">
                        <button
                          type="button"
                          onClick={() => setActiveSessionIndex(idx)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                            isSelected
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          {isSelected ? 'Sedang Dibaca' : 'Buka Materi'}
                        </button>
                        <button
                          type="button"
                          onClick={() => onToggleSessionDone(idx)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                            isDone
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                          }`}
                        >
                          {isDone ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Selesai
                            </>
                          ) : (
                            'Tandai Selesai'
                          )}
                        </button>
                      </div>
                    </div>

                    {/* Active Session Content Reader */}
                    {isSelected && (
                      <div className="p-4 sm:p-6 bg-slate-50/80 border-t border-slate-200 rounded-b-2xl space-y-4 animate-fade-in">
                        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                          <h4 className="font-black text-sm text-slate-900 uppercase flex items-center gap-1.5">
                            <FileText className="w-4 h-4 text-indigo-600" />
                            {currentActiveSession.judul}
                          </h4>
                          <span className="text-[11px] text-slate-400 font-mono">
                            Sesi {idx + 1} dari {sessions.length}
                          </span>
                        </div>

                        {currentActiveSession.konten ? (
                          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-2xs">
                            <div
                              className="prose prose-slate max-w-none text-sm text-slate-800 leading-relaxed word-content-viewer"
                              dangerouslySetInnerHTML={{ __html: currentActiveSession.konten }}
                            />
                          </div>
                        ) : (
                          <div className="p-6 bg-white rounded-2xl border border-slate-200 text-center text-slate-500 text-xs">
                            <p className="font-semibold text-slate-700">{currentActiveSession.judul}</p>
                            {currentActiveSession.link ? (
                              <p className="mt-2">
                                Akses tautan materi &amp; video sesi ini:{' '}
                                <a
                                  href={currentActiveSession.link}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="text-indigo-600 font-bold underline inline-flex items-center gap-1"
                                >
                                  {currentActiveSession.link} <ExternalLink className="w-3 h-3" />
                                </a>
                              </p>
                            ) : (
                              <p className="mt-1 text-slate-400">Silakan pelajari materi sesi ini lalu tandai selesai jika sudah tuntas dipelajari.</p>
                            )}
                          </div>
                        )}

                        <div className="flex justify-end">
                          {!isDone ? (
                            <button
                              type="button"
                              onClick={() => onToggleSessionDone(idx)}
                              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
                            >
                              <CheckCircle className="w-3.5 h-3.5" /> Tandai Selesai &amp; Lanjutkan
                            </button>
                          ) : (
                            <span className="text-xs font-bold text-emerald-700 flex items-center gap-1 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Sesi ini telah diselesaikan
                            </span>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Confirm Completion Button */}
          {!isFinished && (
            <div className="space-y-2">
              <button
                type="button"
                disabled={!canFinish}
                onClick={onFinishMateri}
                className={`w-full py-4 rounded-2xl font-black uppercase text-xs tracking-wider flex items-center justify-center gap-2 transition-all shadow-md ${
                  canFinish
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer hover:shadow-lg'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <CheckCircle className="w-4 h-4" />
                {canFinish
                  ? `Konfirmasi Penyelesaian Materi & Terbitkan Sertifikat (${minRequiredHours} Jam Selesai)`
                  : !isAllSessionsDone
                  ? `Selesaikan Seluruh Sesi Kurikulum Terlebih Dahulu (${completedCount}/${sessions.length})`
                  : `Kurikulum 100% Selesai • Menunggu Waktu Belajar 8 Jam (Sisa ${remainingH} Jam ${remainingM} Menit)`}
              </button>

              {!canFinish && isAllSessionsDone && !isTimeRequirementMet && (
                <p className="text-center text-xs text-amber-700 font-bold">
                  Durasi belajar Anda saat ini: <strong>{totalH} Jam {totalM} Menit</strong> dari syarat minimal <strong>{minRequiredHours} Jam (1 Hari Kerja)</strong>. Gunakan tombol simulasi di atas bila ingin mempercepat verifikasi.
                </p>
              )}
            </div>
          )}

          {/* Discussion Forum */}
          <div className="pt-6 border-t border-slate-200">
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 mb-3 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-indigo-600" /> Forum Diskusi &amp; Tanya Jawab
            </h3>

            <div className="h-64 overflow-y-auto bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3 custom-scroll">
              {chatMessages.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  Belum ada pesan diskusi di modul ini. Jadilah yang pertama bertanya!
                </div>
              ) : (
                chatMessages.map((msg, i) => {
                  const isMe = msg.nup === currentUser.nup;
                  return (
                    <div
                      key={msg.id || i}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                    >
                      <span className="text-[10px] text-slate-400 font-bold mb-0.5">
                        {msg.nama} {isMe ? '(Anda)' : ''}
                      </span>
                      <div
                        className={`px-3.5 py-2 rounded-2xl text-xs max-w-[80%] ${
                          isMe
                            ? 'bg-indigo-600 text-white rounded-tr-none'
                            : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none'
                        }`}
                      >
                        {msg.pesan}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <form onSubmit={handleSendChat} className="flex gap-2 mt-3">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Tulis komentar, tanggapan, atau pertanyaan teknis..."
                className="flex-1 border-2 border-slate-200 rounded-xl px-4 py-3 text-xs bg-white outline-none focus:border-indigo-600 transition-colors"
              />
              <button
                type="submit"
                className="px-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">Kirim</span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Back button */}
      <button
        type="button"
        onClick={onBack}
        className="px-5 py-3 rounded-2xl bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Kembali ke Daftar
      </button>
    </div>
  );
};
