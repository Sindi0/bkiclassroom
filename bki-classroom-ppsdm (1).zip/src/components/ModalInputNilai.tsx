import React, { useState } from 'react';
import { X, Save, Award, UserCheck } from 'lucide-react';
import { Materi } from '../types';
import { DATABASE_PEGAWAI } from '../data/databasePegawai';

interface ModalInputNilaiProps {
  isOpen: boolean;
  onClose: () => void;
  materiList: Record<string, Materi>;
  onSave: (materiId: string, nup: string, nilai: number) => void;
}

export const ModalInputNilai: React.FC<ModalInputNilaiProps> = ({
  isOpen,
  onClose,
  materiList,
  onSave
}) => {
  const materiKeys = Object.keys(materiList);
  const [selectedMateriId, setSelectedMateriId] = useState(materiKeys[0] || '');
  const [nup, setNup] = useState('');
  const [nilai, setNilai] = useState<number>(85);

  if (!isOpen) return null;

  const currentMateriId = selectedMateriId || materiKeys[0] || '';
  const cleanNup = nup.trim().toUpperCase();
  const detectedPegawai = cleanNup ? DATABASE_PEGAWAI[cleanNup] : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentMateriId) {
      alert('Pilih materi terlebih dahulu!');
      return;
    }
    if (!cleanNup) {
      alert('Masukkan NUP pegawai!');
      return;
    }
    if (isNaN(nilai) || nilai < 0 || nilai > 100) {
      alert('Nilai harus berupa angka antara 0 sampai 100.');
      return;
    }

    onSave(currentMateriId, cleanNup, nilai);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-white w-full max-w-md rounded-3xl p-6 shadow-2xl border border-slate-100">
        <div className="flex justify-between items-center mb-5 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Award className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-slate-900 uppercase">Input Nilai Peserta</h3>
          </div>
          <button type="button" onClick={onClose} className="text-slate-400 hover:text-rose-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Pilih Materi Pelatihan</label>
            <select
              value={currentMateriId}
              onChange={(e) => setSelectedMateriId(e.target.value)}
              className="w-full border-2 border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold bg-slate-50 focus:bg-white outline-none focus:border-indigo-600 transition-colors"
            >
              {materiKeys.map((mid) => (
                <option key={mid} value={mid}>
                  {materiList[mid].judul}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase mb-1">NUP Peserta</label>
            <input
              type="text"
              value={nup}
              onChange={(e) => setNup(e.target.value)}
              placeholder="Masukkan NUP Pegawai"
              className="w-full border-2 border-slate-200 rounded-xl px-4 py-2.5 text-xs font-mono font-bold bg-slate-50 focus:bg-white outline-none focus:border-indigo-600 uppercase transition-colors"
            />
            {detectedPegawai ? (
              <p className="text-[11px] text-emerald-600 font-bold mt-1.5 flex items-center gap-1">
                <UserCheck className="w-3.5 h-3.5" /> Terdeteksi: {detectedPegawai.nama} ({detectedPegawai.unit})
              </p>
            ) : cleanNup ? (
              <p className="text-[11px] text-slate-400 font-bold mt-1.5">
                NUP tidak terdaftar di master pegawai standar (akan disimpan sebagai peserta manual)
              </p>
            ) : null}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Nilai (0 - 100)</label>
            <input
              type="number"
              min={0}
              max={100}
              value={nilai}
              onChange={(e) => setNilai(Number(e.target.value))}
              placeholder="Contoh: 85"
              className="w-full border-2 border-slate-200 rounded-xl px-4 py-2.5 text-center text-lg font-black text-indigo-700 bg-slate-50 focus:bg-white outline-none focus:border-indigo-600 transition-colors"
            />
          </div>

          <div className="flex gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-3 font-bold text-slate-400 uppercase text-xs hover:bg-slate-50 rounded-xl border border-slate-200 transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white py-3 rounded-xl font-bold uppercase text-xs shadow-md transition-colors flex items-center justify-center gap-1.5"
            >
              <Save className="w-4 h-4" /> Simpan Nilai
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
