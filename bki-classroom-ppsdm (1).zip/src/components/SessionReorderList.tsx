import React, { useState } from 'react';
import { 
  GripVertical, 
  ChevronUp, 
  ChevronDown, 
  Trash2, 
  Plus, 
  Link as LinkIcon, 
  FileText
} from 'lucide-react';
import { SesiMateri } from '../types';

interface SessionReorderListProps {
  sessions: SesiMateri[];
  onChange: (sessions: SesiMateri[]) => void;
}

export const SessionReorderList: React.FC<SessionReorderListProps> = ({
  sessions,
  onChange
}) => {
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  const handleDragStart = (e: React.DragEvent, index: number) => {
    setDraggedIndex(index);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', index.toString());
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverIndex !== index) {
      setDragOverIndex(index);
    }
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === targetIndex) {
      setDraggedIndex(null);
      setDragOverIndex(null);
      return;
    }

    const items = [...sessions];
    const [moved] = items.splice(draggedIndex, 1);
    items.splice(targetIndex, 0, moved);

    onChange(items);
    setDraggedIndex(null);
    setDragOverIndex(null);
  };

  const moveSession = (currentIndex: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (targetIndex < 0 || targetIndex >= sessions.length) return;

    const items = [...sessions];
    const [moved] = items.splice(currentIndex, 1);
    items.splice(targetIndex, 0, moved);

    onChange(items);
  };

  const updateSession = (index: number, field: keyof SesiMateri, val: string) => {
    const items = [...sessions];
    items[index] = { ...items[index], [field]: val };
    onChange(items);
  };

  const addSession = () => {
    const newSession: SesiMateri = {
      judul: `Sesi ${sessions.length + 1}: `,
      link: ''
    };
    onChange([...sessions, newSession]);
  };

  const removeSession = (index: number) => {
    if (sessions.length <= 1) {
      alert("Materi harus memiliki minimal 1 sesi pembelajaran.");
      return;
    }
    const items = sessions.filter((_, i) => i !== index);
    onChange(items);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-indigo-600" /> Kurikulum Sesi Pembelajaran
          </label>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Tarik (drag) atau gunakan tombol panah untuk mengatur urutan materi kurikulum.
          </p>
        </div>

        <button
          type="button"
          onClick={addSession}
          className="px-3.5 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold transition-colors flex items-center gap-1.5 shadow-2xs"
        >
          <Plus className="w-3.5 h-3.5" /> Tambah Sesi
        </button>
      </div>

      {/* Reorderable Session Items */}
      <div className="space-y-2.5">
        {sessions.map((sesi, index) => {
          const isBeingDragged = draggedIndex === index;
          const isDragTarget = dragOverIndex === index && draggedIndex !== index;

          return (
            <div
              key={index}
              draggable
              onDragStart={(e) => handleDragStart(e, index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDrop={(e) => handleDrop(e, index)}
              onDragEnd={() => {
                setDraggedIndex(null);
                setDragOverIndex(null);
              }}
              className={`rounded-2xl border transition-all duration-300 ease-out select-none ${
                isBeingDragged
                  ? 'opacity-40 border-indigo-500 scale-98 bg-indigo-50/50 shadow-lg'
                  : isDragTarget
                  ? 'border-indigo-600 ring-2 ring-indigo-200 bg-indigo-50/40 scale-[1.01] shadow-md'
                  : 'border-slate-200 bg-white hover:border-slate-300 shadow-2xs'
              }`}
            >
              {/* Main Session Row */}
              <div className="p-3 flex items-center gap-2 sm:gap-3 flex-wrap sm:flex-nowrap">
                {/* Drag Handle & Up/Down Arrows */}
                <div className="flex items-center gap-1">
                  <span 
                    className="p-1.5 text-slate-400 hover:text-indigo-600 cursor-grab active:cursor-grabbing rounded hover:bg-slate-100 transition-colors"
                    title="Tarik untuk memindahkan urutan sesi"
                  >
                    <GripVertical className="w-4 h-4" />
                  </span>

                  <div className="flex flex-col">
                    <button
                      type="button"
                      disabled={index === 0}
                      onClick={() => moveSession(index, 'up')}
                      className="p-0.5 text-slate-400 hover:text-indigo-600 disabled:opacity-20 disabled:pointer-events-none transition-colors"
                      title="Geser ke atas"
                    >
                      <ChevronUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={index === sessions.length - 1}
                      onClick={() => moveSession(index, 'down')}
                      className="p-0.5 text-slate-400 hover:text-indigo-600 disabled:opacity-20 disabled:pointer-events-none transition-colors"
                      title="Geser ke bawah"
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <span className="w-7 h-7 rounded-xl bg-slate-100 text-slate-700 font-black text-xs flex items-center justify-center shrink-0">
                    {index + 1}
                  </span>
                </div>

                {/* Session Title Input */}
                <div className="flex-1 min-w-[200px]">
                  <input
                    type="text"
                    value={sesi.judul}
                    onChange={(e) => updateSession(index, 'judul', e.target.value)}
                    placeholder="Contoh: Sesi 1: Penjelasan Teori..."
                    className="w-full border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold bg-slate-50 focus:bg-white outline-none focus:border-indigo-600 transition-all"
                  />
                </div>

                {/* Optional External Link */}
                <div className="w-full sm:w-64">
                  <div className="relative">
                    <LinkIcon className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="url"
                      value={sesi.link || ''}
                      onChange={(e) => updateSession(index, 'link', e.target.value)}
                      placeholder="Link Tautan Modul / Video (Opsional)"
                      className="w-full border border-slate-200 rounded-xl pl-8 pr-3 py-2 text-xs bg-slate-50 focus:bg-white outline-none focus:border-indigo-600 transition-all font-mono"
                    />
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-1.5 ml-auto sm:ml-0">
                  <button
                    type="button"
                    onClick={() => removeSession(index)}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                    title="Hapus Sesi"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
