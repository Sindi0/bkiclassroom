import React, { useState } from 'react';
import { 
  Presentation, 
  FileSpreadsheet, 
  Clock, 
  Award, 
  Plus, 
  Lock, 
  Unlock, 
  Edit, 
  Trash2, 
  Users, 
  Search, 
  Download, 
  CheckCircle2, 
  FileText, 
  Key, 
  Sparkles,
  BookOpen
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { Materi, FolderLock, LaporanNilai, AbsenRecord, StudyTimeRecord, User } from '../types';

interface TrainerPanelProps {
  currentUser: User;
  materiList: Record<string, Materi>;
  folderLocks: Record<string, FolderLock>;
  laporanRecords: Record<string, Record<string, LaporanNilai>>;
  absenRecords: Record<string, Record<string, AbsenRecord>>;
  studyTimeRecords: Record<string, Record<string, StudyTimeRecord>>;
  onOpenAddMateri: () => void;
  onOpenEditMateri: (id: string) => void;
  onDeleteMateri: (id: string) => void;
  onOpenFolderLockModal: (folderName: string) => void;
  onOpenDetailPeserta: (materiId: string) => void;
  onOpenCertificateModal: (materiId: string, peserta: { nama: string; nup: string; unit: string; nilai: number }) => void;
  onDeleteNilai: (materiId: string, nup: string) => void;
  onDeleteAbsen: (materiId: string, nup: string) => void;
  onOpenInputNilaiModal: () => void;
}

export const TrainerPanel: React.FC<TrainerPanelProps> = ({
  currentUser,
  materiList,
  folderLocks,
  laporanRecords,
  absenRecords,
  studyTimeRecords,
  onOpenAddMateri,
  onOpenEditMateri,
  onDeleteMateri,
  onOpenFolderLockModal,
  onOpenDetailPeserta,
  onOpenCertificateModal,
  onDeleteNilai,
  onDeleteAbsen,
  onOpenInputNilaiModal
}) => {
  const [activeTab, setActiveTab] = useState<'materi' | 'folder' | 'sertifikat' | 'nilai' | 'absen' | 'waktu'>('materi');
  const [materiScope, setMateriScope] = useState<string>(currentUser.isSuperAdmin ? 'all' : currentUser.nup);
  const [searchNilai, setSearchNilai] = useState('');
  const [searchSertifikat, setSearchSertifikat] = useState('');

  // Export Excel Absen
  const downloadExcelAbsen = () => {
    const rows: any[] = [];
    Object.keys(absenRecords).forEach((mid) => {
      const mj = materiList[mid]?.judul || mid;
      Object.keys(absenRecords[mid] || {}).forEach((nup) => {
        const d = absenRecords[mid][nup];
        rows.push({
          Nama: d.nama,
          NUP: d.nup,
          Unit: d.unit,
          Kategori: (d.role || 'umum').toUpperCase(),
          Materi: mj,
          Waktu: d.waktu ? new Date(d.waktu).toLocaleString('id-ID') : '-'
        });
      });
    });
    if (!rows.length) {
      alert('Tidak ada data absensi untuk diekspor.');
      return;
    }
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Absensi');
    XLSX.writeFile(wb, 'Absensi_BKI_Classroom.xlsx');
  };

  // Export Excel Nilai
  const downloadExcelNilai = () => {
    const rows: any[] = [];
    Object.keys(laporanRecords).forEach((mid) => {
      const mj = materiList[mid]?.judul || mid;
      Object.keys(laporanRecords[mid] || {}).forEach((nup) => {
        const d = laporanRecords[mid][nup];
        rows.push({
          Nama: d.nama,
          NUP: d.nup,
          Unit: d.unit,
          Kategori: (d.role || 'umum').toUpperCase(),
          Materi: mj,
          Nilai: d.nilai,
          Waktu: d.waktu ? new Date(d.waktu).toLocaleString('id-ID') : '-'
        });
      });
    });
    if (!rows.length) {
      alert('Tidak ada data nilai untuk diekspor.');
      return;
    }
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Nilai');
    XLSX.writeFile(wb, 'Nilai_BKI_Classroom.xlsx');
  };

  // Export Excel Waktu
  const downloadExcelWaktu = () => {
    const rows: any[] = [];
    Object.keys(studyTimeRecords).forEach((mid) => {
      const mj = materiList[mid]?.judul || mid;
      const targetHours = materiList[mid]?.minimalJam || 8;
      const targetSecs = targetHours * 3600;

      Object.keys(studyTimeRecords[mid] || {}).forEach((nup) => {
        const d = studyTimeRecords[mid][nup];
        const secs = d.totalDetik || 0;
        const isQualified = secs >= targetSecs;

        rows.push({
          Nama: d.nama,
          NUP: nup,
          Unit: d.unit,
          Materi: mj,
          'Total Waktu (Jam)': Number((secs / 3600).toFixed(2)),
          'Total Waktu (Menit)': Math.round(secs / 60),
          'Target Minimal (Jam)': targetHours,
          'Status Standar 8 Jam / 1 Hari Kerja': isQualified ? 'Lengkap (Memenuhi Syarat)' : 'Belum Memenuhi (Kurang)',
          'Frekuensi Akses': d.sesiCount || 0
        });
      });
    });
    if (!rows.length) {
      alert('Tidak ada data durasi waktu belajar untuk diekspor.');
      return;
    }
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Histori Waktu');
    XLSX.writeFile(wb, 'Histori_Waktu_BKI_Classroom.xlsx');
  };

  // Filter materi
  const materiKeys = Object.keys(materiList);
  const filteredMateri = materiKeys.filter((mid) => {
    const m = materiList[mid];
    if (currentUser.isSuperAdmin) {
      if (materiScope === 'all') return true;
      return m.ownerTrainerId === materiScope;
    }
    return m.ownerTrainerId === currentUser.nup;
  });

  // Unique folders list
  const foldersMap: Record<string, { count: number; ownerNup: string; ownerName: string; isLocked: boolean; password?: string }> = {};
  materiKeys.forEach((mid) => {
    const m = materiList[mid];
    if (m.folder && m.folder.trim()) {
      const fn = m.folder.trim();
      const lockKey = encodeURIComponent(fn).replace(/\./g, '%2E');
      const lockInfo = folderLocks[lockKey];
      if (!foldersMap[fn]) {
        foldersMap[fn] = {
          count: 0,
          ownerNup: lockInfo?.ownerNup || m.ownerTrainerId || currentUser.nup,
          ownerName: lockInfo?.ownerName || m.ownerTrainerName || currentUser.nama,
          isLocked: !!lockInfo?.password,
          password: lockInfo?.password
        };
      }
      foldersMap[fn].count += 1;
    }
  });

  // Flattened Laporan for Nilai & Sertifikat tab
  const allGradedRows: {
    mid: string;
    materiJudul: string;
    nup: string;
    nama: string;
    unit: string;
    role: string;
    nilai: number;
    waktu: number;
  }[] = [];

  Object.keys(laporanRecords).forEach((mid) => {
    const m = materiList[mid];
    const mJudul = m?.judul || mid;
    Object.keys(laporanRecords[mid] || {}).forEach((nup) => {
      const d = laporanRecords[mid][nup];
      allGradedRows.push({
        mid,
        materiJudul: mJudul,
        nup,
        nama: d.nama,
        unit: d.unit,
        role: d.role,
        nilai: d.nilai,
        waktu: d.waktu
      });
    });
  });

  // Filtered for search
  const qNilai = searchNilai.toLowerCase().trim();
  const filteredNilai = allGradedRows.filter((r) => {
    if (!qNilai) return true;
    return r.nama.toLowerCase().includes(qNilai) || r.nup.toLowerCase().includes(qNilai) || r.materiJudul.toLowerCase().includes(qNilai);
  });

  const qSertifikat = searchSertifikat.toLowerCase().trim();
  const filteredSertifikat = allGradedRows.filter((r) => {
    if (!qSertifikat) return true;
    return r.nama.toLowerCase().includes(qSertifikat) || r.nup.toLowerCase().includes(qSertifikat) || r.materiJudul.toLowerCase().includes(qSertifikat);
  });

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Top Action Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-2">
            <Award className="w-6 h-6 text-indigo-600" /> Panel Manajemen Trainer & Sertifikat
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Otorisasi Aktif: <span className="font-bold text-slate-800">{currentUser.nama}</span> ({currentUser.nup}) • {currentUser.isSuperAdmin ? 'Administrator Utama' : 'Akses Privat Trainer'}
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={downloadExcelWaktu}
            className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors uppercase"
          >
            <Clock className="w-3.5 h-3.5" /> Excel Waktu
          </button>
          <button
            type="button"
            onClick={downloadExcelAbsen}
            className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors uppercase"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" /> Excel Absen
          </button>
          <button
            type="button"
            onClick={downloadExcelNilai}
            className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors uppercase"
          >
            <Award className="w-3.5 h-3.5" /> Excel Nilai
          </button>
          <button
            type="button"
            onClick={onOpenAddMateri}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/20 flex items-center gap-1.5 transition-colors uppercase"
          >
            <Plus className="w-4 h-4" /> Tambah Materi
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-2xl border border-slate-200 p-1 flex gap-1 overflow-x-auto text-xs font-bold custom-scroll">
        <button
          type="button"
          onClick={() => setActiveTab('materi')}
          className={`flex-1 py-2.5 px-4 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'materi' ? 'bg-indigo-50 text-indigo-600 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Materi Pembelajaran
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('sertifikat')}
          className={`flex-1 py-2.5 px-4 rounded-xl transition-all whitespace-nowrap flex items-center justify-center gap-1.5 ${
            activeTab === 'sertifikat' ? 'bg-amber-50 text-amber-800 shadow-2xs border border-amber-200' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Award className="w-3.5 h-3.5 text-amber-600" /> Sertifikat Pelatihan (PDF)
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('folder')}
          className={`flex-1 py-2.5 px-4 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'folder' ? 'bg-indigo-50 text-indigo-600 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Kelola Kunci Folder
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('nilai')}
          className={`flex-1 py-2.5 px-4 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'nilai' ? 'bg-indigo-50 text-indigo-600 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Nilai Peserta
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('absen')}
          className={`flex-1 py-2.5 px-4 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'absen' ? 'bg-indigo-50 text-indigo-600 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Absensi
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('waktu')}
          className={`flex-1 py-2.5 px-4 rounded-xl transition-all whitespace-nowrap ${
            activeTab === 'waktu' ? 'bg-indigo-50 text-indigo-600 shadow-2xs' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          Histori Waktu
        </button>
      </div>

      {/* TAB 1: MATERI */}
      {activeTab === 'materi' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3 bg-white p-3.5 rounded-2xl border border-slate-200">
            <div className="flex items-center gap-2">
              <label className="text-xs font-bold text-slate-600">Cakupan Materi:</label>
              {currentUser.isSuperAdmin ? (
                <select
                  value={materiScope}
                  onChange={(e) => setMateriScope(e.target.value)}
                  className="border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-bold bg-slate-50 outline-none"
                >
                  <option value="all">Semua Trainer Diklat</option>
                  <option value="TRAINER-01">Trainer 01</option>
                  <option value="TRAINER-02">Trainer 02</option>
                  <option value="TRAINER-03">Trainer 03</option>
                  <option value="TRAINER-04">Trainer 04</option>
                  <option value="TRAINER-05">Trainer 05</option>
                </select>
              ) : (
                <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-xl">
                  Materi Dikelola Oleh {currentUser.nama}
                </span>
              )}
            </div>
            <div className="text-xs text-slate-400 font-semibold">
              {filteredMateri.length} Materi Ditampilkan
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredMateri.length === 0 ? (
              <div className="col-span-full text-center py-12 bg-white rounded-3xl border border-slate-200 p-8">
                <p className="text-xs font-bold text-slate-400">
                  Belum ada materi pembelajaran yang dibuat oleh {currentUser.nama}. Klik "Tambah Materi" di atas untuk membuat modul baru.
                </p>
              </div>
            ) : (
              filteredMateri.map((mid) => {
                const m = materiList[mid];
                const isOwner = currentUser.isSuperAdmin || m.ownerTrainerId === currentUser.nup;
                const isRestricted = m.accessType === 'restricted' || (m.allowedPeserta && m.allowedPeserta.length > 0);

                return (
                  <div key={mid} className="bg-white rounded-2xl border border-slate-200 p-4 space-y-3 shadow-2xs hover:shadow-md transition-all">
                    <div className="flex items-center justify-between text-[10px] font-bold">
                      <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 truncate max-w-[140px]">
                        {m.folder || 'Tanpa Folder'}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full ${
                        isOwner ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {isOwner ? 'Materi Anda' : m.ownerTrainerName || 'Trainer'}
                      </span>
                    </div>

                    <h4 className="font-bold text-sm text-slate-800 line-clamp-1">{m.judul}</h4>

                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span>{(m.sesi || []).length} Sesi Kurikulum</span>
                      <button
                        type="button"
                        onClick={() => onOpenDetailPeserta(mid)}
                        className={`px-2 py-0.5 rounded-full text-[9px] font-bold transition-all flex items-center gap-1 ${
                          isRestricted
                            ? 'bg-violet-50 hover:bg-violet-100 text-violet-700 border border-violet-200'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                        }`}
                        title="Lihat daftar peserta berhak akses"
                      >
                        <Users className="w-3 h-3" />
                        {isRestricted ? `${(m.allowedPeserta || []).length} Peserta (Lihat List)` : 'Semua Peserta (Lihat List)'}
                      </button>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                      {isOwner ? (
                        <>
                          <button
                            type="button"
                            onClick={() => onOpenEditMateri(mid)}
                            className="flex-1 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1"
                          >
                            <Edit className="w-3.5 h-3.5" /> Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteMateri(mid)}
                            className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-600 text-xs font-bold rounded-xl transition-colors"
                            title="Hapus Materi"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      ) : (
                        <span className="text-[10px] text-slate-400 italic py-1.5 text-center w-full">
                          Dikelola oleh {m.ownerTrainerName}
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 2: SERTIFIKAT PELATIHAN (PDF) - FEATURED */}
      {activeTab === 'sertifikat' && (
        <div className="space-y-4">
          <div className="p-5 bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border border-amber-200 rounded-3xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-md font-black shrink-0">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-sm text-slate-900 uppercase">
                  Pusat Distribusi Sertifikat Otomatis & Kustom PDF
                </h3>
                <p className="text-xs text-slate-600 mt-0.5">
                  Generate sertifikat instan berformat PDF beresolusi tinggi (A4 landscape) untuk peserta yang telah lulus atau menguasai modul diklat.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                if (allGradedRows.length > 0) {
                  const r = allGradedRows[0];
                  onOpenCertificateModal(r.mid, { nama: r.nama, nup: r.nup, unit: r.unit, nilai: r.nilai });
                } else if (filteredMateri.length > 0) {
                  onOpenCertificateModal(filteredMateri[0], { nama: 'NAMA CONTOH PESERTA', nup: '123456', unit: 'DIVISI PPSDM', nilai: 95 });
                } else {
                  alert('Tambahkan minimal satu materi terlebih dahulu.');
                }
              }}
              className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-md transition-all active:scale-95 shrink-0"
            >
              <Sparkles className="w-4 h-4" /> Buka Desainer Sertifikat
            </button>
          </div>

          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchSertifikat}
                  onChange={(e) => setSearchSertifikat(e.target.value)}
                  placeholder="Cari nama peserta, NUP, atau judul pelatihan untuk cetak sertifikat..."
                  className="w-full pl-8 pr-4 py-2 border border-slate-200 rounded-xl text-xs bg-slate-50 outline-none focus:border-indigo-600"
                />
              </div>
              <span className="text-xs text-slate-400 font-bold">
                {filteredSertifikat.length} Peserta Lulus Terdata
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200">
                  <tr>
                    <th className="p-3">Nama Pegawai</th>
                    <th className="p-3">NUP</th>
                    <th className="p-3">Unit / Divisi</th>
                    <th className="p-3">Materi Pelatihan</th>
                    <th className="p-3 text-center">Nilai</th>
                    <th className="p-3 text-right">Aksi Sertifikat</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredSertifikat.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400 font-semibold">
                        Belum ada peserta yang tercatat menyelesaikan materi. Nilai akan muncul saat peserta menyelesaikan modul atau diinput manual.
                      </td>
                    </tr>
                  ) : (
                    filteredSertifikat.map((r, i) => (
                      <tr key={i} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3 font-bold text-slate-900">{r.nama}</td>
                        <td className="p-3 font-mono font-bold text-indigo-700">{r.nup}</td>
                        <td className="p-3 text-slate-500">{r.unit}</td>
                        <td className="p-3 font-semibold text-slate-800">{r.materiJudul}</td>
                        <td className="p-3 text-center font-black text-emerald-600">{r.nilai}</td>
                        <td className="p-3 text-right">
                          <button
                            type="button"
                            onClick={() => onOpenCertificateModal(r.mid, {
                              nama: r.nama,
                              nup: r.nup,
                              unit: r.unit,
                              nilai: r.nilai
                            })}
                            className="px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 font-black text-xs rounded-xl border border-amber-200 transition-colors inline-flex items-center gap-1.5 shadow-2xs"
                          >
                            <Download className="w-3.5 h-3.5 text-amber-600" /> Cetak / Unduh PDF
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: KELOLA KUNCI FOLDER */}
      {activeTab === 'folder' && (
        <div className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
            <Lock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-900 space-y-1">
              <p className="font-bold">Keamanan & Privasi Folder Materi Per-Trainer</p>
              <p className="text-amber-800 leading-relaxed">
                Setiap folder yang Anda miliki dapat dikunci dengan PIN / password khusus. Anda juga dapat mengatur posisi folder secara drag-and-drop di halaman Beranda.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.keys(foldersMap).length === 0 ? (
              <p className="text-xs text-slate-400 p-4">Belum ada folder materi yang dibuat.</p>
            ) : (
              Object.keys(foldersMap).map((fn) => {
                const fInfo = foldersMap[fn];
                const canManage = currentUser.isSuperAdmin || fInfo.ownerNup === currentUser.nup;
                const pwdMasked = fInfo.password ? (canManage ? fInfo.password : '•••••• (Privat)') : 'Tidak ada password';

                return (
                  <div key={fn} className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold text-lg">
                        <Lock className="w-5 h-5" />
                      </div>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                        fInfo.isLocked
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      }`}>
                        {fInfo.isLocked ? 'TERKUNCI' : 'TERBUKA'}
                      </span>
                    </div>

                    <h4 className="font-bold text-sm text-slate-800 truncate">{fn}</h4>
                    <p className="text-[10px] text-slate-400">
                      Pemilik: <b className="text-slate-600">{fInfo.ownerName}</b> • {fInfo.count} Materi
                    </p>

                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs font-mono font-bold text-slate-700 flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-sans">Sandi:</span>
                      <span>{pwdMasked}</span>
                    </div>

                    <div className="pt-2">
                      {canManage ? (
                        <button
                          type="button"
                          onClick={() => onOpenFolderLockModal(fn)}
                          className="w-full py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                        >
                          <Key className="w-3.5 h-3.5" /> Ubah Password Kunci
                        </button>
                      ) : (
                        <p className="text-center text-[10px] text-slate-400 italic">
                          Hanya dapat diubah oleh pemilik folder
                        </p>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* TAB 4: NILAI PESERTA */}
      {activeTab === 'nilai' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchNilai}
                onChange={(e) => setSearchNilai(e.target.value)}
                placeholder="Cari nama, NUP, atau materi..."
                className="w-full pl-8 pr-4 py-2 border border-slate-200 rounded-xl text-xs bg-slate-50 outline-none focus:border-indigo-600"
              />
            </div>
            <button
              type="button"
              onClick={onOpenInputNilaiModal}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors uppercase"
            >
              <Plus className="w-4 h-4" /> Input Nilai Manual
            </button>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-200">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="p-3">Nama Pegawai</th>
                  <th className="p-3">NUP</th>
                  <th className="p-3">Unit</th>
                  <th className="p-3">Kategori</th>
                  <th className="p-3">Materi</th>
                  <th className="p-3 text-center">Nilai</th>
                  <th className="p-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredNilai.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-6 text-center text-slate-400">
                      Belum ada data nilai peserta.
                    </td>
                  </tr>
                ) : (
                  filteredNilai.map((r, i) => (
                    <tr key={i} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3 font-bold text-slate-900">{r.nama}</td>
                      <td className="p-3 font-mono text-slate-500">{r.nup}</td>
                      <td className="p-3 text-slate-500">{r.unit}</td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                          r.role === 'reguler' ? 'bg-sky-50 text-sky-700' : 'bg-amber-50 text-amber-700'
                        }`}>
                          {(r.role || 'umum').toUpperCase()}
                        </span>
                      </td>
                      <td className="p-3 font-bold text-indigo-700">{r.materiJudul}</td>
                      <td className="p-3 text-center font-black text-sm text-emerald-600">{r.nilai}</td>
                      <td className="p-3 text-right flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenCertificateModal(r.mid, {
                            nama: r.nama,
                            nup: r.nup,
                            unit: r.unit,
                            nilai: r.nilai
                          })}
                          className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg text-xs font-bold transition-colors"
                          title="Generate Sertifikat PDF"
                        >
                          <Award className="w-3.5 h-3.5 text-amber-600" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteNilai(r.mid, r.nup)}
                          className="p-1.5 text-rose-500 hover:text-rose-700 text-xs"
                          title="Hapus Nilai"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: ABSENSI */}
      {activeTab === 'absen' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6">
          <div className="overflow-x-auto rounded-xl border border-slate-200">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-[10px] uppercase font-black text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="p-3">Nama Pegawai</th>
                  <th className="p-3">NUP</th>
                  <th className="p-3">Unit</th>
                  <th className="p-3">Kategori</th>
                  <th className="p-3">Materi</th>
                  <th className="p-3">Waktu Akses</th>
                  <th className="p-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {Object.keys(absenRecords).length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-6 text-center text-slate-400">
                      Belum ada catatan absensi aktif.
                    </td>
                  </tr>
                ) : (
                  Object.keys(absenRecords).flatMap((mid) => {
                    const mj = materiList[mid]?.judul || mid;
                    return Object.keys(absenRecords[mid] || {}).map((nup) => {
                      const d = absenRecords[mid][nup];
                      const t = d.waktu ? new Date(d.waktu).toLocaleString('id-ID') : '-';
                      return (
                        <tr key={`${mid}-${nup}`} className="hover:bg-slate-50 transition-colors">
                          <td className="p-3 font-bold text-slate-900">{d.nama}</td>
                          <td className="p-3 font-mono text-slate-500">{d.nup}</td>
                          <td className="p-3 text-slate-500">{d.unit}</td>
                          <td className="p-3">
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-slate-100 text-slate-600">
                              {(d.role || 'umum').toUpperCase()}
                            </span>
                          </td>
                          <td className="p-3 font-bold text-indigo-700">{mj}</td>
                          <td className="p-3 text-slate-400 font-mono text-[11px]">{t}</td>
                          <td className="p-3 text-right">
                            <button
                              type="button"
                              onClick={() => onDeleteAbsen(mid, nup)}
                              className="text-rose-500 hover:text-rose-700 p-1"
                              title="Hapus Log Absen"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    });
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 6: HISTORI WAKTU */}
      {activeTab === 'waktu' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-3">
          <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-2xl flex items-center justify-between text-xs font-bold text-indigo-900">
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-indigo-600" /> Standar Durasi Pembelajaran: 8 Jam (1 Hari Kerja)
            </span>
            <span className="text-[11px] font-normal text-indigo-700">
              Digunakan sebagai tolok ukur penerbitan sertifikat kelulusan
            </span>
          </div>

          {Object.keys(studyTimeRecords).length === 0 ? (
            <p className="text-center text-xs text-slate-400 py-8">
              Belum ada catatan durasi waktu belajar peserta.
            </p>
          ) : (
            Object.keys(studyTimeRecords).flatMap((mid) => {
              const mj = materiList[mid]?.judul || mid;
              const targetHours = materiList[mid]?.minimalJam || 8;
              const targetSecs = targetHours * 3600;

              return Object.keys(studyTimeRecords[mid] || {}).map((nup) => {
                const d = studyTimeRecords[mid][nup];
                const secs = d.totalDetik || 0;
                const hours = Math.floor(secs / 3600);
                const mins = Math.floor((secs % 3600) / 60);
                const s = secs % 60;
                const isQualified = secs >= targetSecs;
                const pct = Math.min(100, Math.round((secs / targetSecs) * 100));

                return (
                  <div
                    key={`${mid}-${nup}`}
                    className="p-4 rounded-2xl bg-white border border-slate-200 flex items-center justify-between gap-4 shadow-2xs hover:border-indigo-300 transition-colors flex-wrap sm:flex-nowrap"
                  >
                    <div className="flex-1 min-w-[200px]">
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-sm text-slate-800">
                          {d.nama} <span className="font-mono text-slate-400 text-xs">({nup})</span>
                        </p>
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase inline-flex items-center gap-1 ${
                          isQualified 
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                            : 'bg-amber-100 text-amber-800 border border-amber-300'
                        }`}>
                          {isQualified ? '✓ 8 Jam Terpenuhi' : `${pct}% dari 8 Jam`}
                        </span>
                      </div>
                      <p className="text-[11px] text-indigo-600 font-bold mt-0.5">{mj}</p>
                      
                      {/* Mini progress bar toward 8 hours */}
                      <div className="w-full max-w-xs bg-slate-100 rounded-full h-1.5 mt-2 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${isQualified ? 'bg-emerald-500' : 'bg-amber-500'}`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="font-black text-sm text-slate-900 font-mono">
                        {hours} jam {mins} menit {s} dtk
                      </p>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        Target: {targetHours} Jam • {d.sesiCount || 1} sesi dibuka
                      </p>
                    </div>
                  </div>
                );
              });
            })
          )}
        </div>
      )}
    </div>
  );
};
