import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import { 
  getDatabase, 
  ref, 
  onValue, 
  set, 
  update, 
  remove, 
  push, 
  serverTimestamp, 
  Database 
} from 'firebase/database';
import { Materi, FolderLock, AbsenRecord, LaporanNilai, StudyTimeRecord, ChatMessage, CertificateConfig } from '../types';

const firebaseConfig = {
  apiKey: "AIzaSyBkLiqHrvTuFFpaVsmWT2H1wF5NzwgmuBQ",
  authDomain: "diklatppsdm-e7788.firebaseapp.com",
  databaseURL: "https://diklatppsdm-e7788-default-rtdb.firebaseio.com",
  projectId: "diklatppsdm-e7788",
  storageBucket: "diklatppsdm-e7788.firebasestorage.app",
  messagingSenderId: "573889493408",
  appId: "1:573889493408:web:fd7704a7d40e72e72c4cc5"
};

let app: FirebaseApp | null = null;
let db: Database | null = null;

try {
  app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
  db = getDatabase(app);
} catch (e) {
  console.warn("Firebase initialize warning:", e);
}

export { db, serverTimestamp };

// Local storage fallback helpers for smooth offline or instant persistence
export const getLocalData = <T>(key: string, defaultValue: T): T => {
  try {
    const raw = localStorage.getItem(`bki_${key}`);
    return raw ? JSON.parse(raw) : defaultValue;
  } catch {
    return defaultValue;
  }
};

export const setLocalData = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(`bki_${key}`, JSON.stringify(value));
  } catch (e) {
    console.error("Local storage set error", e);
  }
};

// Default seed materi if database is completely blank
export const DEFAULT_SEED_MATERI: Record<string, Materi> = {
  "materi-k3-dasar": {
    id: "materi-k3-dasar",
    judul: "K3 Dasar Lingkungan Maritim & Galangan Kapal",
    folder: "Modul K3 & HSE",
    targetRole: "semua",
    accessType: "all",
    minimalJam: 8, // Standar minimal 8 jam pembelajaran / 1 hari kerja
    gambar: "https://images.unsplash.com/photo-1541888946425-d0fbb18615f8?auto=format&fit=crop&w=1200&q=80",
    ownerTrainerId: "TRAINER-01",
    ownerTrainerName: "Trainer 01",
    createdAt: Date.now() - 10000000,
    sesi: [
      {
        judul: "1. Pengenalan Regulasi Keselamatan Maritim & Standar BKI",
        konten: `<h2><b>Regulasi Keselamatan Kerja di Galangan Kapal</b></h2>
<p>Keselamatan dan Kesehatan Kerja (K3) merupakan prioritas mutlak dalam industri maritim nasional dan internasional. Sebagai surveyor dan personel teknik PT Biro Klasifikasi Indonesia (Persero), kepatuhan terhadap regulasi keselamatan kerja bukan hanya kewajiban prosedural, melainkan benteng perlindungan jiwa raga dan integritas operasional.</p>
<hr/>
<h3><b>1. Dasar Hukum & Standar Internasional</b></h3>
<ul>
  <li><b>SOLAS 1974 (Safety of Life at Sea):</b> Standar konstruksi, perlengkapan, dan pengoperasian kapal yang aman.</li>
  <li><b>MARPOL 73/78:</b> Pencegahan pencemaran laut oleh minyak, limbah kimia, dan gas buang galangan.</li>
  <li><b>UU No. 1 Tahun 1970:</b> Keselamatan kerja di lingkungan darat, air, dan udara di wilayah yurisdiksi Indonesia.</li>
  <li><b>Peraturan Klasifikasi BKI Part 1:</b> Ketentuan umum keselamatan konstruksi dan lambung kapal.</li>
</ul>
<br/>
<table border="1" style="width:100%; border-collapse: collapse; text-align: left;">
  <thead>
    <tr style="background-color: #f1f5f9;">
      <th style="padding: 8px;">Kategori Bahaya</th>
      <th style="padding: 8px;">Area Galangan</th>
      <th style="padding: 8px;">Alat Pelindung Diri (APD) Wajib</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="padding: 8px;">Bekerja di Ketinggian (Working at Heights)</td>
      <td style="padding: 8px;">Scaffolding lambung luar, tiang agung (mast)</td>
      <td style="padding: 8px;">Full Body Harness dengan double lanyard, Safety Helmet</td>
    </tr>
    <tr>
      <td style="padding: 8px;">Ruang Terbatas (Confined Space)</td>
      <td style="padding: 8px;">Double bottom tank, ballast tank, cofferdam</td>
      <td style="padding: 8px;">Gas detector multi-gas, blower sirkulasi, emergency breathing apparatus</td>
    </tr>
    <tr>
      <td style="padding: 8px;">Pekerjaan Panas (Hot Work)</td>
      <td style="padding: 8px;">Pengelasan plat kulit, cutting torch pemotongan baja</td>
      <td style="padding: 8px;">Welding mask, leather apron, APAR stand-by 2 unit</td>
    </tr>
  </tbody>
</table>
<br/>
<p><i>Catatan penting: Setiap kegiatan inspeksi di ruang terbatas wajib memiliki <b>Gas Free Certificate</b> yang masih berlaku sebelum surveyor memasuki kompartemen.</i></p>`
      },
      {
        judul: "2. Prosedur Izin Kerja (Permit to Work) & Investigasi Bahaya",
        konten: `<h3><b>Sistem Izin Kerja (Permit to Work System)</b></h3>
<p>Sebelum memulai investigasi lapangan atau survei teknis di atas kapal, setiap pengawas dan peserta pelatihan harus memastikan otorisasi resmi telah diterbitkan oleh Safety Officer / HSE Officer galangan.</p>
<ol>
  <li><b>Identifikasi Bahaya:</b> Menggunakan matriks HIRADC (Hazard Identification, Risk Assessment and Determining Control).</li>
  <li><b>Lockout / Tagout (LOTO):</b> Mematikan suplai daya listrik tegangan tinggi dan memberi label peringatan sebelum survei kamar mesin (engine room).</li>
  <li><b>Komunikasi Tim:</b> Menggunakan radio handy-talkie intrinsically safe (anti-percikan) pada kompartemen tangki kargo tanker.</li>
</ol>`
      },
      {
        judul: "3. Simulasi Tanggap Darurat & Evakuasi",
        link: "https://www.bki.co.id"
      }
    ]
  },
  "materi-konstruksi-lambung": {
    id: "materi-konstruksi-lambung",
    judul: "Inspeksi Konstruksi Lambung & Plat Kulit Kapal Baja",
    folder: "Teknik Lambung & Survei",
    targetRole: "semua",
    accessType: "all",
    gambar: "https://images.unsplash.com/photo-1559136555-9303baea8ebd?auto=format&fit=crop&w=1200&q=80",
    ownerTrainerId: "TRAINER-02",
    ownerTrainerName: "Trainer 02",
    createdAt: Date.now() - 5000000,
    sesi: [
      {
        judul: "1. Prinsip Kekuatan Memanjang & Melintang Kapal",
        konten: `<h2><b>Struktur Kekuatan Memanjang Lambung Kapal (Longitudinal Strength)</b></h2>
<p>Beban gelombang samudra menimbulkan momen lentur gelombang (wave bending moment) yang menghasilkan dua kondisi kritis:</p>
<ul>
  <li><b>Sagging:</b> Bagian tengah kapal berada di lembah gelombang, menyebabkan geladak atas (upper deck) mengalami tegangan tekan (compression) dan alas ganda (bottom shell) mengalami tegangan tarik (tension).</li>
  <li><b>Hogging:</b> Puncak gelombang berada di tengah kapal, menyebabkan geladak atas mengalami tegangan tarik dan plat alas mengalami tegangan tekan.</li>
</ul>
<p>Oleh karena itu, modul penampang (section modulus) kapal baja harus mematuhi formula klasifikasi BKI Volume II (Rules for Hull).</p>`
      },
      {
        judul: "2. Evaluasi Korosi Plat & Ultrasonic Thickness Measurement (UTM)",
        konten: `<h3><b>Metode Pengukuran Ketebalan Plat Baja Kapal</b></h3>
<p>Pengurangan ketebalan plat kulit akibat korosi air laut (diminution) dievaluasi melalui NDT Ultrasonic Thickness Gauge. Toleransi maksimum keausan plat umumnya berkisar 20% - 25% dari ketebalan aslinya (as-built) sebelum direkomendasikan pembaruan plat (renewal).</p>`
      }
    ]
  }
};
